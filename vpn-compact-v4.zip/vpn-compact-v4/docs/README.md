# VPN Compact v4

Panel compacto para VPS Debian/Ubuntu con gestión de usuarios SSH/VPN, puertos SSH 80/443, estado en tiempo real con puntos verde/rojo, logs y plantillas systemd para Hysteria, Trojan-Go, UDP Custom, BM/BadVPN y BLE custom.

## Instalación

```bash
sudo apt update -y && sudo apt install -y wget unzip
wget -O vpn-compact-v4.zip "URL_RAW_DE_TU_REPO/vpn-compact-v4.zip"
unzip -o vpn-compact-v4.zip
cd vpn-compact-v4
sudo bash install.sh
menu
```

## Importante

Este paquete no incluye binarios de terceros. Coloca los binarios legítimos en `/usr/local/bin/` y edita los archivos de configuración en `/etc/hysteria/` y `/etc/trojan-go/` antes de activar esos servicios.

## Comandos

- `menu` o `vpn-panel`: abrir panel.
- Usuarios guardados: `/etc/vpn-panel/users.db`.
- Logs del panel: `/var/log/vpn-panel/actions.log`.
