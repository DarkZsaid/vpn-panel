#!/usr/bin/env bash
set -euo pipefail

PANEL_DIR="/opt/vpn-panel"
BIN_DIR="/usr/local/sbin"
DATA_DIR="/etc/vpn-panel"

need_root(){ [[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Ejecuta como root: sudo bash install.sh"; exit 1; }; }
install_pkg(){
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y openssh-server curl wget unzip jq ca-certificates sudo iproute2 net-tools lsof cron
}
setup_dirs(){
  mkdir -p "$PANEL_DIR" "$DATA_DIR" /etc/ssh/sshd_config.d /etc/hysteria /etc/trojan-go /var/log/vpn-panel
  cp -r bin systemd config docs "$PANEL_DIR"/
  install -m 0755 bin/vpn-panel.sh "$BIN_DIR/vpn-panel"
  ln -sf "$BIN_DIR/vpn-panel" "$BIN_DIR/menu"
  touch "$DATA_DIR/users.db" /var/log/vpn-panel/actions.log
}
setup_ssh_ports(){
  cat >/etc/ssh/sshd_config.d/99-vpn-panel.conf <<'SSHD'
Port 22
Port 80
Port 443
PasswordAuthentication yes
PermitTunnel yes
AllowTcpForwarding yes
ClientAliveInterval 60
ClientAliveCountMax 2
X11Forwarding no
SSHD
  systemctl enable ssh >/dev/null 2>&1 || true
  systemctl restart ssh || systemctl restart sshd
}
install_units(){
  cp systemd/*.service /etc/systemd/system/ 2>/dev/null || true
  systemctl daemon-reload
}
main(){
  need_root
  echo "Instalando panel VPN compact v4..."
  install_pkg
  setup_dirs
  setup_ssh_ports
  install_units
  echo "OK. Ejecuta: menu"
  echo "Nota: Hysteria/Trojan/UDP Custom requieren colocar sus binarios en /usr/local/bin y editar configs en /etc."
}
main "$@"
