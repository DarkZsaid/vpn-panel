#!/bin/bash
# ╔══════════════════════════════════════════════════════╗
#   DARKZSAID PREMIUM - INSTALADOR PRINCIPAL
#   bash install.sh
# ╚══════════════════════════════════════════════════════╝

W='\033[1;37m'; Y='\033[38;5;220m'; YB='\033[1;33m'
R='\033[0;31m'; RB='\033[1;31m'; G='\033[0;32m'
GB='\033[1;32m'; DIM='\033[2m'; BLD='\033[1m'; NC='\033[0m'

MOD_DIR="/usr/local/bin/dz-panel"
BASE_DIR="/etc/dz-panel"
CFG_DIR="$BASE_DIR/config"
USR_DIR="$BASE_DIR/users"

bar() {
    local msg="$1"
    local width=36
    echo -ne "\n  ${Y}${BLD}${msg}${NC} ${DIM}[${NC}"
    for ((i=0; i<=width; i++)); do
        echo -ne "${Y}█${NC}"
        sleep 0.03
    done
    echo -e "${DIM}]${NC} ${GB}${BLD}✔${NC}"
}
ok()  { echo -e "  ${GB}[✔]${NC} ${W}${BLD}${1}${NC}"; }
err() { echo -e "  ${RB}[✘]${NC} ${W}${1}${NC}"; }

clear
echo ""
echo -e "  ${Y}${BLD}╔══════════════════════════════════════════════════╗${NC}"
echo -e "  ${Y}${BLD}║  ⚡ DARKZSAID PREMIUM - INSTALADOR v1.0          ║${NC}"
echo -e "  ${Y}${BLD}╠══════════════════════════════════════════════════╣${NC}"
echo -e "  ${Y}${BLD}║${NC}  ${W}${BLD}Sistema :${NC} $(grep PRETTY /etc/os-release 2>/dev/null | cut -d'"' -f2)"
echo -e "  ${Y}${BLD}║${NC}  ${W}${BLD}IP      :${NC} $(curl -s --max-time 5 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
echo -e "  ${Y}${BLD}║${NC}  ${W}${BLD}Arch    :${NC} $(uname -m)"
echo -e "  ${Y}${BLD}╚══════════════════════════════════════════════════╝${NC}"
echo ""

[[ $EUID -ne 0 ]] && { err "Ejecuta como root."; exit 1; }
[[ ! -f /etc/os-release ]] && { err "OS no detectado."; exit 1; }
source /etc/os-release
if [[ "$ID" != "ubuntu" ]] || [[ "${VERSION_ID}" != "20.04" && "${VERSION_ID}" != "22.04" ]]; then
    echo -e "  ${Y}[!]${NC} ${W}Se recomienda Ubuntu 20.04/22.04. Continuar de todas formas?${NC}"
fi

echo -ne "  ${Y}${BLD}❯ Iniciar instalación? [s/N]: ${NC}"
read -r CONF
[[ "${CONF,,}" != "s" ]] && exit 0

echo ""
bar "Creando estructura de directorios"
mkdir -p "$BASE_DIR" "$CFG_DIR" "$USR_DIR"
mkdir -p "$MOD_DIR"/{protocols,users,config,install}

bar "Copiando módulos del panel"
SRC="$(dirname "$(realpath "$0")")"
cp -r "$SRC/protocols/"* "$MOD_DIR/protocols/" 2>/dev/null
cp -r "$SRC/users/"*     "$MOD_DIR/users/"     2>/dev/null
cp -r "$SRC/config/"*    "$MOD_DIR/config/"    2>/dev/null
cp -r "$SRC/install/"*   "$MOD_DIR/install/"   2>/dev/null
cp    "$SRC/vpn-menu.sh" "$MOD_DIR/vpn-menu.sh"
find  "$MOD_DIR" -name "*.sh" -exec chmod +x {} \;

bar "Instalando dependencias del sistema"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y -qq
apt-get install -y \
    curl wget unzip tar git jq bc socat openssl ca-certificates \
    python3 nginx certbot python3-certbot-nginx \
    dropbear stunnel4 fail2ban ufw qrencode uuid-runtime \
    net-tools iproute2 iptables iptables-persistent \
    build-essential cmake vnstat cron \
    --no-install-recommends -qq 2>/dev/null

bar "Configurando IP forwarding"
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-dz.conf
sysctl -p /etc/sysctl.d/99-dz.conf &>/dev/null

bar "Activando BBR"
modprobe tcp_bbr 2>/dev/null
grep -q "tcp_bbr" /etc/modules-load.d/modules.conf 2>/dev/null \
    || echo "tcp_bbr" >> /etc/modules-load.d/modules.conf

bar "Creando comando global 'vpn'"
cat > /usr/local/bin/vpn <<'EOF'
#!/bin/bash
source /usr/local/bin/dz-panel/vpn-menu.sh
EOF
chmod +x /usr/local/bin/vpn

bar "Habilitando servicios base"
systemctl enable --now fail2ban &>/dev/null
systemctl enable --now cron &>/dev/null

echo ""
echo -e "  ${GB}${BLD}╔══════════════════════════════════════════════════╗${NC}"
echo -e "  ${GB}${BLD}║  ✔  DARKZSAID PREMIUM INSTALADO CORRECTAMENTE   ║${NC}"
echo -e "  ${GB}${BLD}╠══════════════════════════════════════════════════╣${NC}"
echo -e "  ${GB}${BLD}║${NC}  ${DIM}Panel en:${NC}  ${W}${BLD}/usr/local/bin/dz-panel/${NC}"
echo -e "  ${GB}${BLD}║${NC}  ${DIM}Config:${NC}    ${W}${BLD}/etc/dz-panel/config/${NC}"
echo -e "  ${GB}${BLD}║${NC}  ${DIM}Usuarios:${NC}  ${W}${BLD}/etc/dz-panel/users/users.db${NC}"
echo -e "  ${GB}${BLD}╠══════════════════════════════════════════════════╣${NC}"
echo -e "  ${GB}${BLD}║${NC}  ${Y}${BLD}Pasos siguientes:${NC}"
echo -e "  ${GB}${BLD}║${NC}  ${W}${BLD}1.${NC} Ejecuta ${Y}${BLD}vpn${NC}"
echo -e "  ${GB}${BLD}║${NC}  ${W}${BLD}2.${NC} Ve a ${Y}${BLD}Configuración → Dominio + SSL${NC}"
echo -e "  ${GB}${BLD}║${NC}  ${W}${BLD}3.${NC} Instala los protocolos que necesites"
echo -e "  ${GB}${BLD}║${NC}  ${W}${BLD}4.${NC} Crea tus primeros usuarios"
echo -e "  ${GB}${BLD}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${Y}${BLD}Abre el panel con:  ${W}vpn${NC}"
echo ""
