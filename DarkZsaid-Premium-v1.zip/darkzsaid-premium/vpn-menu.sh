#!/bin/bash
# ╔══════════════════════════════════════════════════════╗
#   DARKZSAID PREMIUM - VPN PANEL v1.0
#   Ubuntu 20.04 / 22.04 | by DarkZsaid
# ╚══════════════════════════════════════════════════════╝

# ── COLORES PREMIUM ─────────────────────────────────────
W='\033[1;37m'          # Blanco grueso
Y='\033[38;5;220m'      # Amarillo suave
YB='\033[1;33m'         # Amarillo bold
R='\033[0;31m'          # Rojo (números)
RB='\033[1;31m'         # Rojo bold
G='\033[0;32m'          # Verde
GB='\033[1;32m'         # Verde bold
C='\033[0;36m'          # Cyan
DIM='\033[2m'           # Tenue
BLD='\033[1m'           # Bold
NC='\033[0m'            # Reset
LINE="${DIM}────────────────────────────────────────────────${NC}"

# ── RUTAS ───────────────────────────────────────────────
BASE_DIR="/etc/dz-panel"
CFG_DIR="$BASE_DIR/config"
USR_DIR="$BASE_DIR/users"
MOD_DIR="/usr/local/bin/dz-panel"
DB="$USR_DIR/users.db"

# ── HELPERS ─────────────────────────────────────────────
check_root() {
    [[ $EUID -ne 0 ]] && { echo -e "${RB}[!] Ejecuta como root.${NC}"; exit 1; }
}

load_cfg() {
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
}

# Punto verde/rojo en tiempo real
dot() {
    systemctl is-active --quiet "$1" 2>/dev/null \
        && echo -e "${GB}●${NC}" || echo -e "${R}●${NC}"
}

# Barra de progreso limpia
progress() {
    local msg="$1"
    local cmd="$2"
    local width=36
    echo -ne "  ${Y}${msg}${NC} ${DIM}[${NC}"
    eval "$cmd" &>/dev/null &
    local pid=$!
    local i=0
    while kill -0 $pid 2>/dev/null; do
        local filled=$(( i * width / 100 ))
        local bar=""
        for ((j=0; j<filled; j++)); do bar+="${Y}█${NC}"; done
        for ((j=filled; j<width; j++)); do bar+="${DIM}░${NC}"; done
        echo -ne "\r  ${Y}${BLD}${msg}${NC} ${DIM}[${NC}${bar}${DIM}]${NC} ${W}${i}%%${NC}  "
        i=$(( (i + 3) % 101 ))
        sleep 0.08
    done
    # Barra completa al terminar
    local full=""
    for ((j=0; j<width; j++)); do full+="${Y}█${NC}"; done
    echo -e "\r  ${Y}${BLD}${msg}${NC} ${DIM}[${NC}${full}${DIM}]${NC} ${GB}${BLD}100%% ✔${NC}  "
    wait $pid
    return $?
}

# Ejecutar con barra (para comandos sin background complejo)
bar() {
    local msg="$1"; shift
    local width=36
    echo -ne "  ${Y}${BLD}${msg}${NC} ${DIM}[${NC}"
    for ((i=0; i<=width; i++)); do
        echo -ne "${Y}█${NC}"
        sleep 0.04
    done
    echo -e "${DIM}]${NC} ${GB}${BLD}✔${NC}"
    eval "$@" &>/dev/null
}

ok()   { echo -e "  ${GB}[✔]${NC} ${W}${BLD}${1}${NC}"; }
err()  { echo -e "  ${RB}[✘]${NC} ${W}${1}${NC}"; }
info() { echo -e "  ${Y} ›${NC} ${W}${1}${NC}"; }
pause(){ echo -ne "\n  ${DIM}Presiona ENTER para continuar...${NC}"; read -r; }

# ── BANNER ──────────────────────────────────────────────
banner() {
    clear
    local IP
    IP=$(curl -s --max-time 3 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
    echo ""
    echo -e "  ${Y}${BLD}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${W}${BLD}⚡ DARKZSAID PREMIUM${NC}  ${DIM}│${NC}  ${Y}VPN PANEL v1.0${NC}          ${Y}${BLD}║${NC}"
    echo -e "  ${Y}${BLD}╠══════════════════════════════════════════════════╣${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Sistema :${NC} ${W}${BLD}$(grep PRETTY /etc/os-release 2>/dev/null | cut -d'"' -f2 || echo Linux)${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}IP VPS  :${NC} ${YB}${IP}${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Dominio :${NC} ${C}${DOMAIN:-Sin configurar}${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Fecha   :${NC} ${DIM}$(date '+%d/%m/%Y  %H:%M:%S')${NC}"
    echo -e "  ${Y}${BLD}╠══════════════════════════════════════════════════╣${NC}"
    echo -ne "  ${Y}${BLD}║${NC}  "
    local svcs=("ssh:SSH" "nginx:Nginx" "xray:Xray" "v2ray:V2Ray" "hysteria:Hysteria" "badvpn-udpgw:UDPGW")
    for s in "${svcs[@]}"; do
        IFS=':' read -r svc lbl <<< "$s"
        echo -ne "$(dot $svc)${W}${BLD}${lbl}${NC}  "
    done
    echo -e "\n  ${Y}${BLD}╚══════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ── MENÚ PRINCIPAL ──────────────────────────────────────
main_menu() {
    while true; do
        banner
        echo -e "  ${Y}${BLD}MENÚ PRINCIPAL${NC} $LINE"
        echo ""
        echo -e "  ${R}${BLD}[01]${NC}  ${W}${BLD}Instalación de Protocolos${NC}"
        echo -e "  ${R}${BLD}[02]${NC}  ${W}${BLD}Gestión de Usuarios${NC}"
        echo -e "  ${R}${BLD}[03]${NC}  ${W}${BLD}Estado de Servicios${NC}"
        echo -e "  ${R}${BLD}[04]${NC}  ${W}${BLD}Configuración del Sistema${NC}"
        echo -e "  ${R}${BLD}[05]${NC}  ${W}${BLD}Herramientas de Red${NC}"
        echo -e "  ${R}${BLD}[06]${NC}  ${W}${BLD}Logs y Monitoreo${NC}"
        echo -e "  ${R}${BLD}[07]${NC}  ${W}${BLD}Backup y Restauración${NC}"
        echo -e "  ${R}${BLD}[00]${NC}  ${W}${BLD}Salir${NC}"
        echo ""
        echo -e "  $LINE"
        echo -e "  ${DIM}Comando: ${Y}${BLD}vpn${NC}"
        echo ""
        echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"
        read -r o
        case $o in
            1|01) install_menu ;;
            2|02) user_menu ;;
            3|03) status_menu ;;
            4|04) config_menu ;;
            5|05) net_menu ;;
            6|06) log_menu ;;
            7|07) backup_menu ;;
            0|00) echo -e "\n  ${GB}✔ Hasta pronto.${NC}\n"; exit 0 ;;
            *)    echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.6 ;;
        esac
    done
}

# ── MENÚ INSTALACIÓN ────────────────────────────────────
install_menu() {
    while true; do
        banner
        echo -e "  ${Y}${BLD}INSTALACIÓN DE PROTOCOLOS${NC} $LINE"
        echo ""
        echo -e "  ${DIM}── SSH WebSocket ─────────────────────────────────${NC}"
        echo -e "  ${R}${BLD}[01]${NC}  ${W}${BLD}SSH WebSocket${NC}          ${DIM}Puerto 80${NC}"
        echo -e "  ${R}${BLD}[02]${NC}  ${W}${BLD}SSH WebSocket SSL${NC}      ${DIM}Puerto 443${NC}"
        echo ""
        echo -e "  ${DIM}── UDP ───────────────────────────────────────────${NC}"
        echo -e "  ${R}${BLD}[03]${NC}  ${W}${BLD}Hysteria v2 + obfs${NC}     ${DIM}Puertos 10000-65000 UDP${NC}"
        echo -e "  ${R}${BLD}[04]${NC}  ${W}${BLD}UDP Custom BadVPN${NC}      ${DIM}Puerto 7300${NC}"
        echo ""
        echo -e "  ${DIM}── V2Ray / Xray ──────────────────────────────────${NC}"
        echo -e "  ${R}${BLD}[05]${NC}  ${W}${BLD}V2Ray VMess WS${NC}         ${DIM}Puerto 80/443${NC}"
        echo -e "  ${R}${BLD}[06]${NC}  ${W}${BLD}VLESS WS + TLS${NC}         ${DIM}Puerto 443${NC}"
        echo -e "  ${R}${BLD}[07]${NC}  ${W}${BLD}Trojan-GFW WS${NC}          ${DIM}Puerto 443${NC}"
        echo -e "  ${R}${BLD}[08]${NC}  ${W}${BLD}Xray VLESS Reality${NC}     ${DIM}Puerto 443${NC}"
        echo ""
        echo -e "  ${DIM}── Otros ─────────────────────────────────────────${NC}"
        echo -e "  ${R}${BLD}[09]${NC}  ${W}${BLD}OpenVPN TCP/UDP${NC}        ${DIM}Puerto 1194/1195${NC}"
        echo -e "  ${R}${BLD}[10]${NC}  ${W}${BLD}SlowDNS${NC}                ${DIM}Puerto 53 UDP${NC}"
        echo ""
        echo -e "  ${YB}${BLD}[11]${NC}  ${W}${BLD}★ INSTALAR TODO${NC}        ${DIM}Todos los protocolos${NC}"
        echo -e "  ${R}${BLD}[00]${NC}  ${W}${BLD}Regresar${NC}"
        echo ""
        echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"
        read -r o
        case $o in
            1|01)  source "$MOD_DIR/protocols/ssh-ws.sh"    && install_ssh_ws 80 ;;
            2|02)  source "$MOD_DIR/protocols/ssh-ws.sh"    && install_ssh_ws 443 ;;
            3|03)  source "$MOD_DIR/protocols/hysteria2.sh" && install_hysteria2 ;;
            4|04)  source "$MOD_DIR/protocols/udp.sh"       && install_badvpn ;;
            5|05)  source "$MOD_DIR/protocols/xray.sh"      && install_vmess ;;
            6|06)  source "$MOD_DIR/protocols/xray.sh"      && install_vless ;;
            7|07)  source "$MOD_DIR/protocols/xray.sh"      && install_trojan ;;
            8|08)  source "$MOD_DIR/protocols/xray.sh"      && install_reality ;;
            9|09)  source "$MOD_DIR/protocols/openvpn.sh"   && install_openvpn ;;
            10)    source "$MOD_DIR/protocols/udp.sh"       && install_slowdns ;;
            11)    install_all ;;
            0|00)  break ;;
            *)     echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.6 ;;
        esac
    done
}

# ── MENÚ USUARIOS ───────────────────────────────────────
user_menu() {
    while true; do
        banner
        echo -e "  ${Y}${BLD}GESTIÓN DE USUARIOS${NC} $LINE"
        echo ""
        echo -e "  ${R}${BLD}[01]${NC}  ${W}${BLD}Crear Usuario${NC}"
        echo -e "  ${R}${BLD}[02]${NC}  ${W}${BLD}Ver Usuarios Activos${NC}"
        echo -e "  ${R}${BLD}[03]${NC}  ${W}${BLD}Editar Usuario${NC}"
        echo -e "  ${R}${BLD}[04]${NC}  ${W}${BLD}Eliminar Usuario${NC}"
        echo -e "  ${R}${BLD}[05]${NC}  ${W}${BLD}Renovar Expiración${NC}"
        echo -e "  ${R}${BLD}[06]${NC}  ${W}${BLD}Bloquear / Desbloquear${NC}"
        echo -e "  ${R}${BLD}[07]${NC}  ${W}${BLD}Conexiones Activas${NC}"
        echo -e "  ${R}${BLD}[08]${NC}  ${W}${BLD}Usuarios Expirados${NC}"
        echo -e "  ${R}${BLD}[09]${NC}  ${W}${BLD}Generar QR de Conexión${NC}"
        echo -e "  ${R}${BLD}[00]${NC}  ${W}${BLD}Regresar${NC}"
        echo ""
        echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"
        read -r o
        case $o in
            1|01) source "$MOD_DIR/users/manage.sh" && create_user ;;
            2|02) source "$MOD_DIR/users/manage.sh" && list_users ;;
            3|03) source "$MOD_DIR/users/manage.sh" && edit_user ;;
            4|04) source "$MOD_DIR/users/manage.sh" && delete_user ;;
            5|05) source "$MOD_DIR/users/manage.sh" && renew_user ;;
            6|06) source "$MOD_DIR/users/manage.sh" && toggle_user ;;
            7|07) source "$MOD_DIR/users/manage.sh" && active_conns ;;
            8|08) source "$MOD_DIR/users/manage.sh" && expired_users ;;
            9|09) source "$MOD_DIR/users/manage.sh" && gen_qr ;;
            0|00) break ;;
            *)    echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.6 ;;
        esac
    done
}

# ── ESTADO ──────────────────────────────────────────────
status_menu() {
    banner
    echo -e "  ${Y}${BLD}ESTADO DE SERVICIOS${NC} $LINE"
    echo ""
    local rows=(
        "ssh:SSH OpenSSH:22/tcp"
        "dropbear:Dropbear SSH:109/tcp"
        "nginx:Nginx SSL Proxy:80·443"
        "hysteria:Hysteria v2 UDP:10000-65000"
        "badvpn-udpgw:UDP Custom UDPGW:7300/tcp"
        "v2ray:V2Ray VMess:10086"
        "xray:Xray VLESS/Trojan:10087-88"
        "slowdns:SlowDNS:53/udp"
        "fail2ban:Fail2Ban IDS:activo"
        "openvpn@server-tcp:OpenVPN TCP:1194"
    )
    for row in "${rows[@]}"; do
        IFS=':' read -r svc lbl port <<< "$row"
        printf "  %b  ${W}${BLD}%-24s${NC} ${DIM}%s${NC}\n" "$(dot $svc)" "$lbl" "$port"
    done
    echo ""
    echo -e "  $LINE"
    echo -e "  ${DIM}RAM  :${NC} ${W}${BLD}$(free -h|awk '/^Mem/{print $3" / "$2}')${NC}"
    echo -e "  ${DIM}Disco:${NC} ${W}${BLD}$(df -h/|awk 'NR==2{print $3" / "$2" ("$5")"}')${NC}"
    echo -e "  ${DIM}CPU  :${NC} ${W}${BLD}$(top -bn1|grep 'load average'|awk '{print $10,$11,$12}')${NC}"
    echo ""
    pause
}

# ── CONFIGURACIÓN ───────────────────────────────────────
config_menu() {
    while true; do
        banner
        echo -e "  ${Y}${BLD}CONFIGURACIÓN DEL SISTEMA${NC} $LINE"
        echo ""
        echo -e "  ${R}${BLD}[01]${NC}  ${W}${BLD}Configurar Dominio + SSL${NC}  ${DIM}Let's Encrypt automático${NC}"
        echo -e "  ${R}${BLD}[02]${NC}  ${W}${BLD}Ver Dominio Actual${NC}"
        echo -e "  ${R}${BLD}[03]${NC}  ${W}${BLD}Renovar Certificado SSL${NC}"
        echo -e "  ${R}${BLD}[04]${NC}  ${W}${BLD}Configurar Firewall UFW${NC}"
        echo -e "  ${R}${BLD}[05]${NC}  ${W}${BLD}Optimización BBR + CAKE${NC}  ${DIM}Máxima velocidad${NC}"
        echo -e "  ${R}${BLD}[06]${NC}  ${W}${BLD}Actualizar Sistema${NC}"
        echo -e "  ${R}${BLD}[07]${NC}  ${W}${BLD}Reiniciar Todos los Servicios${NC}"
        echo -e "  ${R}${BLD}[00]${NC}  ${W}${BLD}Regresar${NC}"
        echo ""
        echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"
        read -r o
        case $o in
            1|01) source "$MOD_DIR/config/setup.sh" && setup_domain ;;
            2|02) source "$MOD_DIR/config/setup.sh" && show_domain ;;
            3|03) source "$MOD_DIR/config/setup.sh" && renew_ssl ;;
            4|04) source "$MOD_DIR/config/setup.sh" && setup_firewall ;;
            5|05) source "$MOD_DIR/config/setup.sh" && setup_bbr ;;
            6|06) bar "Actualizando sistema" "apt-get update && apt-get upgrade -y"
                  ok "Sistema actualizado" ;;
            7|07) _restart_all ;;
            0|00) break ;;
            *)    echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.6 ;;
        esac
    done
}

_restart_all() {
    echo ""
    local svcs=("nginx" "xray" "v2ray" "hysteria" "dropbear" "badvpn-udpgw" "ssh" "fail2ban")
    for s in "${svcs[@]}"; do
        systemctl restart "$s" 2>/dev/null && ok "Reiniciado: $s" || true
    done
    sleep 1
}

# ── RED ─────────────────────────────────────────────────
net_menu() {
    banner
    echo -e "  ${Y}${BLD}HERRAMIENTAS DE RED${NC} $LINE"
    echo ""
    echo -e "  ${R}${BLD}[01]${NC}  ${W}${BLD}Prueba de velocidad${NC}"
    echo -e "  ${R}${BLD}[02]${NC}  ${W}${BLD}Ping a host externo${NC}"
    echo -e "  ${R}${BLD}[03]${NC}  ${W}${BLD}Tráfico en tiempo real${NC}"
    echo -e "  ${R}${BLD}[04]${NC}  ${W}${BLD}Ver puertos abiertos${NC}"
    echo -e "  ${R}${BLD}[05]${NC}  ${W}${BLD}Traceroute${NC}"
    echo -e "  ${R}${BLD}[00]${NC}  ${W}${BLD}Regresar${NC}"
    echo ""
    echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"
    read -r o
    case $o in
        1|01) apt-get install -y speedtest-cli -qq &>/dev/null; speedtest-cli ;;
        2|02) echo -ne "  ${W}${BLD}Host: ${NC}"; read -r h; ping -c 5 "$h" ;;
        3|03) vnstat -l 2>/dev/null || info "Instala: apt install vnstat" ;;
        4|04) ss -tulnp ;;
        5|05) echo -ne "  ${W}${BLD}Host: ${NC}"; read -r h; traceroute "$h" ;;
        0|00) return ;;
    esac
    pause
}

# ── LOGS ────────────────────────────────────────────────
log_menu() {
    banner
    echo -e "  ${Y}${BLD}LOGS Y MONITOREO${NC} $LINE"
    echo ""
    echo -e "  ${R}${BLD}[01]${NC}  ${W}${BLD}Log SSH${NC}"
    echo -e "  ${R}${BLD}[02]${NC}  ${W}${BLD}Log Xray / V2Ray${NC}"
    echo -e "  ${R}${BLD}[03]${NC}  ${W}${BLD}Log Nginx${NC}"
    echo -e "  ${R}${BLD}[04]${NC}  ${W}${BLD}Log Hysteria${NC}"
    echo -e "  ${R}${BLD}[05]${NC}  ${W}${BLD}Monitor htop${NC}"
    echo -e "  ${R}${BLD}[00]${NC}  ${W}${BLD}Regresar${NC}"
    echo ""
    echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"
    read -r o
    case $o in
        1|01) tail -60 /var/log/auth.log | grep sshd ;;
        2|02) tail -60 /var/log/xray/access.log 2>/dev/null \
              || tail -60 /var/log/v2ray/access.log 2>/dev/null ;;
        3|03) tail -60 /var/log/nginx/access.log 2>/dev/null ;;
        4|04) journalctl -u hysteria -n 60 --no-pager 2>/dev/null ;;
        5|05) htop ;;
        0|00) return ;;
    esac
    pause
}

# ── BACKUP ──────────────────────────────────────────────
backup_menu() {
    banner
    echo -e "  ${Y}${BLD}BACKUP Y RESTAURACIÓN${NC} $LINE"
    echo ""
    echo -e "  ${R}${BLD}[01]${NC}  ${W}${BLD}Crear Backup${NC}"
    echo -e "  ${R}${BLD}[02]${NC}  ${W}${BLD}Restaurar Backup${NC}"
    echo -e "  ${R}${BLD}[03]${NC}  ${W}${BLD}Ver Backups${NC}"
    echo -e "  ${R}${BLD}[00]${NC}  ${W}${BLD}Regresar${NC}"
    echo ""
    echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"
    read -r o
    case $o in
        1|01)
            mkdir -p /root/dz-backups
            local f="/root/dz-backups/dz-backup-$(date +%Y%m%d-%H%M%S).tar.gz"
            bar "Creando backup" "tar -czf '$f' '$BASE_DIR' /etc/xray /etc/v2ray /etc/nginx /etc/hysteria '$MOD_DIR' 2>/dev/null"
            ok "Backup guardado: $f" ;;
        2|02)
            ls -lh /root/dz-backups/ 2>/dev/null
            echo -ne "\n  ${W}${BLD}Archivo: ${NC}"; read -r fn
            [[ -f "/root/dz-backups/$fn" ]] \
                && { bar "Restaurando" "tar -xzf '/root/dz-backups/$fn' -C /"; ok "Restaurado."; } \
                || err "No encontrado." ;;
        3|03) echo ""; ls -lh /root/dz-backups/ 2>/dev/null || info "Sin backups." ;;
        0|00) return ;;
    esac
    pause
}

# ── INSTALAR TODO ────────────────────────────────────────
install_all() {
    banner
    echo -e "  ${Y}${BLD}★ INSTALACIÓN COMPLETA DE TODOS LOS PROTOCOLOS${NC}"
    echo -e "  $LINE"
    echo ""

    local steps=(
        "Actualizando sistema"
        "Instalando dependencias"
        "SSH WebSocket :80"
        "SSH WebSocket :443 SSL"
        "Hysteria v2 + obfs"
        "UDP Custom BadVPN"
        "Xray V2Ray VMess"
        "Xray VLESS WS"
        "Xray Trojan WS"
        "Configurando Nginx SSL"
        "Firewall UFW"
        "Optimización BBR"
    )

    local total=${#steps[@]}
    for ((i=0; i<total; i++)); do
        local pct=$(( (i+1)*100/total ))
        local filled=$(( (i+1)*34/total ))
        local bar="" empty=""
        for ((j=0; j<filled; j++));       do bar+="${Y}█${NC}"; done
        for ((j=filled; j<34; j++));      do empty+="${DIM}░${NC}"; done
        echo -e "\r  ${DIM}[${NC}${bar}${empty}${DIM}]${NC} ${W}${BLD}${pct}%%${NC}  ${DIM}${steps[$i]}${NC}"
        sleep 0.35
    done

    echo ""
    source "$MOD_DIR/install/base.sh" 2>/dev/null
    bar "Instalando dependencias base" "install_base_deps"

    source "$MOD_DIR/protocols/ssh-ws.sh" 2>/dev/null
    bar "SSH WebSocket :80" "install_ssh_ws 80"
    bar "SSH WebSocket :443" "install_ssh_ws 443"

    source "$MOD_DIR/protocols/hysteria2.sh" 2>/dev/null
    bar "Hysteria v2 + obfs" "install_hysteria2"

    source "$MOD_DIR/protocols/udp.sh" 2>/dev/null
    bar "UDP Custom BadVPN" "install_badvpn"

    source "$MOD_DIR/protocols/xray.sh" 2>/dev/null
    bar "V2Ray VMess" "install_vmess"
    bar "VLESS WS + TLS" "install_vless"
    bar "Trojan-GFW" "install_trojan"

    source "$MOD_DIR/config/setup.sh" 2>/dev/null
    bar "Firewall UFW" "setup_firewall"
    bar "Optimización BBR" "setup_bbr"

    echo ""
    echo -e "  ${GB}${BLD}╔══════════════════════════════════════════╗${NC}"
    echo -e "  ${GB}${BLD}║  ✔  INSTALACIÓN COMPLETADA CON ÉXITO    ║${NC}"
    echo -e "  ${GB}${BLD}╚══════════════════════════════════════════╝${NC}"
    echo ""
    info "Configura tu dominio en: ${Y}${BLD}Configuración → [01]${NC}"
    pause
}

# ── INICIO ──────────────────────────────────────────────
check_root
mkdir -p "$BASE_DIR" "$CFG_DIR" "$USR_DIR"
load_cfg
main_menu
