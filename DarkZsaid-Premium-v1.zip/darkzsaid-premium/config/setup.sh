#!/bin/bash
# ── CONFIGURACIÓN: Dominio + SSL + Nginx + Firewall + BBR ─

# ── CONFIGURAR DOMINIO + SSL ──────────────────────────────
setup_domain() {
    banner
    echo -e "  ${Y}${BLD}CONFIGURAR DOMINIO + SSL${NC} $LINE"
    echo ""
    echo -e "  ${W}${BLD}Requisito:${NC} ${DIM}El dominio debe apuntar a la IP de este servidor${NC}"
    echo ""
    echo -ne "  ${Y}${BLD}❯ Dominio (ej: vpn.tuservidor.com): ${NC}"
    read -r DOMAIN
    [[ -z "$DOMAIN" ]] && { err "Dominio inválido."; sleep 1; return; }

    echo -ne "  ${Y}${BLD}❯ Email para Let's Encrypt: ${NC}"
    read -r EMAIL
    [[ -z "$EMAIL" ]] && EMAIL="admin@${DOMAIN}"

    # Guardar en config
    mkdir -p "$CFG_DIR"
    # Actualizar o crear panel.conf
    if [[ -f "$CFG_DIR/panel.conf" ]]; then
        sed -i '/^DOMAIN=/d; /^EMAIL=/d' "$CFG_DIR/panel.conf"
    fi
    echo "DOMAIN=\"$DOMAIN\""  >> "$CFG_DIR/panel.conf"
    echo "EMAIL=\"$EMAIL\""    >> "$CFG_DIR/panel.conf"

    bar "Instalando Nginx + Certbot" \
        "apt-get install -y nginx certbot python3-certbot-nginx -qq"

    # ── Nginx básico para que certbot verifique ───────
    _nginx_base_config "$DOMAIN"

    bar "Obteniendo certificado SSL" \
        "certbot --nginx -d '$DOMAIN' --non-interactive --agree-tos \
        -m '$EMAIL' --redirect &>/tmp/certbot.log"

    if [[ -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]]; then
        ok "Certificado SSL obtenido para $DOMAIN"
        bar "Configurando Nginx SSL completo" "_nginx_ssl_config '$DOMAIN'"
        bar "Guardando renovación automática" \
            "(crontab -l 2>/dev/null; echo '0 3 * * * certbot renew --quiet && systemctl reload nginx') | sort -u | crontab -"
    else
        err "Error obteniendo certificado. Verifica que el DNS del dominio apunte a este servidor."
        cat /tmp/certbot.log 2>/dev/null | tail -5
        sleep 3
        return 1
    fi

    echo ""
    echo -e "  ${Y}${BLD}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "  ${Y}${BLD}║  ✔  DOMINIO Y SSL CONFIGURADOS                  ║${NC}"
    echo -e "  ${Y}${BLD}╠══════════════════════════════════════════════════╣${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Dominio :${NC} ${W}${BLD}$DOMAIN${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}SSL     :${NC} ${GB}${BLD}Let's Encrypt (válido 90 días)${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Renova  :${NC} ${W}${BLD}Automático (cron 3am)${NC}"
    echo -e "  ${Y}${BLD}╚══════════════════════════════════════════════════╝${NC}"
    pause
}

show_domain() {
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    echo ""
    if [[ -n "$DOMAIN" ]]; then
        ok "Dominio actual: $DOMAIN"
        if [[ -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]]; then
            local exp
            exp=$(openssl x509 -enddate -noout \
                  -in "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" 2>/dev/null \
                  | cut -d'=' -f2)
            ok "SSL válido hasta: $exp"
        else
            err "Certificado SSL no encontrado"
        fi
    else
        info "No hay dominio configurado. Usa la opción [01]"
    fi
    pause
}

renew_ssl() {
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    [[ -z "$DOMAIN" ]] && { err "No hay dominio configurado."; pause; return; }
    bar "Renovando certificado SSL" "certbot renew --quiet && systemctl reload nginx"
    ok "Certificado renovado."
    pause
}

# ── NGINX BASE (para certbot) ─────────────────────────
_nginx_base_config() {
    local DOM="$1"
    rm -f /etc/nginx/sites-enabled/default 2>/dev/null
    mkdir -p /etc/nginx/conf.d

    cat > "/etc/nginx/sites-available/$DOM" <<EOF
server {
    listen 80;
    server_name $DOM;
    root /var/www/html;
    location / { return 200 'DarkZsaid Premium'; add_header Content-Type text/plain; }
}
EOF
    ln -sf "/etc/nginx/sites-available/$DOM" /etc/nginx/sites-enabled/
    nginx -t &>/dev/null && systemctl reload nginx &>/dev/null
}

# ── NGINX SSL COMPLETO con todos los paths ────────────
_nginx_ssl_config() {
    local DOM="$1"
    local CERT="/etc/letsencrypt/live/$DOM/fullchain.pem"
    local KEY="/etc/letsencrypt/live/$DOM/privkey.pem"

    cat > /etc/nginx/conf.d/dz-vpn.conf <<EOF
# ── DarkZsaid Premium - VPN Proxy ────────────────────
server {
    listen 443 ssl http2;
    server_name $DOM;

    ssl_certificate     $CERT;
    ssl_certificate_key $KEY;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers on;
    ssl_session_cache   shared:SSL:10m;
    ssl_session_timeout 10m;

    # Camouflage
    location / {
        return 200 '<!DOCTYPE html><html><body><h1>Welcome</h1></body></html>';
        add_header Content-Type text/html;
    }

    # SSH WebSocket
    location /ssh {
        proxy_pass          http://127.0.0.1:80;
        proxy_http_version  1.1;
        proxy_set_header    Upgrade    \$http_upgrade;
        proxy_set_header    Connection "upgrade";
        proxy_set_header    Host       \$host;
        proxy_read_timeout  86400;
    }

    # Espacio para rutas dinámicas de V2Ray/VLESS/Trojan
    # (se agregan automáticamente al instalar cada protocolo)
}

server {
    listen 80;
    server_name $DOM;
    return 301 https://\$host\$request_uri;
}
EOF

    nginx -t &>/dev/null && systemctl reload nginx &>/dev/null
}

# ── FIREWALL UFW ──────────────────────────────────────
setup_firewall() {
    bar "Instalando UFW" "apt-get install -y ufw -qq"
    bar "Aplicando reglas" "_apply_firewall_rules"
    echo ""
    ok "Firewall configurado"
    ufw status verbose 2>/dev/null | head -20
    pause
}

_apply_firewall_rules() {
    ufw --force reset &>/dev/null
    ufw default deny incoming &>/dev/null
    ufw default allow outgoing &>/dev/null

    # SSH y panel
    ufw allow 22/tcp   comment "OpenSSH"        &>/dev/null
    ufw allow 109/tcp  comment "Dropbear"       &>/dev/null
    ufw allow 143/tcp  comment "Dropbear alt"   &>/dev/null
    # Web
    ufw allow 80/tcp   comment "HTTP/WS"        &>/dev/null
    ufw allow 443/tcp  comment "HTTPS/SSL"      &>/dev/null
    ufw allow 8443/tcp comment "Reality"        &>/dev/null
    # Xray
    ufw allow 10086/tcp comment "VMess"         &>/dev/null
    ufw allow 10087/tcp comment "VLESS"         &>/dev/null
    ufw allow 10088/tcp comment "Trojan"        &>/dev/null
    # UDP
    ufw allow 36712/udp comment "Hysteria"      &>/dev/null
    ufw allow 10000:65000/udp comment "Hy2-Hop" &>/dev/null
    ufw allow 53/udp   comment "SlowDNS"        &>/dev/null
    ufw allow 7300/tcp comment "BadVPN"         &>/dev/null
    # OpenVPN
    ufw allow 1194/tcp comment "OpenVPN TCP"    &>/dev/null
    ufw allow 1194/udp comment "OpenVPN UDP"    &>/dev/null
    ufw allow 1195/udp comment "OpenVPN UDP2"   &>/dev/null

    ufw --force enable &>/dev/null
}

# ── OPTIMIZACIÓN BBR + CAKE ───────────────────────────
setup_bbr() {
    bar "Activando BBR + CAKE" "_apply_bbr"
    ok "BBR + CAKE activados"
    echo -e "  ${DIM}Algoritmo TCP :${NC} ${W}${BLD}BBR${NC}"
    echo -e "  ${DIM}Queue Disc    :${NC} ${W}${BLD}CAKE${NC}"
    pause
}

_apply_bbr() {
    modprobe tcp_bbr 2>/dev/null

    # Limpiar entradas duplicadas
    sed -i '/net.core.default_qdisc/d' /etc/sysctl.conf
    sed -i '/net.ipv4.tcp_congestion_control/d' /etc/sysctl.conf
    sed -i '/net.ipv4.tcp_fastopen/d' /etc/sysctl.conf
    sed -i '/net.ipv4.ip_forward/d' /etc/sysctl.conf

    cat >> /etc/sysctl.conf <<'EOF'

# DarkZsaid Premium - Network Optimization
net.core.default_qdisc              = cake
net.ipv4.tcp_congestion_control     = bbr
net.ipv4.tcp_fastopen               = 3
net.ipv4.ip_forward                 = 1
net.ipv6.conf.all.forwarding        = 1
net.ipv4.tcp_slow_start_after_idle  = 0
net.ipv4.tcp_mtu_probing            = 1
net.ipv4.tcp_syncookies             = 1
net.ipv4.tcp_tw_reuse               = 1
net.core.rmem_max                   = 67108864
net.core.wmem_max                   = 67108864
net.ipv4.tcp_rmem                   = 4096 87380 67108864
net.ipv4.tcp_wmem                   = 4096 65536 67108864
net.core.netdev_max_backlog         = 30000
EOF

    sysctl -p &>/dev/null
}
