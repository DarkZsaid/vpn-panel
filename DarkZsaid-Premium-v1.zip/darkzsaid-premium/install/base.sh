#!/bin/bash
# ── BASE DEPENDENCIES ─────────────────────────────────────

install_base_deps() {
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y -qq
    apt-get install -y \
        curl wget unzip tar git jq bc socat \
        openssl ca-certificates gnupg2 \
        python3 python3-pip \
        nginx certbot python3-certbot-nginx \
        dropbear stunnel4 \
        fail2ban ufw \
        qrencode uuid-runtime \
        net-tools iproute2 iptables iptables-persistent \
        build-essential cmake \
        vnstat cron \
        --no-install-recommends -qq 2>/dev/null

    # IP forward
    echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-dz.conf
    sysctl -p /etc/sysctl.d/99-dz.conf &>/dev/null

    # Fail2Ban básico
    systemctl enable --now fail2ban &>/dev/null
}
