#!/bin/bash
# ── GESTIÓN COMPLETA DE USUARIOS ──────────────────────────

# ── CREAR USUARIO ─────────────────────────────────────────
create_user() {
    banner
    echo -e "  ${Y}${BLD}CREAR USUARIO${NC} $LINE"
    echo ""
    echo -ne "  ${Y}${BLD}❯ Nombre de usuario: ${NC}"; read -r USER
    [[ -z "$USER" ]] && { err "Nombre inválido."; sleep 1; return; }

    if grep -q "^${USER}:" "$DB" 2>/dev/null; then
        err "El usuario '$USER' ya existe."; sleep 2; return
    fi

    echo -ne "  ${Y}${BLD}❯ Contraseña (vacío=auto): ${NC}"; read -r PASS
    [[ -z "$PASS" ]] && PASS=$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | head -c 12)

    echo -ne "  ${Y}${BLD}❯ Días de expiración [30]: ${NC}"; read -r DAYS
    [[ -z "$DAYS" ]] && DAYS=30

    echo -ne "  ${Y}${BLD}❯ Máx. conexiones [2]: ${NC}"; read -r MAXC
    [[ -z "$MAXC" ]] && MAXC=2

    echo ""
    echo -e "  ${DIM}── Protocolos ───────────────────────────────────${NC}"
    echo -e "  ${R}${BLD}[1]${NC} ${W}${BLD}SSH + WebSocket${NC}"
    echo -e "  ${R}${BLD}[2]${NC} ${W}${BLD}V2Ray VMess${NC}"
    echo -e "  ${R}${BLD}[3]${NC} ${W}${BLD}VLESS + Trojan${NC}"
    echo -e "  ${R}${BLD}[4]${NC} ${W}${BLD}Hysteria v2${NC}"
    echo -e "  ${R}${BLD}[5]${NC} ${W}${BLD}Todos${NC}"
    echo -ne "  ${Y}${BLD}❯ Protocolo [5]: ${NC}"; read -r PROTO
    [[ -z "$PROTO" ]] && PROTO=5

    local EXP CREATED UUID
    EXP=$(date -d "+${DAYS} days" '+%Y-%m-%d')
    CREATED=$(date '+%Y-%m-%d')
    UUID=$(cat /proc/sys/kernel/random/uuid)

    bar "Creando usuario del sistema" \
        "useradd -m -s /bin/bash -e '$EXP' '$USER' &>/dev/null; \
         echo '${USER}:${PASS}' | chpasswd"

    # Agregar a protocolos
    [[ "$PROTO" =~ [245] ]] && _add_to_vmess "$USER" "$UUID"
    [[ "$PROTO" =~ [345] ]] && _add_to_vless "$USER" "$UUID"
    [[ "$PROTO" =~ [45]  ]] && _add_to_hy2 "$USER" "$PASS"

    # Guardar en DB
    mkdir -p "$(dirname "$DB")"
    echo "${USER}:${PASS}:${EXP}:${MAXC}:${CREATED}:active:${UUID}:${PROTO}" >> "$DB"

    echo ""
    echo -e "  ${Y}${BLD}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "  ${Y}${BLD}║  ✔  USUARIO CREADO                              ║${NC}"
    echo -e "  ${Y}${BLD}╠══════════════════════════════════════════════════╣${NC}"
    _print_user_info "$USER"
    echo -e "  ${Y}${BLD}╚══════════════════════════════════════════════════╝${NC}"
    pause
}

# ── INFO DE USUARIO ───────────────────────────────────────
_print_user_info() {
    local U="$1"
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    local HOST="${DOMAIN:-$(curl -s --max-time 3 ifconfig.me 2>/dev/null)}"

    local LINE
    LINE=$(grep "^${U}:" "$DB" 2>/dev/null | head -1)
    [[ -z "$LINE" ]] && { err "Usuario no encontrado."; return; }

    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"

    local today; today=$(date '+%Y-%m-%d')
    local dias_rest
    dias_rest=$(( ( $(date -d "$exp" +%s) - $(date -d "$today" +%s) ) / 86400 ))

    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Usuario    :${NC} ${W}${BLD}$u${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Contraseña :${NC} ${W}${BLD}$pass${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Vence      :${NC} ${W}${BLD}$exp${NC} ${DIM}(${dias_rest} días)${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Max conn.  :${NC} ${W}${BLD}$maxc${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Estado     :${NC} ${W}${BLD}$status${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}UUID       :${NC} ${W}${BLD}$uuid${NC}"
    echo -e "  ${Y}${BLD}║${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}SSH Host   :${NC} ${W}${BLD}$HOST${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}WS Puertos :${NC} ${W}${BLD}80 / 443${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Payload    :${NC} ${W}GET / HTTP/1.1[crlf]Host: $HOST[crlf]Upgrade: websocket[crlf][crlf]${NC}"

    if [[ "$proto" =~ [245] ]]; then
        local vmess_path
        vmess_path=$(cat /etc/xray/vmess-path.txt 2>/dev/null || echo "/v2ray")
        local VJSON="{\"v\":\"2\",\"ps\":\"${u}-DZ\",\"add\":\"${HOST}\",\"port\":\"443\",\"id\":\"${uuid}\",\"aid\":\"0\",\"net\":\"ws\",\"path\":\"${vmess_path}\",\"tls\":\"tls\"}"
        local VLINK="vmess://$(echo -n "$VJSON" | base64 -w0)"
        echo -e "  ${Y}${BLD}║${NC}  ${DIM}VMess Link :${NC}"
        echo -e "  ${Y}${BLD}║${NC}  ${W}${BLD}$VLINK${NC}"
    fi
    if [[ "$proto" =~ [345] ]]; then
        local vless_path
        vless_path=$(cat /etc/xray/vless-path.txt 2>/dev/null || echo "/vless")
        local VLESSLINK="vless://${uuid}@${HOST}:443?encryption=none&security=tls&type=ws&path=${vless_path}&sni=${HOST}#${u}-DZ"
        echo -e "  ${Y}${BLD}║${NC}  ${DIM}VLESS Link :${NC}"
        echo -e "  ${Y}${BLD}║${NC}  ${W}${BLD}$VLESSLINK${NC}"
    fi
    if [[ "$proto" =~ [45] ]]; then
        local hy2_obfs
        hy2_obfs=$(cat /etc/hysteria/obfs.txt 2>/dev/null || echo "")
        local HY2LINK="hysteria2://${pass}@${HOST}:10000-65000?obfs=salamander&obfs-password=${hy2_obfs}&insecure=1#${u}-DZ"
        echo -e "  ${Y}${BLD}║${NC}  ${DIM}Hysteria2  :${NC}"
        echo -e "  ${Y}${BLD}║${NC}  ${W}${BLD}$HY2LINK${NC}"
    fi
}

# ── LISTAR USUARIOS ───────────────────────────────────────
list_users() {
    banner
    echo -e "  ${Y}${BLD}USUARIOS ACTIVOS${NC} $LINE"
    echo ""

    if [[ ! -f "$DB" ]] || [[ ! -s "$DB" ]]; then
        info "No hay usuarios registrados."
        pause; return
    fi

    printf "  ${Y}${BLD}%-16s %-14s %-6s %-10s %-8s${NC}\n" \
        "USUARIO" "VENCIMIENTO" "DIAS" "ESTADO" "PROTO"
    echo -e "  ${DIM}────────────────────────────────────────────────${NC}"

    local today; today=$(date '+%Y-%m-%d')
    while IFS=':' read -r u pass exp maxc created status uuid proto; do
        local dias=$(( ( $(date -d "$exp" +%s 2>/dev/null || echo 0) - $(date -d "$today" +%s) ) / 86400 ))
        local col
        if   [[ "$status" == "blocked" ]]; then col="${R}${BLD}"
        elif (( dias <= 3 ));              then col="${YB}"
        else                                    col="${W}${BLD}"; fi
        printf "  ${col}%-16s %-14s %-6s %-10s P%-8s${NC}\n" \
            "$u" "$exp" "${dias}d" "$status" "$proto"
    done < "$DB"

    echo ""
    echo -e "  ${DIM}Total: $(wc -l < "$DB") usuario(s)${NC}"
    pause
}

# ── EDITAR USUARIO ────────────────────────────────────────
edit_user() {
    banner
    echo -e "  ${Y}${BLD}EDITAR USUARIO${NC} $LINE"
    echo ""
    _list_simple
    echo -ne "  ${Y}${BLD}❯ Usuario: ${NC}"; read -r U
    [[ -z "$U" ]] && return

    local LINE
    LINE=$(grep "^${U}:" "$DB" 2>/dev/null | head -1)
    [[ -z "$LINE" ]] && { err "No encontrado."; sleep 2; return; }

    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"

    echo ""
    echo -e "  ${DIM}Datos de $u → pass: $pass | exp: $exp | conn: $maxc${NC}"
    echo ""
    echo -e "  ${R}${BLD}[1]${NC} ${W}${BLD}Cambiar contraseña${NC}"
    echo -e "  ${R}${BLD}[2]${NC} ${W}${BLD}Cambiar vencimiento${NC}"
    echo -e "  ${R}${BLD}[3]${NC} ${W}${BLD}Cambiar máx. conexiones${NC}"
    echo ""
    echo -ne "  ${Y}${BLD}❯ Opción: ${NC}"; read -r OP

    case $OP in
        1) echo -ne "  ${W}${BLD}Nueva contraseña: ${NC}"; read -r NP
           [[ -z "$NP" ]] && NP=$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | head -c 12)
           echo "$u:$NP" | chpasswd
           sed -i "s|^${u}:${pass}:|${u}:${NP}:|" "$DB"
           ok "Contraseña cambiada a: $NP" ;;
        2) echo -ne "  ${W}${BLD}Días desde hoy: ${NC}"; read -r D
           local NE; NE=$(date -d "+${D} days" '+%Y-%m-%d')
           chage -E "$NE" "$u" 2>/dev/null
           sed -i "s|^${u}:${pass}:${exp}:|${u}:${pass}:${NE}:|" "$DB"
           ok "Vencimiento: $NE" ;;
        3) echo -ne "  ${W}${BLD}Nuevo límite: ${NC}"; read -r NC2
           sed -i "s|:${exp}:${maxc}:|:${exp}:${NC2}:|" "$DB"
           ok "Límite: $NC2 conexiones" ;;
    esac
    sleep 2
}

# ── ELIMINAR USUARIO ──────────────────────────────────────
delete_user() {
    _list_simple
    echo -ne "  ${Y}${BLD}❯ Usuario a eliminar: ${NC}"; read -r U
    [[ -z "$U" ]] && return

    if ! grep -q "^${U}:" "$DB" 2>/dev/null; then
        err "No encontrado."; sleep 2; return
    fi

    echo -ne "  ${RB}¿Confirmar eliminación de '$U'? [s/N]: ${NC}"; read -r C
    [[ "${C,,}" != "s" ]] && return

    bar "Eliminando usuario" \
        "pkill -u '$U' 2>/dev/null; userdel -r '$U' 2>/dev/null; \
        sed -i '/^${U}:/d' '$DB'"
    ok "Usuario '$U' eliminado."
    sleep 1
}

# ── RENOVAR ───────────────────────────────────────────────
renew_user() {
    _list_simple
    echo -ne "  ${Y}${BLD}❯ Usuario: ${NC}"; read -r U
    echo -ne "  ${Y}${BLD}❯ Días a agregar: ${NC}"; read -r D

    local LINE; LINE=$(grep "^${U}:" "$DB" 2>/dev/null | head -1)
    [[ -z "$LINE" ]] && { err "No encontrado."; sleep 2; return; }
    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"

    local NE; NE=$(date -d "$exp +${D} days" '+%Y-%m-%d' 2>/dev/null \
                || date -d "+${D} days" '+%Y-%m-%d')
    chage -E "$NE" "$U" 2>/dev/null
    sed -i "s|:${exp}:|:${NE}:|g" "$DB"
    ok "Renovado hasta: $NE"
    sleep 2
}

# ── BLOQUEAR/DESBLOQUEAR ─────────────────────────────────
toggle_user() {
    _list_simple
    echo -ne "  ${Y}${BLD}❯ Usuario: ${NC}"; read -r U

    local LINE; LINE=$(grep "^${U}:" "$DB" 2>/dev/null | head -1)
    [[ -z "$LINE" ]] && { err "No encontrado."; sleep 2; return; }
    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"

    if [[ "$status" == "active" ]]; then
        usermod -L "$U" 2>/dev/null
        pkill -u "$U" 2>/dev/null
        sed -i "s|:active:|:blocked:|" "$DB"
        err "Usuario $U bloqueado."
    else
        usermod -U "$U" 2>/dev/null
        sed -i "s|:blocked:|:active:|" "$DB"
        ok "Usuario $U desbloqueado."
    fi
    sleep 2
}

# ── CONEXIONES ACTIVAS ────────────────────────────────────
active_conns() {
    banner
    echo -e "  ${Y}${BLD}CONEXIONES ACTIVAS${NC} $LINE"
    echo ""
    echo -e "  ${DIM}── SSH ──────────────────────────────────────────${NC}"
    who 2>/dev/null | awk '{printf "  %-12s %s %s\n", $1, $3, $4}' | head -20
    echo ""
    echo -e "  ${DIM}── Resumen por usuario ─────────────────────────${NC}"
    ss -tnp 2>/dev/null | grep -E "sshd|dropbear" | \
        awk '{print $4}' | sort | uniq -c | sort -rn | head -10 | \
        awk '{printf "  %s conexiones → %s\n", $1, $2}'
    echo ""
    pause
}

# ── EXPIRADOS ─────────────────────────────────────────────
expired_users() {
    banner
    echo -e "  ${Y}${BLD}USUARIOS EXPIRADOS${NC} $LINE"
    echo ""

    local today; today=$(date '+%Y-%m-%d')
    local found=0

    while IFS=':' read -r u pass exp maxc created status uuid proto; do
        if [[ "$exp" < "$today" ]]; then
            echo -e "  ${R}${BLD}●${NC} ${W}${BLD}$u${NC} ${DIM}expiró el $exp${NC}"
            found=1
        fi
    done < "$DB" 2>/dev/null

    [[ $found -eq 0 ]] && ok "No hay usuarios expirados."
    echo ""
    pause
}

# ── GENERAR QR ────────────────────────────────────────────
gen_qr() {
    _list_simple
    echo -ne "  ${Y}${BLD}❯ Usuario para QR: ${NC}"; read -r U

    local LINE; LINE=$(grep "^${U}:" "$DB" 2>/dev/null | head -1)
    [[ -z "$LINE" ]] && { err "No encontrado."; sleep 2; return; }

    banner
    echo -e "  ${Y}${BLD}QR - $U${NC} $LINE"
    echo ""
    echo -e "  ${Y}${BLD}╔══════════════════════════════════════════════════╗${NC}"
    _print_user_info "$U"
    echo -e "  ${Y}${BLD}╚══════════════════════════════════════════════════╝${NC}"
    echo ""
    pause
}

# ── HELPERS ───────────────────────────────────────────────
_list_simple() {
    echo ""
    echo -e "  ${DIM}Usuarios disponibles:${NC}"
    [[ -f "$DB" ]] && cut -d':' -f1 "$DB" | while read -r u; do
        echo -e "  ${Y}›${NC} ${W}${BLD}$u${NC}"
    done || info "Sin usuarios."
    echo ""
}

_add_to_vmess() {
    local U="$1" UUID="$2"
    local CONF="/etc/xray/config.json"
    [[ ! -f "$CONF" ]] && return
    python3 - <<PYEOF 2>/dev/null
import json
with open("$CONF") as f: c = json.load(f)
for inb in c.get("inbounds",[]):
    if inb.get("protocol") == "vmess":
        clients = inb["settings"]["clients"]
        if not any(cl.get("id") == "$UUID" for cl in clients):
            clients.append({"id": "$UUID", "alterId": 0})
with open("$CONF","w") as f: json.dump(c,f,indent=2)
PYEOF
    systemctl restart xray &>/dev/null
}

_add_to_vless() {
    local U="$1" UUID="$2"
    local CONF="/etc/xray/config.json"
    [[ ! -f "$CONF" ]] && return
    python3 - <<PYEOF 2>/dev/null
import json
with open("$CONF") as f: c = json.load(f)
for inb in c.get("inbounds",[]):
    if inb.get("protocol") in ["vless","trojan"]:
        clients = inb["settings"]["clients"]
        if not any(cl.get("id") == "$UUID" for cl in clients):
            clients.append({"id": "$UUID", "level": 0})
with open("$CONF","w") as f: json.dump(c,f,indent=2)
PYEOF
    systemctl restart xray &>/dev/null
}

_add_to_hy2() {
    local U="$1" PASS="$2"
    local CONF="/etc/hysteria/config.yaml"
    [[ ! -f "$CONF" ]] && return
    # Para Hysteria v2 con múltiples usuarios, cambiar a userpass
    if ! grep -q "userpass:" "$CONF"; then
        sed -i '/^auth:/,/^[^ ]/{ /password:/d }' "$CONF"
        sed -i '/^auth:/a\  type: userpass\n  userpass:\n    '"$U"': "'"$PASS"'"' "$CONF"
    else
        sed -i "/userpass:/a\\    $U: \"$PASS\"" "$CONF"
    fi
    systemctl restart hysteria &>/dev/null
}
