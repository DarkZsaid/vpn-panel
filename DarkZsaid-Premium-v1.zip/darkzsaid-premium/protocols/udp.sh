#!/bin/bash
# ── UDP CUSTOM (BadVPN) + SlowDNS ─────────────────────────

UDPGW_PORT=7300

install_badvpn() {
    bar "Instalando dependencias" "apt-get install -y cmake build-essential git -qq"

    # ── Intentar compilar ────────────────────────────
    cd /tmp && rm -rf badvpn
    git clone --depth=1 https://github.com/ambrop72/badvpn.git &>/dev/null

    if [[ -d /tmp/badvpn ]]; then
        bar "Compilando BadVPN UDPGW" \
            "cd /tmp/badvpn && mkdir -p build && cd build \
            && cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 &>/dev/null \
            && make &>/dev/null \
            && install -m755 udpgw/badvpn-udpgw /usr/local/bin/"
        cd /tmp && rm -rf badvpn
    fi

    # ── Fallback: binario precompilado ───────────────
    if [[ ! -f /usr/local/bin/badvpn-udpgw ]]; then
        bar "Descargando binario BadVPN" \
            "wget -q -O /usr/local/bin/badvpn-udpgw \
            'https://github.com/daybreakersx/premscript/raw/master/badvpn-udpgw64' \
            && chmod +x /usr/local/bin/badvpn-udpgw"
    fi

    # ── Servicio systemd ─────────────────────────────
    cat > /etc/systemd/system/badvpn-udpgw.service <<EOF
[Unit]
Description=DarkZsaid Premium - BadVPN UDPGW
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/badvpn-udpgw \\
    --listen-addr 127.0.0.1:$UDPGW_PORT \\
    --max-clients 1000 \\
    --max-connections-for-client 100
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    bar "Iniciando UDP Custom" \
        "systemctl daemon-reload && systemctl enable --now badvpn-udpgw"

    echo ""
    ok "UDP Custom (BadVPN) instalado"
    echo -e "  ${DIM}Puerto UDPGW :${NC} ${W}${BLD}127.0.0.1:$UDPGW_PORT${NC}"
    echo -e "  ${DIM}Config cliente:${NC} ${W}${BLD}UDP Custom → 127.0.0.1:$UDPGW_PORT${NC}"
    pause
}

install_slowdns() {
    local ARCH
    case "$(uname -m)" in
        x86_64)  ARCH="amd64" ;;
        aarch64) ARCH="arm64" ;;
        *)       err "Arquitectura no soportada"; return 1 ;;
    esac

    mkdir -p /etc/slowdns

    # ── Descargar SlowDNS ────────────────────────────
    bar "Descargando SlowDNS" \
        "wget -q -O /usr/local/bin/slowdns \
        'https://github.com/helmiau/helmwrt/releases/latest/download/slowdns-linux-${ARCH}' \
        && chmod +x /usr/local/bin/slowdns"

    if [[ ! -f /usr/local/bin/slowdns ]]; then
        err "No se pudo descargar SlowDNS"; return 1
    fi

    # ── Generar claves ───────────────────────────────
    bar "Generando claves SlowDNS" \
        "/usr/local/bin/slowdns -gen-key 2>/dev/null > /etc/slowdns/keys.txt \
        || openssl genrsa 2048 2>/dev/null > /etc/slowdns/keys.txt"

    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    local NS_DOMAIN="${DOMAIN:-example.com}"

    # ── Servicio systemd ─────────────────────────────
    cat > /etc/systemd/system/slowdns.service <<EOF
[Unit]
Description=DarkZsaid Premium - SlowDNS
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/slowdns server \\
    -udp 0.0.0.0:53 \\
    -privkey /etc/slowdns/keys.txt \\
    -ns ns.$NS_DOMAIN
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    bar "Iniciando SlowDNS" \
        "systemctl daemon-reload && systemctl enable --now slowdns"

    echo ""
    ok "SlowDNS instalado"
    echo -e "  ${DIM}Nameserver :${NC} ${W}${BLD}ns.${NS_DOMAIN}${NC}"
    echo -e "  ${Y} ›${NC} ${W}${BLD}Configura el registro NS en tu dominio apuntando al servidor${NC}"
    pause
}
