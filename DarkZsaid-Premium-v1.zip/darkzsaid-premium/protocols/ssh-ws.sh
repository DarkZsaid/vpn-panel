#!/bin/bash
# ── SSH WEBSOCKET (Dropbear + Python WS Proxy) ────────────

install_ssh_ws() {
    local PORT="${1:-80}"
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"

    bar "Instalando Dropbear SSH" "apt-get install -y dropbear -qq"

    # ── Configurar Dropbear ──────────────────────────
    cat > /etc/default/dropbear <<'EOF'
NO_START=0
DROPBEAR_PORT=109
DROPBEAR_EXTRA_ARGS="-p 143"
DROPBEAR_BANNER="/etc/issue.net"
DROPBEAR_RECEIVE_WINDOW=65536
EOF

    cat > /etc/issue.net <<'EOF'

  ┌─────────────────────────────────────────┐
  │     ⚡ DARKZSAID PREMIUM SERVER          │
  │        Acceso Solo Autorizado            │
  └─────────────────────────────────────────┘

EOF

    # ── Proxy WebSocket en Python ────────────────────
    cat > /usr/local/bin/dz-ws-proxy.py <<'PYEOF'
#!/usr/bin/env python3
"""DarkZsaid Premium - SSH WebSocket Proxy"""
import socket, threading, select, os, sys

WS_PORT  = int(os.environ.get("WS_PORT", "80"))
SSH_HOST = "127.0.0.1"
SSH_PORT = int(os.environ.get("SSH_PORT", "109"))
BUFSIZE  = 65536

HANDSHAKE = (
    b"HTTP/1.1 101 Switching Protocols\r\n"
    b"Upgrade: websocket\r\n"
    b"Connection: Upgrade\r\n"
    b"\r\n"
)

def pipe(src, dst):
    try:
        while True:
            r, _, _ = select.select([src], [], [], 300)
            if not r:
                break
            d = src.recv(BUFSIZE)
            if not d:
                break
            dst.sendall(d)
    except Exception:
        pass
    finally:
        try: src.close()
        except: pass
        try: dst.close()
        except: pass

def handle(client):
    try:
        data = client.recv(BUFSIZE)
        if not data:
            client.close()
            return
        client.sendall(HANDSHAKE)
        remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        remote.connect((SSH_HOST, SSH_PORT))
        t1 = threading.Thread(target=pipe, args=(client, remote), daemon=True)
        t2 = threading.Thread(target=pipe, args=(remote, client), daemon=True)
        t1.start(); t2.start()
        t1.join(); t2.join()
    except Exception:
        try: client.close()
        except: pass

def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", WS_PORT))
    srv.listen(1024)
    sys.stdout.write(f"[DZ-WS] Puerto {WS_PORT} → SSH {SSH_PORT}\n")
    sys.stdout.flush()
    while True:
        try:
            client, _ = srv.accept()
            threading.Thread(target=handle, args=(client,), daemon=True).start()
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    main()
PYEOF
    chmod +x /usr/local/bin/dz-ws-proxy.py

    # ── Servicio systemd ─────────────────────────────
    cat > "/etc/systemd/system/dz-ws-${PORT}.service" <<EOF
[Unit]
Description=DarkZsaid Premium SSH WebSocket :${PORT}
After=network.target dropbear.service

[Service]
Type=simple
ExecStart=/usr/bin/python3 /usr/local/bin/dz-ws-proxy.py
Environment="WS_PORT=${PORT}"
Environment="SSH_PORT=109"
Restart=always
RestartSec=3
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

    # Si es 443 y hay dominio, usar stunnel con SSL
    if [[ "$PORT" == "443" && -n "$DOMAIN" && \
          -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]]; then
        bar "Configurando SSL para puerto 443" "_setup_ws_ssl"
    fi

    bar "Iniciando SSH WebSocket :${PORT}" \
        "systemctl daemon-reload && systemctl enable --now dropbear \
        && systemctl enable --now 'dz-ws-${PORT}'"

    echo ""
    ok "SSH WebSocket instalado en puerto $PORT"
    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    echo -e "  ${DIM}Host      :${NC} ${W}${BLD}$HOST${NC}"
    echo -e "  ${DIM}Puerto WS :${NC} ${W}${BLD}$PORT${NC}"
    echo -e "  ${DIM}Payload   :${NC} ${W}${BLD}GET / HTTP/1.1[crlf]Host: $HOST[crlf]Upgrade: websocket[crlf][crlf]${NC}"
    pause
}

_setup_ws_ssl() {
    apt-get install -y stunnel4 -qq &>/dev/null
    cat > /etc/stunnel/stunnel.conf <<EOF
[dz-ssh-ssl]
accept  = 444
connect = 127.0.0.1:80
cert    = /etc/letsencrypt/live/${DOMAIN}/fullchain.pem
key     = /etc/letsencrypt/live/${DOMAIN}/privkey.pem
EOF
    systemctl enable --now stunnel4 &>/dev/null
}
