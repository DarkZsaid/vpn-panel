#!/bin/bash
# ── HYSTERIA v2 + obfs salamander + port hopping ────────

HY2_DIR="/etc/hysteria"
HY2_PORT=36712
HY2_PORT_MIN=10000
HY2_PORT_MAX=65000

install_hysteria2() {
    echo ""
    info "Instalando Hysteria v2 con obfs salamander..."

    # ── Detectar arquitectura ──────────────────────────
    local ARCH
    case "$(uname -m)" in
        x86_64)  ARCH="amd64" ;;
        aarch64) ARCH="arm64" ;;
        armv7l)  ARCH="armv7" ;;
        *)       err "Arquitectura no soportada: $(uname -m)"; return 1 ;;
    esac

    # ── Descargar binario Hysteria v2 ─────────────────
    bar "Descargando Hysteria v2" \
        "wget -q -O /usr/local/bin/hysteria \
        'https://github.com/apernet/hysteria/releases/latest/download/hysteria-linux-${ARCH}' \
        && chmod +x /usr/local/bin/hysteria"

    if [[ ! -f /usr/local/bin/hysteria ]]; then
        err "No se pudo descargar Hysteria v2"; return 1
    fi

    mkdir -p "$HY2_DIR"
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"

    # ── Generar contraseñas ────────────────────────────
    local AUTH_PASS OBFS_PASS
    AUTH_PASS=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)
    OBFS_PASS=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 20)

    echo "$AUTH_PASS"  > "$HY2_DIR/auth.txt"
    echo "$OBFS_PASS"  > "$HY2_DIR/obfs.txt"

    # ── Certificado TLS ────────────────────────────────
    local CERT KEY
    if [[ -n "$DOMAIN" && -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]]; then
        CERT="/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
        KEY="/etc/letsencrypt/live/$DOMAIN/privkey.pem"
        info "Usando certificado Let's Encrypt de $DOMAIN"
    else
        CERT="$HY2_DIR/hy2.crt"
        KEY="$HY2_DIR/hy2.key"
        bar "Generando certificado autofirmado" \
            "openssl req -x509 -nodes -newkey ec:<(openssl ecparam -name prime256v1) \
            -keyout '$KEY' -out '$CERT' -subj '/CN=darkzsaid' -days 3650 2>/dev/null"
        info "Certificado autofirmado (configura dominio para mejor compatibilidad)"
    fi

    # ── Configuración Hysteria v2 ──────────────────────
    cat > "$HY2_DIR/config.yaml" <<EOF
# DarkZsaid Premium - Hysteria v2
listen: :$HY2_PORT

tls:
  cert: $CERT
  key:  $KEY

obfs:
  type: salamander
  salamander:
    password: "$OBFS_PASS"

quic:
  initStreamReceiveWindow: 8388608
  maxStreamReceiveWindow:  8388608
  initConnReceiveWindow:   20971520
  maxConnReceiveWindow:    20971520
  maxIdleTimeout:          30s
  keepAlivePeriod:         10s
  disablePathMTUDiscovery: false

bandwidth:
  up:   0
  down: 0

ignoreClientBandwidth: true

auth:
  type: password
  password: "$AUTH_PASS"

masquerade:
  type: proxy
  proxy:
    url:         "https://www.microsoft.com"
    rewriteHost: true

resolver:
  type: udp
  udp:
    addr:    "8.8.8.8:53"
    timeout: 4s

sniff:
  enable:          true
  timeout:         2s
  rewriteDomain:   false
  tcpPorts:        "80,443,8000-9000"
  udpPorts:        "all"
EOF

    # ── Servicio systemd ───────────────────────────────
    cat > /etc/systemd/system/hysteria.service <<EOF
[Unit]
Description=DarkZsaid Premium - Hysteria v2 Server
After=network.target nss-lookup.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/hysteria server --config $HY2_DIR/config.yaml
WorkingDirectory=$HY2_DIR
Restart=on-failure
RestartSec=3
LimitNOFILE=infinity

[Install]
WantedBy=multi-user.target
EOF

    bar "Habilitando servicio Hysteria" \
        "systemctl daemon-reload && systemctl enable --now hysteria"

    # ── Port hopping con iptables ──────────────────────
    _setup_port_hopping

    # ── Guardar config en panel.conf ──────────────────
    echo "HY2_AUTH='$AUTH_PASS'" >> "$CFG_DIR/panel.conf"
    echo "HY2_OBFS='$OBFS_PASS'" >> "$CFG_DIR/panel.conf"

    echo ""
    echo -e "  ${Y}${BLD}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "  ${Y}${BLD}║  ✔  HYSTERIA v2 INSTALADO                       ║${NC}"
    echo -e "  ${Y}${BLD}╠══════════════════════════════════════════════════╣${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Puerto principal :${NC} ${W}${BLD}$HY2_PORT UDP${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Port hopping     :${NC} ${W}${BLD}${HY2_PORT_MIN}-${HY2_PORT_MAX} UDP${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Auth password    :${NC} ${W}${BLD}${AUTH_PASS}${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Obfs type        :${NC} ${W}${BLD}salamander${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Obfs password    :${NC} ${W}${BLD}${OBFS_PASS}${NC}"
    echo -e "  ${Y}${BLD}║${NC}  ${DIM}Host             :${NC} ${W}${BLD}${DOMAIN:-$(curl -s ifconfig.me)}${NC}"
    echo -e "  ${Y}${BLD}╚══════════════════════════════════════════════════╝${NC}"
    echo ""

    # ── Generar link de cliente ────────────────────────
    _hy2_client_link "$AUTH_PASS" "$OBFS_PASS"
    pause
}

# ── Port hopping 10000-65000 → 36712 ──────────────────
_setup_port_hopping() {
    bar "Configurando port hopping UDP ${HY2_PORT_MIN}-${HY2_PORT_MAX}" \
        "_apply_port_hopping"
}

_apply_port_hopping() {
    # Detectar interfaz de red principal
    local IFACE
    IFACE=$(ip route get 8.8.8.8 2>/dev/null | awk '{print $5; exit}')
    [[ -z "$IFACE" ]] && IFACE="eth0"

    # Limpiar reglas anteriores
    iptables -t nat -D PREROUTING -i "$IFACE" -p udp \
        --dport "${HY2_PORT_MIN}:${HY2_PORT_MAX}" \
        -j REDIRECT --to-port "$HY2_PORT" 2>/dev/null || true

    # Agregar regla de port hopping
    iptables -t nat -A PREROUTING -i "$IFACE" -p udp \
        --dport "${HY2_PORT_MIN}:${HY2_PORT_MAX}" \
        -j REDIRECT --to-port "$HY2_PORT"

    # IPv6 si está disponible
    ip6tables -t nat -D PREROUTING -i "$IFACE" -p udp \
        --dport "${HY2_PORT_MIN}:${HY2_PORT_MAX}" \
        -j REDIRECT --to-port "$HY2_PORT" 2>/dev/null || true
    ip6tables -t nat -A PREROUTING -i "$IFACE" -p udp \
        --dport "${HY2_PORT_MIN}:${HY2_PORT_MAX}" \
        -j REDIRECT --to-port "$HY2_PORT" 2>/dev/null || true

    # Persistir reglas iptables
    apt-get install -y iptables-persistent -qq &>/dev/null
    netfilter-persistent save &>/dev/null || true
}

# ── Link de cliente Hysteria v2 ───────────────────────
_hy2_client_link() {
    local PASS="$1"
    local OBFS="$2"
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    local HOST="${DOMAIN:-$(curl -s ifconfig.me 2>/dev/null)}"

    local LINK="hysteria2://${PASS}@${HOST}:${HY2_PORT_MIN}-${HY2_PORT_MAX}?obfs=salamander&obfs-password=${OBFS}&insecure=1#DarkZsaid-Hy2"

    echo -e "  ${Y}${BLD}── LINK CLIENTE (copiar en app) ────────────────${NC}"
    echo -e "  ${W}${BLD}${LINK}${NC}"
    echo ""
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null || true
}

# ── Agregar usuario a Hysteria ─────────────────────────
hy2_add_user() {
    local USER="$1"
    local PASS="$2"
    # Hysteria v2 con auth por password único → usar archivo de usuarios
    local USR_CONF="$HY2_DIR/users/${USER}.yaml"
    mkdir -p "$HY2_DIR/users"
    echo "password: \"$PASS\"" > "$USR_CONF"
    # Reconfigurar para múltiples usuarios (userpass type)
    # Solo se necesita reiniciar si cambia el tipo de auth
    systemctl restart hysteria 2>/dev/null
}
