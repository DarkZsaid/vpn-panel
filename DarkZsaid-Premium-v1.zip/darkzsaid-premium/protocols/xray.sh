#!/bin/bash
# ── XRAY CORE: VMess + VLESS + Trojan + Reality ─────────

XRAY_DIR="/etc/xray"
XRAY_BIN="/usr/local/bin/xray"

# ── Instalar Xray-core ────────────────────────────────
_ensure_xray() {
    if [[ ! -f "$XRAY_BIN" ]]; then
        bar "Instalando Xray-core" \
            "bash <(curl -Ls https://github.com/XTLS/Xray-install/raw/main/install-release.sh) \
            -- install 2>/dev/null"
    fi
    mkdir -p "$XRAY_DIR" /var/log/xray
}

# ── Configurar Nginx para WebSocket ──────────────────
_nginx_ws_location() {
    local path="$1"
    local port="$2"
    local conf="/etc/nginx/conf.d/dz-vpn.conf"
    # Agregar location si no existe
    if ! grep -q "location $path" "$conf" 2>/dev/null; then
        # Insertar antes del último }
        sed -i "/^}$/i\\
    location $path {\\
        proxy_pass          http://127.0.0.1:$port;\\
        proxy_http_version  1.1;\\
        proxy_set_header    Upgrade    \\\$http_upgrade;\\
        proxy_set_header    Connection \"upgrade\";\\
        proxy_set_header    Host       \\\$host;\\
        proxy_read_timeout  86400;\\
    }" "$conf" 2>/dev/null
        nginx -t &>/dev/null && systemctl reload nginx &>/dev/null
    fi
}

# ── Escribir/actualizar config Xray ──────────────────
_write_xray_config() {
    local CONF="$XRAY_DIR/config.json"

    # Si no existe, crear estructura base
    if [[ ! -f "$CONF" ]]; then
        cat > "$CONF" <<'BASEEOF'
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/xray/access.log",
    "error":  "/var/log/xray/error.log"
  },
  "inbounds": [],
  "outbounds": [
    { "protocol": "freedom", "settings": {} },
    { "protocol": "blackhole", "tag": "block" }
  ],
  "routing": {
    "rules": [
      { "type": "field", "ip": ["geoip:private"], "outboundTag": "block" }
    ]
  }
}
BASEEOF
    fi
}

# ── Agregar inbound a config.json ─────────────────────
_add_inbound() {
    local json="$1"
    local CONF="$XRAY_DIR/config.json"
    python3 - <<PYEOF 2>/dev/null
import json, sys

with open("$CONF", "r") as f:
    cfg = json.load(f)

new_inbound = $json

# Evitar duplicados por puerto
port = new_inbound.get("port")
cfg["inbounds"] = [i for i in cfg["inbounds"] if i.get("port") != port]
cfg["inbounds"].append(new_inbound)

with open("$CONF", "w") as f:
    json.dump(cfg, f, indent=2)

print("ok")
PYEOF
}

# ── V2RAY VMESS WebSocket ─────────────────────────────
install_vmess() {
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    _ensure_xray
    _write_xray_config

    local UUID PORT PATH_WS
    UUID=$(cat /proc/sys/kernel/random/uuid)
    PORT=10086
    PATH_WS="/v2ray-$(openssl rand -hex 4)"

    echo "$UUID" > "$XRAY_DIR/vmess-uuid.txt"
    echo "$PATH_WS" > "$XRAY_DIR/vmess-path.txt"

    bar "Configurando VMess WebSocket" \
        "_add_inbound '{
          \"port\": $PORT,
          \"listen\": \"127.0.0.1\",
          \"protocol\": \"vmess\",
          \"settings\": {
            \"clients\": [{\"id\": \"$UUID\", \"alterId\": 0}]
          },
          \"streamSettings\": {
            \"network\": \"ws\",
            \"wsSettings\": {\"path\": \"$PATH_WS\"}
          }
        }'"

    _nginx_ws_location "$PATH_WS" "$PORT"
    bar "Reiniciando Xray" "systemctl restart xray"

    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    local VMESS_JSON="{\"v\":\"2\",\"ps\":\"DZ-VMess\",\"add\":\"$HOST\",\"port\":\"443\",\"id\":\"$UUID\",\"aid\":\"0\",\"net\":\"ws\",\"path\":\"$PATH_WS\",\"tls\":\"tls\"}"
    local LINK="vmess://$(echo -n "$VMESS_JSON" | base64 -w0)"

    echo ""
    ok "VMess WebSocket instalado"
    echo -e "  ${DIM}UUID   :${NC} ${W}${BLD}$UUID${NC}"
    echo -e "  ${DIM}Path   :${NC} ${W}${BLD}$PATH_WS${NC}"
    echo -e "  ${DIM}Puerto :${NC} ${W}${BLD}443 (via Nginx)${NC}"
    echo -e "  ${DIM}Link   :${NC}"
    echo -e "  ${Y}${BLD}${LINK}${NC}"
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null || true
    pause
}

# ── VLESS WebSocket + TLS ─────────────────────────────
install_vless() {
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    _ensure_xray
    _write_xray_config

    local UUID PORT PATH_WS
    UUID=$(cat /proc/sys/kernel/random/uuid)
    PORT=10087
    PATH_WS="/vless-$(openssl rand -hex 4)"

    echo "$UUID"    > "$XRAY_DIR/vless-uuid.txt"
    echo "$PATH_WS" > "$XRAY_DIR/vless-path.txt"

    bar "Configurando VLESS WebSocket" \
        "_add_inbound '{
          \"port\": $PORT,
          \"listen\": \"127.0.0.1\",
          \"protocol\": \"vless\",
          \"settings\": {
            \"clients\": [{\"id\": \"$UUID\", \"level\": 0}],
            \"decryption\": \"none\"
          },
          \"streamSettings\": {
            \"network\": \"ws\",
            \"wsSettings\": {\"path\": \"$PATH_WS\"}
          }
        }'"

    _nginx_ws_location "$PATH_WS" "$PORT"
    bar "Reiniciando Xray" "systemctl restart xray"

    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    local LINK="vless://${UUID}@${HOST}:443?encryption=none&security=tls&type=ws&path=${PATH_WS}&sni=${HOST}#DZ-VLESS"

    echo ""
    ok "VLESS WebSocket + TLS instalado"
    echo -e "  ${DIM}UUID   :${NC} ${W}${BLD}$UUID${NC}"
    echo -e "  ${DIM}Path   :${NC} ${W}${BLD}$PATH_WS${NC}"
    echo -e "  ${Y}${BLD}${LINK}${NC}"
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null || true
    pause
}

# ── TROJAN-GFW WebSocket ──────────────────────────────
install_trojan() {
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    _ensure_xray
    _write_xray_config

    local PASS PORT PATH_WS
    PASS=$(openssl rand -hex 12)
    PORT=10088
    PATH_WS="/trojan-$(openssl rand -hex 4)"

    echo "$PASS"    > "$XRAY_DIR/trojan-pass.txt"
    echo "$PATH_WS" > "$XRAY_DIR/trojan-path.txt"

    bar "Configurando Trojan WebSocket" \
        "_add_inbound '{
          \"port\": $PORT,
          \"listen\": \"127.0.0.1\",
          \"protocol\": \"trojan\",
          \"settings\": {
            \"clients\": [{\"password\": \"$PASS\", \"level\": 0}]
          },
          \"streamSettings\": {
            \"network\": \"ws\",
            \"wsSettings\": {\"path\": \"$PATH_WS\"}
          }
        }'"

    _nginx_ws_location "$PATH_WS" "$PORT"
    bar "Reiniciando Xray" "systemctl restart xray"

    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    local LINK="trojan://${PASS}@${HOST}:443?security=tls&type=ws&path=${PATH_WS}&sni=${HOST}#DZ-Trojan"

    echo ""
    ok "Trojan WebSocket instalado"
    echo -e "  ${DIM}Pass   :${NC} ${W}${BLD}$PASS${NC}"
    echo -e "  ${DIM}Path   :${NC} ${W}${BLD}$PATH_WS${NC}"
    echo -e "  ${Y}${BLD}${LINK}${NC}"
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null || true
    pause
}

# ── XRAY VLESS REALITY ────────────────────────────────
install_reality() {
    [[ -f "$CFG_DIR/panel.conf" ]] && source "$CFG_DIR/panel.conf"
    _ensure_xray

    local UUID SHORT_ID PRIV_KEY PUB_KEY
    UUID=$(cat /proc/sys/kernel/random/uuid)
    SHORT_ID=$(openssl rand -hex 4)

    bar "Generando claves Reality" "_gen_reality_keys"

    PRIV_KEY=$(cat /tmp/reality-priv.txt 2>/dev/null)
    PUB_KEY=$(cat /tmp/reality-pub.txt 2>/dev/null)
    rm -f /tmp/reality-priv.txt /tmp/reality-pub.txt

    if [[ -z "$PRIV_KEY" ]]; then
        err "Error generando claves Reality"; return 1
    fi

    echo "$UUID"     > "$XRAY_DIR/reality-uuid.txt"
    echo "$PUB_KEY"  > "$XRAY_DIR/reality-pubkey.txt"
    echo "$SHORT_ID" > "$XRAY_DIR/reality-shortid.txt"

    # Reality usa su propio config separado (puerto 443 directo)
    cat > "$XRAY_DIR/reality.json" <<EOF
{
  "log": { "loglevel": "warning" },
  "inbounds": [{
    "port": 8443,
    "protocol": "vless",
    "settings": {
      "clients": [{"id": "$UUID", "flow": "xtls-rprx-vision", "level": 0}],
      "decryption": "none"
    },
    "streamSettings": {
      "network": "tcp",
      "security": "reality",
      "realitySettings": {
        "show":        false,
        "dest":        "www.microsoft.com:443",
        "xver":        0,
        "serverNames": ["www.microsoft.com", "learn.microsoft.com"],
        "privateKey":  "$PRIV_KEY",
        "shortIds":    ["$SHORT_ID"]
      }
    },
    "sniffing": {"enabled": true, "destOverride": ["http","tls","quic"]}
  }],
  "outbounds": [{"protocol": "freedom"}]
}
EOF

    # Servicio Reality separado
    cat > /etc/systemd/system/xray-reality.service <<EOF
[Unit]
Description=DarkZsaid Premium - Xray Reality
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/xray run -config $XRAY_DIR/reality.json
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    bar "Iniciando Xray Reality" \
        "systemctl daemon-reload && systemctl enable --now xray-reality"

    # Abrir puerto 8443 en UFW
    ufw allow 8443/tcp &>/dev/null || true

    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    local LINK="vless://${UUID}@${HOST}:8443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.microsoft.com&fp=chrome&pbk=${PUB_KEY}&sid=${SHORT_ID}&type=tcp&headerType=none#DZ-Reality"

    echo ""
    ok "VLESS Reality instalado"
    echo -e "  ${DIM}UUID       :${NC} ${W}${BLD}$UUID${NC}"
    echo -e "  ${DIM}Public Key :${NC} ${W}${BLD}$PUB_KEY${NC}"
    echo -e "  ${DIM}Short ID   :${NC} ${W}${BLD}$SHORT_ID${NC}"
    echo -e "  ${DIM}Puerto     :${NC} ${W}${BLD}8443/tcp${NC}"
    echo -e "  ${Y}${BLD}${LINK}${NC}"
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null || true
    pause
}

_gen_reality_keys() {
    local keys
    keys=$("$XRAY_BIN" x25519 2>/dev/null)
    echo "$keys" | grep "Private key:" | awk '{print $3}' > /tmp/reality-priv.txt
    echo "$keys" | grep "Public key:"  | awk '{print $3}' > /tmp/reality-pub.txt
}
