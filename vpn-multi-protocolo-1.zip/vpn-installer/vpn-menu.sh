#!/bin/bash
# ============================================================
#   SCRIPT VPN MULTI-PROTOCOLO - PANEL DE GESTIÓN COMPLETO
#   Compatibilidad: Ubuntu 20.04 / 22.04
#   Protocolos: SSH-WS, Hysteria, SlowDNS, UDP Custom,
#               V2Ray, Trojan, VLESS, SSH-WS 443, Xray
# ============================================================

# ─── COLORES ───────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m'

# ─── RUTAS GLOBALES ────────────────────────────────────────
BASE_DIR="/etc/vpn-panel"
USERS_DIR="$BASE_DIR/users"
CONFIG_DIR="$BASE_DIR/config"
LOG_DIR="/var/log/vpn-panel"
SCRIPT_DIR="/usr/local/bin/vpn-panel"

# ─── VERIFICAR ROOT ────────────────────────────────────────
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}[ERROR]${NC} Este script debe ejecutarse como root."
        exit 1
    fi
}

# ─── VERIFICAR OS ──────────────────────────────────────────
check_os() {
    if [[ ! -f /etc/os-release ]]; then
        echo -e "${RED}[ERROR]${NC} No se pudo detectar el sistema operativo."
        exit 1
    fi
    source /etc/os-release
    if [[ "$ID" != "ubuntu" ]]; then
        echo -e "${RED}[ERROR]${NC} Este script requiere Ubuntu 20.04 o 22.04."
        exit 1
    fi
}

# ─── CARGAR CONFIGURACIÓN ──────────────────────────────────
load_config() {
    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"
}

# ─── BANNER PRINCIPAL ──────────────────────────────────────
show_banner() {
    clear
    echo -e "${CYAN}"
    echo "  ╔══════════════════════════════════════════════════════╗"
    echo "  ║         VPN MULTI-PROTOCOLO - PANEL COMPLETO         ║"
    echo "  ║              Ubuntu 20.04 / 22.04                    ║"
    echo "  ╚══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo -e "  ${WHITE}Servidor IP  :${NC} $(curl -s ifconfig.me 2>/dev/null || echo 'N/A')"
    echo -e "  ${WHITE}Dominio      :${NC} ${DOMAIN:-'No configurado'}"
    echo -e "  ${WHITE}Uptime       :${NC} $(uptime -p 2>/dev/null || echo 'N/A')"
    echo -e "  ${WHITE}Fecha        :${NC} $(date '+%d/%m/%Y %H:%M:%S')"
    echo ""
}

# ─── MENÚ PRINCIPAL ────────────────────────────────────────
main_menu() {
    while true; do
        show_banner
        echo -e "  ${YELLOW}══════════════════ MENÚ PRINCIPAL ══════════════════${NC}"
        echo ""
        echo -e "  ${GREEN}[1]${NC}  Instalación de Protocolos"
        echo -e "  ${GREEN}[2]${NC}  Gestión de Usuarios"
        echo -e "  ${GREEN}[3]${NC}  Estado de Servicios"
        echo -e "  ${GREEN}[4]${NC}  Configuración del Sistema"
        echo -e "  ${GREEN}[5]${NC}  Herramientas de Red"
        echo -e "  ${GREEN}[6]${NC}  Logs y Monitoreo"
        echo -e "  ${GREEN}[7]${NC}  Backup y Restauración"
        echo -e "  ${RED}[0]${NC}  Salir"
        echo ""
        echo -e "  ${YELLOW}══════════════════════════════════════════════════════${NC}"
        echo -ne "  ${WHITE}Selecciona una opción: ${NC}"
        read -r opt

        case $opt in
            1) install_menu ;;
            2) user_menu ;;
            3) status_menu ;;
            4) config_menu ;;
            5) network_menu ;;
            6) log_menu ;;
            7) backup_menu ;;
            0) echo -e "\n  ${GREEN}¡Hasta luego!${NC}\n"; exit 0 ;;
            *) echo -e "\n  ${RED}Opción inválida.${NC}"; sleep 1 ;;
        esac
    done
}

# ─── MENÚ INSTALACIÓN ──────────────────────────────────────
install_menu() {
    while true; do
        show_banner
        echo -e "  ${YELLOW}══════════════ INSTALACIÓN DE PROTOCOLOS ═══════════${NC}"
        echo ""
        echo -e "  ${CYAN}── SSH ─────────────────────────────────────────────${NC}"
        echo -e "  ${GREEN}[1]${NC}  SSH WebSocket Puerto 80"
        echo -e "  ${GREEN}[2]${NC}  SSH WebSocket Puerto 443 (SSL)"
        echo -e "  ${GREEN}[3]${NC}  SSH OpenVPN TCP/UDP"
        echo ""
        echo -e "  ${CYAN}── UDP ─────────────────────────────────────────────${NC}"
        echo -e "  ${GREEN}[4]${NC}  UDP Hysteria (Puerto 36712)"
        echo -e "  ${GREEN}[5]${NC}  UDP Custom (BadVPN)"
        echo ""
        echo -e "  ${CYAN}── V2RAY / XRAY ────────────────────────────────────${NC}"
        echo -e "  ${GREEN}[6]${NC}  V2Ray VMess WebSocket"
        echo -e "  ${GREEN}[7]${NC}  VLESS WebSocket + TLS"
        echo -e "  ${GREEN}[8]${NC}  Trojan-GFW"
        echo -e "  ${GREEN}[9]${NC}  Xray VLESS Reality"
        echo ""
        echo -e "  ${CYAN}── DNS / OTROS ─────────────────────────────────────${NC}"
        echo -e "  ${GREEN}[10]${NC} SlowDNS"
        echo -e "  ${GREEN}[11]${NC} INSTALACIÓN COMPLETA (Todos los protocolos)"
        echo ""
        echo -e "  ${RED}[0]${NC}  Regresar"
        echo ""
        echo -ne "  ${WHITE}Selecciona: ${NC}"
        read -r opt

        case $opt in
            1)  source "$SCRIPT_DIR/protocols/ssh-ws.sh" && install_ssh_ws 80 ;;
            2)  source "$SCRIPT_DIR/protocols/ssh-ws.sh" && install_ssh_ws 443 ;;
            3)  source "$SCRIPT_DIR/protocols/openvpn.sh" && install_openvpn ;;
            4)  source "$SCRIPT_DIR/protocols/hysteria.sh" && install_hysteria ;;
            5)  source "$SCRIPT_DIR/protocols/udp-custom.sh" && install_udp_custom ;;
            6)  source "$SCRIPT_DIR/protocols/v2ray.sh" && install_v2ray ;;
            7)  source "$SCRIPT_DIR/protocols/vless.sh" && install_vless ;;
            8)  source "$SCRIPT_DIR/protocols/trojan.sh" && install_trojan ;;
            9)  source "$SCRIPT_DIR/protocols/xray-reality.sh" && install_xray_reality ;;
            10) source "$SCRIPT_DIR/protocols/slowdns.sh" && install_slowdns ;;
            11) install_all_protocols ;;
            0)  break ;;
            *)  echo -e "\n  ${RED}Opción inválida.${NC}"; sleep 1 ;;
        esac
    done
}

# ─── MENÚ USUARIOS ─────────────────────────────────────────
user_menu() {
    while true; do
        show_banner
        echo -e "  ${YELLOW}══════════════════ GESTIÓN DE USUARIOS ═════════════${NC}"
        echo ""
        echo -e "  ${GREEN}[1]${NC}  Crear Usuario"
        echo -e "  ${GREEN}[2]${NC}  Ver Usuarios Activos"
        echo -e "  ${GREEN}[3]${NC}  Editar Usuario"
        echo -e "  ${GREEN}[4]${NC}  Eliminar Usuario"
        echo -e "  ${GREEN}[5]${NC}  Renovar Expiración de Usuario"
        echo -e "  ${GREEN}[6]${NC}  Bloquear / Desbloquear Usuario"
        echo -e "  ${GREEN}[7]${NC}  Ver Conexiones Activas"
        echo -e "  ${GREEN}[8]${NC}  Usuarios Expirados"
        echo -e "  ${GREEN}[9]${NC}  Generar QR de Conexión"
        echo ""
        echo -e "  ${RED}[0]${NC}  Regresar"
        echo ""
        echo -ne "  ${WHITE}Selecciona: ${NC}"
        read -r opt

        case $opt in
            1) source "$SCRIPT_DIR/users/manage.sh" && create_user ;;
            2) source "$SCRIPT_DIR/users/manage.sh" && list_users ;;
            3) source "$SCRIPT_DIR/users/manage.sh" && edit_user ;;
            4) source "$SCRIPT_DIR/users/manage.sh" && delete_user ;;
            5) source "$SCRIPT_DIR/users/manage.sh" && renew_user ;;
            6) source "$SCRIPT_DIR/users/manage.sh" && toggle_user ;;
            7) source "$SCRIPT_DIR/users/manage.sh" && active_connections ;;
            8) source "$SCRIPT_DIR/users/manage.sh" && expired_users ;;
            9) source "$SCRIPT_DIR/users/manage.sh" && generate_qr ;;
            0) break ;;
            *) echo -e "\n  ${RED}Opción inválida.${NC}"; sleep 1 ;;
        esac
    done
}

# ─── MENÚ ESTADO DE SERVICIOS ──────────────────────────────
status_menu() {
    show_banner
    echo -e "  ${YELLOW}════════════════ ESTADO DE SERVICIOS ═══════════════${NC}"
    echo ""

    services=(
        "ssh:SSH Server"
        "ws-dropbear:SSH WebSocket 80"
        "ws-stunnel:SSH WebSocket 443"
        "hysteria:Hysteria UDP"
        "badvpn-udpgw:UDP Custom"
        "v2ray:V2Ray VMess"
        "xray:Xray VLESS/Trojan"
        "trojan:Trojan-GFW"
        "slowdns:SlowDNS"
        "nginx:Nginx (Proxy)"
        "fail2ban:Fail2Ban"
    )

    for svc in "${services[@]}"; do
        name="${svc%%:*}"
        label="${svc##*:}"
        if systemctl is-active --quiet "$name" 2>/dev/null; then
            status="${GREEN}● ACTIVO${NC}"
        else
            status="${RED}● INACTIVO${NC}"
        fi
        printf "  %-28s %b\n" "$label" "$status"
    done

    echo ""
    echo -e "  ${YELLOW}──────────── PUERTOS ESCUCHANDO ────────────────────${NC}"
    ss -tlnup 2>/dev/null | grep -E ":(22|80|443|1194|36712|7300|8080|8443|3128)" | \
        awk '{print "  " $1, $4, $5}' | head -20

    echo ""
    echo -ne "  ${WHITE}Presiona ENTER para continuar...${NC}"
    read -r
}

# ─── MENÚ CONFIGURACIÓN ────────────────────────────────────
config_menu() {
    while true; do
        show_banner
        echo -e "  ${YELLOW}═════════════════ CONFIGURACIÓN ════════════════════${NC}"
        echo ""
        echo -e "  ${GREEN}[1]${NC}  Configurar Dominio y SSL (Let's Encrypt)"
        echo -e "  ${GREEN}[2]${NC}  Cambiar Puertos de Servicios"
        echo -e "  ${GREEN}[3]${NC}  Configurar Firewall (UFW)"
        echo -e "  ${GREEN}[4]${NC}  Configurar BBR + CAKE (Optimización TCP)"
        echo -e "  ${GREEN}[5]${NC}  Cambiar DNS del Servidor"
        echo -e "  ${GREEN}[6]${NC}  Configurar Límite de Conexiones"
        echo -e "  ${GREEN}[7]${NC}  Actualizar Panel"
        echo ""
        echo -e "  ${RED}[0]${NC}  Regresar"
        echo ""
        echo -ne "  ${WHITE}Selecciona: ${NC}"
        read -r opt

        case $opt in
            1) source "$SCRIPT_DIR/config/ssl.sh" && setup_ssl ;;
            2) source "$SCRIPT_DIR/config/ports.sh" && change_ports ;;
            3) source "$SCRIPT_DIR/config/firewall.sh" && setup_firewall ;;
            4) source "$SCRIPT_DIR/config/optimize.sh" && setup_bbr ;;
            5) source "$SCRIPT_DIR/config/dns.sh" && change_dns ;;
            6) source "$SCRIPT_DIR/config/limits.sh" && set_limits ;;
            7) update_panel ;;
            0) break ;;
            *) echo -e "\n  ${RED}Opción inválida.${NC}"; sleep 1 ;;
        esac
    done
}

# ─── MENÚ RED ──────────────────────────────────────────────
network_menu() {
    show_banner
    echo -e "  ${YELLOW}══════════════════ HERRAMIENTAS DE RED ══════════════${NC}"
    echo ""
    echo -e "  ${GREEN}[1]${NC}  Prueba de velocidad (speedtest)"
    echo -e "  ${GREEN}[2]${NC}  Ping a servidor externo"
    echo -e "  ${GREEN}[3]${NC}  Ver tráfico en tiempo real (vnStat)"
    echo -e "  ${GREEN}[4]${NC}  Ver conexiones activas"
    echo -e "  ${GREEN}[5]${NC}  Traceroute"
    echo -e "  ${RED}[0]${NC}  Regresar"
    echo ""
    echo -ne "  ${WHITE}Selecciona: ${NC}"
    read -r opt

    case $opt in
        1) apt-get install -y speedtest-cli &>/dev/null; speedtest-cli ;;
        2) echo -ne "  Host a pingear: "; read -r host; ping -c 4 "$host" ;;
        3) vnstat -l 2>/dev/null || echo "vnstat no instalado. Ejecuta: apt install vnstat" ;;
        4) ss -tulnp ;;
        5) echo -ne "  Host destino: "; read -r host; traceroute "$host" ;;
        0) return ;;
    esac
    echo -ne "\n  ${WHITE}Presiona ENTER...${NC}"; read -r
}

# ─── MENÚ LOGS ─────────────────────────────────────────────
log_menu() {
    show_banner
    echo -e "  ${YELLOW}══════════════════ LOGS Y MONITOREO ════════════════${NC}"
    echo ""
    echo -e "  ${GREEN}[1]${NC}  Log de conexiones SSH"
    echo -e "  ${GREEN}[2]${NC}  Log de V2Ray/Xray"
    echo -e "  ${GREEN}[3]${NC}  Log de Nginx"
    echo -e "  ${GREEN}[4]${NC}  Log de Fail2Ban"
    echo -e "  ${GREEN}[5]${NC}  Monitor de recursos (htop)"
    echo -e "  ${RED}[0]${NC}  Regresar"
    echo ""
    echo -ne "  ${WHITE}Selecciona: ${NC}"
    read -r opt

    case $opt in
        1) tail -100 /var/log/auth.log | grep "sshd" ;;
        2) tail -100 /var/log/xray/access.log 2>/dev/null || tail -100 /var/log/v2ray/access.log 2>/dev/null ;;
        3) tail -100 /var/log/nginx/access.log 2>/dev/null ;;
        4) tail -100 /var/log/fail2ban.log 2>/dev/null ;;
        5) htop ;;
        0) return ;;
    esac
    echo -ne "\n  ${WHITE}Presiona ENTER...${NC}"; read -r
}

# ─── MENÚ BACKUP ───────────────────────────────────────────
backup_menu() {
    show_banner
    echo -e "  ${YELLOW}════════════════ BACKUP Y RESTAURACIÓN ═════════════${NC}"
    echo ""
    echo -e "  ${GREEN}[1]${NC}  Crear Backup completo"
    echo -e "  ${GREEN}[2]${NC}  Restaurar Backup"
    echo -e "  ${GREEN}[3]${NC}  Ver Backups disponibles"
    echo -e "  ${RED}[0]${NC}  Regresar"
    echo ""
    echo -ne "  ${WHITE}Selecciona: ${NC}"
    read -r opt

    case $opt in
        1) create_backup ;;
        2) restore_backup ;;
        3) ls -lh /root/vpn-backups/ 2>/dev/null || echo "No hay backups." ;;
        0) return ;;
    esac
    echo -ne "\n  ${WHITE}Presiona ENTER...${NC}"; read -r
}

create_backup() {
    local bdir="/root/vpn-backups"
    mkdir -p "$bdir"
    local fname="$bdir/vpn-backup-$(date +%Y%m%d-%H%M%S).tar.gz"
    tar -czf "$fname" "$BASE_DIR" /etc/xray /etc/v2ray /etc/trojan /etc/nginx \
        /etc/hysteria /usr/local/bin/vpn-panel 2>/dev/null
    echo -e "\n  ${GREEN}✔ Backup creado:${NC} $fname"
}

restore_backup() {
    ls /root/vpn-backups/ 2>/dev/null
    echo -ne "\n  Nombre del archivo a restaurar: "
    read -r fname
    if [[ -f "/root/vpn-backups/$fname" ]]; then
        tar -xzf "/root/vpn-backups/$fname" -C /
        echo -e "  ${GREEN}✔ Restaurado correctamente.${NC}"
    else
        echo -e "  ${RED}Archivo no encontrado.${NC}"
    fi
}

# ─── INSTALACIÓN COMPLETA ──────────────────────────────────
install_all_protocols() {
    echo -e "\n  ${YELLOW}Iniciando instalación completa...${NC}\n"
    source "$SCRIPT_DIR/install/base.sh" && install_base_deps
    source "$SCRIPT_DIR/protocols/ssh-ws.sh" && install_ssh_ws 80 && install_ssh_ws 443
    source "$SCRIPT_DIR/protocols/hysteria.sh" && install_hysteria
    source "$SCRIPT_DIR/protocols/udp-custom.sh" && install_udp_custom
    source "$SCRIPT_DIR/protocols/v2ray.sh" && install_v2ray
    source "$SCRIPT_DIR/protocols/vless.sh" && install_vless
    source "$SCRIPT_DIR/protocols/trojan.sh" && install_trojan
    source "$SCRIPT_DIR/protocols/slowdns.sh" && install_slowdns
    echo -e "\n  ${GREEN}✔ Instalación completa finalizada.${NC}"
    sleep 2
}

update_panel() {
    echo -e "\n  ${YELLOW}Actualizando panel...${NC}"
    apt-get update -y && apt-get upgrade -y
    echo -e "  ${GREEN}✔ Panel actualizado.${NC}"
    sleep 1
}

# ─── INICIALIZAR ───────────────────────────────────────────
check_root
check_os
mkdir -p "$BASE_DIR" "$USERS_DIR" "$CONFIG_DIR" "$LOG_DIR"
load_config
main_menu
