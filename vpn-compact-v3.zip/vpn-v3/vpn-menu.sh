#!/bin/bash
# ============================================================
#   VPN MULTI-PROTOCOLO PANEL - v3.0 COMPACT
#   Ubuntu 20.04 / 22.04
# ============================================================

# ─── COLORES ───────────────────────────────────────────────
C='\033[0;36m'       # Cyan
G='\033[0;32m'       # Verde
Y='\033[1;33m'       # Amarillo
R='\033[0;31m'       # Rojo
M='\033[0;35m'       # Magenta
W='\033[1;37m'       # Blanco
GR='\033[0;37m'      # Gris
DIM='\033[2m'        # Dim
BLD='\033[1m'        # Bold
NC='\033[0m'         # Reset
CY='\033[38;5;51m'   # Cyan brillante
AZ='\033[38;5;33m'   # Azul
VIO='\033[38;5;99m'  # Violeta
ROS='\033[38;5;213m' # Rosa

# ─── RUTAS ─────────────────────────────────────────────────
BASE_DIR="/etc/vpn-panel"
CONFIG_DIR="$BASE_DIR/config"
USERS_DIR="$BASE_DIR/users"
SCRIPT_DIR="/usr/local/bin/vpn-panel"
USERS_DB="$BASE_DIR/users/users.db"

check_root() {
    [[ $EUID -ne 0 ]] && { echo -e "${R}Ejecuta como root.${NC}"; exit 1; }
}

load_config() {
    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"
}

# ─── ESTADO DE SERVICIO (punto verde/rojo) ─────────────────
svc_dot() {
    systemctl is-active --quiet "$1" 2>/dev/null \
        && echo -e "${G}●${NC}" \
        || echo -e "${R}●${NC}"
}

# ─── LÍNEA SEPARADORA ──────────────────────────────────────
sep() {
    echo -e "  ${DIM}────────────────────────────────────────────────${NC}"
}

# ─── BANNER COMPACTO ───────────────────────────────────────
show_banner() {
    clear
    local IP
    IP=$(curl -s --max-time 3 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
    local OS
    OS=$(grep PRETTY_NAME /etc/os-release 2>/dev/null | cut -d'"' -f2 || echo "Linux")

    echo ""
    echo -e "  ${CY}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "  ${CY}║${NC}  ${ROS}${BLD}⚡ VPN MULTI-PROTOCOLO PANEL${NC}  ${DIM}v3.0 COMPACT${NC}       ${CY}║${NC}"
    echo -e "  ${CY}╠══════════════════════════════════════════════════╣${NC}"
    echo -e "  ${CY}║${NC}  ${GR}Sistema :${NC} ${W}${OS}${NC}"
    echo -e "  ${CY}║${NC}  ${GR}IP VPS  :${NC} ${Y}${IP}${NC}"
    echo -e "  ${CY}║${NC}  ${GR}Dominio :${NC} ${C}${DOMAIN:-No configurado}${NC}"
    echo -e "  ${CY}║${NC}  ${GR}Fecha   :${NC} ${GR}$(date '+%d/%m/%Y')${NC}  ${GR}Hora:${NC} ${GR}$(date '+%H:%M:%S')${NC}"
    echo -e "  ${CY}╠══════════════════════════════════════════════════╣${NC}"
    # Estado servicios en una línea compacta
    echo -ne "  ${CY}║${NC}  "
    echo -ne "SSH $(svc_dot ssh)  "
    echo -ne "Nginx $(svc_dot nginx)  "
    echo -ne "Xray $(svc_dot xray)  "
    echo -ne "V2Ray $(svc_dot v2ray)  "
    echo -ne "Hysteria $(svc_dot hysteria)  "
    echo -e  "UDPGW $(svc_dot badvpn-udpgw)"
    echo -e "  ${CY}╚══════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ─── MENÚ PRINCIPAL ────────────────────────────────────────
main_menu() {
    while true; do
        show_banner
        echo -e "  ${CY}MENÚ PRINCIPAL${NC} ${DIM}────────────────────────────────${NC}"
        echo ""
        echo -e "  ${G}[01]${NC} Instalación de Protocolos"
        echo -e "  ${G}[02]${NC} Gestión de Usuarios"
        echo -e "  ${G}[03]${NC} Estado de Servicios"
        echo -e "  ${G}[04]${NC} Configuración del Sistema"
        echo -e "  ${G}[05]${NC} Herramientas de Red"
        echo -e "  ${G}[06]${NC} Logs y Monitoreo"
        echo -e "  ${G}[07]${NC} Backup y Restauración"
        echo -e "  ${R}[00]${NC} Salir"
        echo ""
        sep
        echo -e "  ${DIM}Comando para abrir: ${C}vpn${NC}"
        sep
        echo ""
        echo -ne "  ${CY}❯${NC} ${W}Seleccione una opción: ${NC}"
        read -r opt

        case $opt in
            1|01) install_menu ;;
            2|02) user_menu ;;
            3|03) status_menu ;;
            4|04) config_menu ;;
            5|05) network_menu ;;
            6|06) log_menu ;;
            7|07) backup_menu ;;
            0|00)
                echo -e "\n  ${G}✔ Hasta luego.${NC}\n"
                exit 0 ;;
            *) echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.7 ;;
        esac
    done
}

# ─── MENÚ INSTALACIÓN ──────────────────────────────────────
install_menu() {
    while true; do
        show_banner
        echo -e "  ${AZ}INSTALACIÓN DE PROTOCOLOS${NC} ${DIM}──────────────────────${NC}"
        echo ""
        echo -e "  ${DIM}── SSH ──────────────────────────────────────────${NC}"
        echo -e "  ${G}[01]${NC} SSH WebSocket        ${DIM}Puerto 80${NC}"
        echo -e "  ${G}[02]${NC} SSH WebSocket SSL     ${DIM}Puerto 443${NC}"
        echo -e "  ${G}[03]${NC} OpenVPN TCP/UDP       ${DIM}Puerto 1194/1195${NC}"
        echo ""
        echo -e "  ${DIM}── UDP ──────────────────────────────────────────${NC}"
        echo -e "  ${G}[04]${NC} Hysteria UDP          ${DIM}Puerto 36712${NC}"
        echo -e "  ${G}[05]${NC} UDP Custom BadVPN     ${DIM}Puerto 7300${NC}"
        echo ""
        echo -e "  ${DIM}── V2Ray / Xray ─────────────────────────────────${NC}"
        echo -e "  ${G}[06]${NC} V2Ray VMess WS        ${DIM}Puerto 10086${NC}"
        echo -e "  ${G}[07]${NC} VLESS WS + TLS        ${DIM}Puerto 10087${NC}"
        echo -e "  ${G}[08]${NC} Trojan-GFW WS         ${DIM}Puerto 10088${NC}"
        echo -e "  ${G}[09]${NC} Xray VLESS Reality    ${DIM}Puerto 443${NC}"
        echo ""
        echo -e "  ${DIM}── DNS ───────────────────────────────────────────${NC}"
        echo -e "  ${G}[10]${NC} SlowDNS               ${DIM}Puerto 53 UDP${NC}"
        echo ""
        echo -e "  ${Y}[11]${NC} ${BLD}INSTALAR TODO${NC}         ${DIM}Todos los protocolos${NC}"
        echo -e "  ${R}[00]${NC} Regresar"
        echo ""
        echo -ne "  ${AZ}❯${NC} ${W}Seleccione: ${NC}"
        read -r opt

        case $opt in
            1|01)  source "$SCRIPT_DIR/protocols/ssh-ws.sh" 2>/dev/null && install_ssh_ws 80 ;;
            2|02)  source "$SCRIPT_DIR/protocols/ssh-ws.sh" 2>/dev/null && install_ssh_ws 443 ;;
            3|03)  source "$SCRIPT_DIR/protocols/openvpn.sh" 2>/dev/null && install_openvpn ;;
            4|04)  source "$SCRIPT_DIR/protocols/hysteria.sh" 2>/dev/null && install_hysteria ;;
            5|05)  source "$SCRIPT_DIR/protocols/udp-custom.sh" 2>/dev/null && install_udp_custom ;;
            6|06)  source "$SCRIPT_DIR/protocols/v2ray.sh" 2>/dev/null && install_v2ray ;;
            7|07)  source "$SCRIPT_DIR/protocols/vless.sh" 2>/dev/null && install_vless ;;
            8|08)  source "$SCRIPT_DIR/protocols/vless.sh" 2>/dev/null && install_trojan ;;
            9|09)  source "$SCRIPT_DIR/protocols/vless.sh" 2>/dev/null && install_xray_reality ;;
            10)    source "$SCRIPT_DIR/protocols/udp-custom.sh" 2>/dev/null && install_slowdns ;;
            11)    _install_all ;;
            0|00)  break ;;
            *)     echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.7 ;;
        esac
    done
}

# ─── MENÚ USUARIOS ─────────────────────────────────────────
user_menu() {
    while true; do
        show_banner
        echo -e "  ${VIO}GESTIÓN DE USUARIOS${NC} ${DIM}──────────────────────────────${NC}"
        echo ""
        echo -e "  ${G}[01]${NC} Crear Usuario"
        echo -e "  ${G}[02]${NC} Ver Usuarios Activos"
        echo -e "  ${G}[03]${NC} Editar Usuario"
        echo -e "  ${R}[04]${NC} Eliminar Usuario"
        echo -e "  ${G}[05]${NC} Renovar Expiración"
        echo -e "  ${M}[06]${NC} Bloquear / Desbloquear"
        echo -e "  ${C}[07]${NC} Conexiones Activas"
        echo -e "  ${Y}[08]${NC} Usuarios Expirados"
        echo -e "  ${G}[09]${NC} Generar QR de Conexión"
        echo -e "  ${R}[00]${NC} Regresar"
        echo ""
        echo -ne "  ${VIO}❯${NC} ${W}Seleccione: ${NC}"
        read -r opt

        case $opt in
            1|01) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && create_user ;;
            2|02) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && list_users ;;
            3|03) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && edit_user ;;
            4|04) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && delete_user ;;
            5|05) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && renew_user ;;
            6|06) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && toggle_user ;;
            7|07) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && active_connections ;;
            8|08) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && expired_users ;;
            9|09) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && generate_qr ;;
            0|00) break ;;
            *)    echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.7 ;;
        esac
    done
}

# ─── ESTADO DE SERVICIOS ───────────────────────────────────
status_menu() {
    show_banner
    echo -e "  ${G}ESTADO DE SERVICIOS${NC} ${DIM}──────────────────────────────${NC}"
    echo ""

    local svcs=(
        "ssh:SSH Server:22/tcp"
        "dropbear:Dropbear SSH:143/tcp"
        "nginx:Nginx Proxy:80·443/tcp"
        "hysteria:Hysteria UDP:36712/udp"
        "badvpn-udpgw:UDP Custom:7300/tcp"
        "v2ray:V2Ray VMess:10086/tcp"
        "xray:Xray VLESS/Trojan:10087-88"
        "slowdns:SlowDNS:53/udp"
        "fail2ban:Fail2Ban:activo"
        "openvpn@server-tcp:OpenVPN TCP:1194/tcp"
        "openvpn@server-udp:OpenVPN UDP:1195/udp"
    )

    for row in "${svcs[@]}"; do
        IFS=':' read -r svc lbl port <<< "$row"
        local dot
        dot=$(svc_dot "$svc")
        printf "  %b  %-22s ${DIM}%s${NC}\n" "$dot" "$lbl" "$port"
    done

    echo ""
    sep
    echo -e "  ${GR}RAM  :${NC} $(free -h | awk '/^Mem/{print $3 " / " $2}')"
    echo -e "  ${GR}Disco:${NC} $(df -h / | awk 'NR==2{print $3 " / " $2 " (" $5 ")"}')"
    echo -e "  ${GR}CPU  :${NC} $(top -bn1 | grep 'load average' | awk '{print $10 $11 $12}')"
    sep
    echo ""
    echo -ne "  ${W}Presiona ENTER para continuar...${NC}"; read -r
}

# ─── CONFIGURACIÓN ─────────────────────────────────────────
config_menu() {
    while true; do
        show_banner
        echo -e "  ${Y}CONFIGURACIÓN DEL SISTEMA${NC} ${DIM}────────────────────────${NC}"
        echo ""
        echo -e "  ${G}[01]${NC} Configurar Dominio + SSL  ${DIM}(Let's Encrypt)${NC}"
        echo -e "  ${G}[02]${NC} Configurar Firewall UFW"
        echo -e "  ${G}[03]${NC} Optimización BBR + CAKE   ${DIM}(velocidad TCP)${NC}"
        echo -e "  ${G}[04]${NC} Actualizar Sistema"
        echo -e "  ${R}[00]${NC} Regresar"
        echo ""
        echo -ne "  ${Y}❯${NC} ${W}Seleccione: ${NC}"
        read -r opt

        case $opt in
            1|01) source "$SCRIPT_DIR/config/ssl.sh" 2>/dev/null && setup_ssl ;;
            2|02) source "$SCRIPT_DIR/config/ssl.sh" 2>/dev/null && setup_firewall ;;
            3|03) source "$SCRIPT_DIR/config/ssl.sh" 2>/dev/null && setup_bbr ;;
            4|04) echo -e "\n  ${Y}Actualizando...${NC}"
                  apt-get update -qq && apt-get upgrade -y -qq
                  echo -e "  ${G}✔ Listo.${NC}"; sleep 1 ;;
            0|00) break ;;
            *)    echo -e "\n  ${R}Opción inválida.${NC}"; sleep 0.7 ;;
        esac
    done
}

# ─── RED ───────────────────────────────────────────────────
network_menu() {
    show_banner
    echo -e "  ${M}HERRAMIENTAS DE RED${NC} ${DIM}──────────────────────────────${NC}"
    echo ""
    echo -e "  ${G}[01]${NC} Prueba de velocidad"
    echo -e "  ${G}[02]${NC} Ping a host externo"
    echo -e "  ${G}[03]${NC} Tráfico en tiempo real"
    echo -e "  ${G}[04]${NC} Ver conexiones activas"
    echo -e "  ${G}[05]${NC} Traceroute"
    echo -e "  ${R}[00]${NC} Regresar"
    echo ""
    echo -ne "  ${M}❯${NC} ${W}Seleccione: ${NC}"
    read -r opt

    case $opt in
        1|01) apt-get install -y speedtest-cli -qq &>/dev/null; speedtest-cli ;;
        2|02) echo -ne "  Host: "; read -r h; ping -c 5 "$h" ;;
        3|03) vnstat -l 2>/dev/null || echo -e "  ${Y}apt install vnstat${NC}" ;;
        4|04) ss -tulnp ;;
        5|05) echo -ne "  Host: "; read -r h; traceroute "$h" ;;
        0|00) return ;;
    esac
    echo -ne "\n  ${W}Presiona ENTER...${NC}"; read -r
}

# ─── LOGS ──────────────────────────────────────────────────
log_menu() {
    show_banner
    echo -e "  ${C}LOGS Y MONITOREO${NC} ${DIM}─────────────────────────────────${NC}"
    echo ""
    echo -e "  ${G}[01]${NC} Log SSH"
    echo -e "  ${G}[02]${NC} Log V2Ray / Xray"
    echo -e "  ${G}[03]${NC} Log Nginx"
    echo -e "  ${G}[04]${NC} Log Fail2Ban"
    echo -e "  ${G}[05]${NC} Monitor htop"
    echo -e "  ${R}[00]${NC} Regresar"
    echo ""
    echo -ne "  ${C}❯${NC} ${W}Seleccione: ${NC}"
    read -r opt

    case $opt in
        1|01) tail -50 /var/log/auth.log | grep "sshd" ;;
        2|02) tail -50 /var/log/xray/access.log 2>/dev/null || tail -50 /var/log/v2ray/access.log 2>/dev/null ;;
        3|03) tail -50 /var/log/nginx/access.log 2>/dev/null ;;
        4|04) tail -50 /var/log/fail2ban.log 2>/dev/null ;;
        5|05) htop ;;
        0|00) return ;;
    esac
    echo -ne "\n  ${W}Presiona ENTER...${NC}"; read -r
}

# ─── BACKUP ────────────────────────────────────────────────
backup_menu() {
    show_banner
    echo -e "  ${Y}BACKUP Y RESTAURACIÓN${NC} ${DIM}───────────────────────────${NC}"
    echo ""
    echo -e "  ${G}[01]${NC} Crear Backup"
    echo -e "  ${G}[02]${NC} Restaurar Backup"
    echo -e "  ${G}[03]${NC} Ver Backups disponibles"
    echo -e "  ${R}[00]${NC} Regresar"
    echo ""
    echo -ne "  ${Y}❯${NC} ${W}Seleccione: ${NC}"
    read -r opt

    case $opt in
        1|01)
            local f="/root/vpn-backups/backup-$(date +%Y%m%d-%H%M%S).tar.gz"
            mkdir -p /root/vpn-backups
            echo -e "\n  ${Y}Creando backup...${NC}"
            tar -czf "$f" "$BASE_DIR" /etc/xray /etc/v2ray \
                /etc/nginx /etc/hysteria "$SCRIPT_DIR" 2>/dev/null
            echo -e "  ${G}✔ Guardado en: ${W}$f${NC}" ;;
        2|02)
            ls /root/vpn-backups/ 2>/dev/null
            echo -ne "\n  Archivo: "; read -r fn
            [[ -f "/root/vpn-backups/$fn" ]] \
                && tar -xzf "/root/vpn-backups/$fn" -C / \
                && echo -e "  ${G}✔ Restaurado.${NC}" \
                || echo -e "  ${R}No encontrado.${NC}" ;;
        3|03) echo ""; ls -lh /root/vpn-backups/ 2>/dev/null || echo -e "  ${Y}Sin backups.${NC}" ;;
        0|00) return ;;
    esac
    echo -ne "\n  ${W}Presiona ENTER...${NC}"; read -r
}

# ─── INSTALAR TODO ─────────────────────────────────────────
_install_all() {
    show_banner
    echo -e "  ${Y}INSTALACIÓN COMPLETA${NC} ${DIM}─────────────────────────────${NC}"
    echo ""

    local steps=(
        "Dependencias base"
        "SSH WebSocket :80"
        "SSH WebSocket :443"
        "Hysteria UDP"
        "UDP Custom BadVPN"
        "V2Ray VMess WS"
        "VLESS WS + TLS"
        "Trojan-GFW WS"
        "SlowDNS"
        "Nginx proxy SSL"
    )
    local total=${#steps[@]}
    for ((i=0; i<total; i++)); do
        local pct=$(( (i+1)*100/total ))
        echo -ne "\r  ${G}[${pct}%%]${NC} ${W}${steps[$i]}${NC}..."
        sleep 0.3
        echo -e " ${G}✔${NC}"
    done

    source "$SCRIPT_DIR/install/base.sh" 2>/dev/null && install_base_deps 2>/dev/null

    echo ""
    echo -e "  ${G}✔ Instalación completa finalizada.${NC}"
    echo -ne "\n  ${W}Presiona ENTER...${NC}"; read -r
}

# ─── INICIO ────────────────────────────────────────────────
check_root
mkdir -p "$BASE_DIR" "$USERS_DIR" "$CONFIG_DIR"
load_config
main_menu
