#!/bin/bash
# ============================================================
#   MÓDULO: Configuración SSL con Let's Encrypt
# ============================================================

setup_ssl() {
    show_banner
    echo -e "  ${YELLOW}════════════════ CONFIGURAR SSL ════════════════════${NC}"
    echo ""

    echo -ne "  ${WHITE}Dominio (ej: vpn.miservidor.com): ${NC}"; read -r DOMAIN
    [[ -z "$DOMAIN" ]] && { echo -e "  ${RED}Dominio inválido.${NC}"; sleep 2; return; }

    echo -ne "  ${WHITE}Email para Let's Encrypt: ${NC}"; read -r EMAIL
    [[ -z "$EMAIL" ]] && EMAIL="admin@${DOMAIN}"

    # ── Guardar dominio en config ───────────────────────────
    mkdir -p "$CONFIG_DIR"
    cat > "$CONFIG_DIR/panel.conf" <<EOF
DOMAIN="$DOMAIN"
EMAIL="$EMAIL"
INSTALL_DATE="$(date '+%Y-%m-%d')"
EOF

    # ── Configurar Nginx para que certbot funcione ──────────
    _setup_nginx_base "$DOMAIN"

    # ── Obtener certificado ─────────────────────────────────
    echo -e "\n  ${CYAN}[SSL]${NC} Obteniendo certificado para $DOMAIN..."
    certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect 2>&1 | \
        grep -E "(Congratulations|Error|error)"

    if [[ -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]]; then
        echo -e "  ${GREEN}✔ Certificado SSL instalado para $DOMAIN${NC}"

        # Configurar renovación automática
        (crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet && systemctl reload nginx") \
            | sort -u | crontab -

        # Reconfigurar Nginx con SSL completo
        _setup_nginx_ssl "$DOMAIN"
    else
        echo -e "  ${RED}✘ Error obteniendo certificado. Verifica el DNS del dominio.${NC}"
    fi

    echo -ne "\n  ${WHITE}Presiona ENTER...${NC}"; read -r
}

_setup_nginx_base() {
    local DOMAIN="$1"
    apt-get install -y nginx certbot python3-certbot-nginx 2>/dev/null

    cat > "/etc/nginx/sites-available/$DOMAIN" <<EOF
server {
    listen 80;
    server_name $DOMAIN;
    location / { return 200 'OK'; add_header Content-Type text/plain; }
}
EOF

    ln -sf "/etc/nginx/sites-available/$DOMAIN" "/etc/nginx/sites-enabled/"
    rm -f /etc/nginx/sites-enabled/default 2>/dev/null
    systemctl enable --now nginx
    nginx -t && systemctl reload nginx
}

_setup_nginx_ssl() {
    local DOMAIN="$1"

    cat > /etc/nginx/conf.d/vpn-main.conf <<EOF
# ── VPN Panel - Configuración principal ──────────────────
server {
    listen 443 ssl http2;
    server_name $DOMAIN;

    ssl_certificate     /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache   shared:SSL:10m;

    # Raíz (camouflage)
    location / {
        return 200 '<!DOCTYPE html><html><body><h1>403 Forbidden</h1></body></html>';
        add_header Content-Type text/html;
    }

    # SSH WebSocket
    location /ssh-ws {
        proxy_pass          http://127.0.0.1:80;
        proxy_http_version  1.1;
        proxy_set_header    Upgrade    \$http_upgrade;
        proxy_set_header    Connection "upgrade";
        proxy_set_header    Host       \$host;
        proxy_read_timeout  86400;
    }

    # V2Ray VMess
    location /v2ray {
        proxy_pass          http://127.0.0.1:10086;
        proxy_http_version  1.1;
        proxy_set_header    Upgrade    \$http_upgrade;
        proxy_set_header    Connection "upgrade";
        proxy_set_header    Host       \$host;
        proxy_read_timeout  86400;
    }

    # VLESS
    location /vless {
        proxy_pass          http://127.0.0.1:10087;
        proxy_http_version  1.1;
        proxy_set_header    Upgrade    \$http_upgrade;
        proxy_set_header    Connection "upgrade";
        proxy_set_header    Host       \$host;
        proxy_read_timeout  86400;
    }

    # Trojan WebSocket
    location /trojan {
        proxy_pass          http://127.0.0.1:10088;
        proxy_http_version  1.1;
        proxy_set_header    Upgrade    \$http_upgrade;
        proxy_set_header    Connection "upgrade";
        proxy_set_header    Host       \$host;
        proxy_read_timeout  86400;
    }
}

# ── Redirigir HTTP a HTTPS ────────────────────────────────
server {
    listen 80;
    server_name $DOMAIN;
    return 301 https://\$host\$request_uri;
}
EOF

    nginx -t && systemctl reload nginx
    echo -e "  ${GREEN}✔ Nginx configurado con SSL para todos los protocolos.${NC}"
}

# ============================================================
#   MÓDULO: Firewall UFW
# ============================================================

setup_firewall() {
    echo -e "\n  ${CYAN}[FIREWALL]${NC} Configurando UFW..."

    apt-get install -y ufw 2>/dev/null

    ufw --force reset

    # Puertos base
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow 22/tcp    comment "SSH"
    ufw allow 80/tcp    comment "HTTP / SSH-WS"
    ufw allow 443/tcp   comment "HTTPS / SSL"
    ufw allow 143/tcp   comment "Dropbear"
    ufw allow 10086/tcp comment "V2Ray VMess"
    ufw allow 10087/tcp comment "VLESS"
    ufw allow 10088/tcp comment "Trojan"
    ufw allow 36712/udp comment "Hysteria"
    ufw allow 53/udp    comment "SlowDNS"
    ufw allow 7300/tcp  comment "BadVPN UDPGW"
    ufw allow 3128/tcp  comment "Squid Proxy"

    ufw --force enable
    ufw status verbose

    echo -e "\n  ${GREEN}✔ Firewall configurado.${NC}"
    sleep 2
}

# ============================================================
#   MÓDULO: Optimización TCP (BBR + CAKE)
# ============================================================

setup_bbr() {
    echo -e "\n  ${CYAN}[OPTIMIZACIÓN]${NC} Configurando BBR + CAKE..."

    cat >> /etc/sysctl.conf <<'EOF'

# ── VPN Optimization ──────────────────────────────────────
net.core.default_qdisc       = cake
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_fastopen        = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.ip_forward          = 1
net.ipv6.conf.all.forwarding = 1
net.core.rmem_max            = 67108864
net.core.wmem_max            = 67108864
net.ipv4.tcp_rmem            = 4096 87380 67108864
net.ipv4.tcp_wmem            = 4096 65536 67108864
net.ipv4.tcp_mtu_probing     = 1
net.ipv4.tcp_syncookies      = 1
net.ipv4.tcp_tw_reuse        = 1
EOF

    sysctl -p 2>/dev/null
    modprobe tcp_bbr 2>/dev/null

    echo -e "  ${GREEN}✔ BBR + optimizaciones TCP aplicadas.${NC}"
    sleep 2
}
