#!/bin/bash
# ============================================================
#   MÓDULO: Instalación de Dependencias Base
# ============================================================

install_base_deps() {
    echo -e "\n  ${CYAN}[BASE]${NC} Actualizando sistema e instalando dependencias..."

    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get upgrade -y

    local pkgs=(
        curl wget unzip tar git jq uuid-runtime
        openssl ca-certificates gnupg2 lsb-release
        net-tools iproute2 iptables
        nginx certbot python3-certbot-nginx
        dropbear stunnel4 squid
        fail2ban ufw vnstat
        qrencode bc socat cron
        python3 python3-pip
        build-essential cmake
    )

    echo -e "  ${CYAN}[BASE]${NC} Instalando paquetes..."
    apt-get install -y "${pkgs[@]}" --no-install-recommends

    # Habilitar BBR
    if ! grep -q "tcp_bbr" /etc/modules-load.d/modules.conf 2>/dev/null; then
        echo "tcp_bbr" >> /etc/modules-load.d/modules.conf
        modprobe tcp_bbr 2>/dev/null
    fi

    echo -e "  ${GREEN}✔ Dependencias base instaladas.${NC}"
}
