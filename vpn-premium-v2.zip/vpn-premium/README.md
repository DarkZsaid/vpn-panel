# VPN MULTI-PROTOCOLO PANEL — DOCUMENTACIÓN

## Descripción
Panel completo de gestión VPN para Ubuntu 20.04/22.04 con soporte para múltiples protocolos y menú interactivo en terminal.

---

## Estructura del Proyecto

```
vpn-installer/
├── install.sh                  # Instalador principal
├── vpn-menu.sh                 # Menú interactivo principal
├── install/
│   └── base.sh                 # Dependencias base del sistema
├── protocols/
│   ├── ssh-ws.sh               # SSH WebSocket (puerto 80 y 443)
│   ├── hysteria.sh             # UDP Hysteria
│   ├── udp-custom.sh           # UDP Custom (BadVPN) + SlowDNS
│   ├── v2ray.sh                # V2Ray VMess WebSocket
│   ├── vless.sh                # VLESS WS + Trojan + Xray Reality
│   └── openvpn.sh              # OpenVPN TCP/UDP
├── users/
│   └── manage.sh               # Gestión completa de usuarios
└── config/
    └── ssl.sh                  # SSL, Firewall, BBR, Nginx
```

---

## Instalación

### 1. Subir al servidor
```bash
scp -r vpn-installer/ root@TU_IP:/root/
```

### 2. Ejecutar instalador
```bash
cd /root/vpn-installer
chmod +x install.sh
bash install.sh
```

### 3. Abrir el panel
```bash
vpn
```

---

## Protocolos Incluidos

| Protocolo        | Puerto        | Notas                              |
|-----------------|---------------|------------------------------------|
| SSH WebSocket   | 80            | Dropbear + proxy WS Python         |
| SSH WebSocket   | 443 (SSL)     | Stunnel + Let's Encrypt            |
| OpenVPN TCP     | 1194          | Con Easy-RSA, perfil .ovpn         |
| OpenVPN UDP     | 1195          | Alta velocidad                     |
| Hysteria UDP    | 36712         | QUIC, alta velocidad               |
| UDP Custom      | 7300          | BadVPN UDPGW (para HTTP Injector)  |
| V2Ray VMess WS  | 10086 (local) | Via Nginx reverse proxy            |
| VLESS WS + TLS  | 10087 (local) | Via Xray-core                      |
| Trojan-GFW WS   | 10088 (local) | Via Xray-core                      |
| Xray Reality    | 443           | VLESS + Reality (sin dominio SSL)  |
| SlowDNS         | 53 UDP        | Requiere registro NS               |

---

## Gestión de Usuarios

Los usuarios se almacenan en `/etc/vpn-panel/users/users.db` con formato:
```
usuario:contraseña:fecha_exp:max_conn:creado:estado:uuid:protocolos
```

### Operaciones disponibles:
- ✅ Crear usuario (SSH + V2Ray/VLESS/Trojan)
- ✅ Ver usuarios activos con estado y vencimiento
- ✅ Editar contraseña, vencimiento o límite de conexiones
- ✅ Eliminar usuario (sistema + DB + protocolos)
- ✅ Renovar expiración
- ✅ Bloquear/Desbloquear
- ✅ Ver conexiones activas en tiempo real
- ✅ Ver usuarios expirados
- ✅ Generar QR con links de conexión

---

## Configuración Nginx (Proxy Reverso SSL)

Todos los protocolos WebSocket se exponen bajo HTTPS a través de Nginx:

| Path       | Protocolo   |
|-----------|-------------|
| /ssh-ws   | SSH WS      |
| /v2ray    | VMess WS    |
| /vless    | VLESS WS    |
| /trojan   | Trojan WS   |

---

## Payload para HTTP Injector / HTTP Custom

### Método WebSocket (Puerto 80):
```
GET / HTTP/1.1[crlf]
Host: TU_DOMINIO[crlf]
Upgrade: websocket[crlf]
Connection: Upgrade[crlf]
[crlf]
```

### Método SSL (Puerto 443):
```
GET wss://TU_DOMINIO/ssh-ws HTTP/1.1[crlf]
Host: TU_DOMINIO[crlf]
Upgrade: websocket[crlf]
[crlf]
```

---

## Archivos de Configuración Importantes

| Archivo                          | Descripción               |
|---------------------------------|---------------------------|
| `/etc/vpn-panel/config/panel.conf` | Dominio, email, fecha   |
| `/etc/vpn-panel/users/users.db`    | Base de datos de usuarios|
| `/etc/xray/config-vless.json`      | Configuración VLESS      |
| `/etc/xray/config-trojan.json`     | Configuración Trojan     |
| `/etc/v2ray/config.json`           | Configuración V2Ray      |
| `/etc/hysteria/config.json`        | Configuración Hysteria   |
| `/etc/nginx/conf.d/vpn-main.conf`  | Proxy reverso Nginx      |

---

## Comandos Útiles

```bash
# Abrir panel
vpn

# Ver estado de servicios
systemctl status xray v2ray hysteria nginx dropbear

# Ver logs en tiempo real
journalctl -u xray -f
journalctl -u hysteria -f

# Reiniciar todos los servicios VPN
systemctl restart xray v2ray hysteria nginx dropbear badvpn-udpgw

# Ver conexiones SSH activas
who
ss -tnp | grep sshd
```

---

## Requisitos del Servidor

- Ubuntu 20.04 o 22.04
- Mínimo 1 GB RAM (recomendado 2 GB)
- Mínimo 10 GB disco
- Acceso root
- Dominio apuntando al servidor (para SSL)
- Puertos abiertos: 22, 80, 443, 1194, 1195, 36712, 53/udp

---

## Notas de Seguridad

- Fail2Ban se instala automáticamente para proteger SSH
- UFW configura solo los puertos necesarios
- Los certificados SSL se renuevan automáticamente via cron
- Se recomienda cambiar el puerto SSH de 22 después de la instalación
