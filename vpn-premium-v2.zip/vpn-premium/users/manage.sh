#!/bin/bash
# ============================================================
#   MÓDULO: Gestión Completa de Usuarios
# ============================================================

USERS_DB="$BASE_DIR/users/users.db"

# ── CREAR USUARIO ───────────────────────────────────────────
create_user() {
    show_banner
    echo -e "  ${YELLOW}══════════════════ CREAR USUARIO ════════════════════${NC}"
    echo ""

    echo -ne "  ${WHITE}Nombre de usuario : ${NC}"; read -r USERNAME
    [[ -z "$USERNAME" ]] && { echo -e "  ${RED}Nombre inválido.${NC}"; sleep 1; return; }

    # Verificar si ya existe
    if grep -q "^${USERNAME}:" "$USERS_DB" 2>/dev/null; then
        echo -e "  ${RED}El usuario '$USERNAME' ya existe.${NC}"; sleep 2; return
    fi

    echo -ne "  ${WHITE}Contraseña (vacío=auto): ${NC}"; read -r PASSWORD
    [[ -z "$PASSWORD" ]] && PASSWORD=$(openssl rand -base64 10 | tr -dc 'a-zA-Z0-9' | head -c 10)

    echo -ne "  ${WHITE}Días de expiración [30]: ${NC}"; read -r DAYS
    [[ -z "$DAYS" ]] && DAYS=30

    echo -ne "  ${WHITE}Máx. conexiones simultáneas [2]: ${NC}"; read -r MAX_CONN
    [[ -z "$MAX_CONN" ]] && MAX_CONN=2

    echo ""
    echo -e "  ${CYAN}── Selecciona protocolos para este usuario ──${NC}"
    echo -e "  ${GREEN}[1]${NC} SSH + WebSocket"
    echo -e "  ${GREEN}[2]${NC} V2Ray VMess"
    echo -e "  ${GREEN}[3]${NC} VLESS WebSocket"
    echo -e "  ${GREEN}[4]${NC} Trojan"
    echo -e "  ${GREEN}[5]${NC} Todos"
    echo -ne "  ${WHITE}Protocolos [5]: ${NC}"; read -r PROTO_OPT
    [[ -z "$PROTO_OPT" ]] && PROTO_OPT=5

    local EXPIRE_DATE
    EXPIRE_DATE=$(date -d "+${DAYS} days" '+%Y-%m-%d')

    # ── Crear usuario del sistema para SSH ──────────────────
    useradd -m -s /bin/bash -e "$EXPIRE_DATE" "$USERNAME" 2>/dev/null
    echo "$USERNAME:$PASSWORD" | chpasswd

    # ── Guardar en DB ───────────────────────────────────────
    mkdir -p "$(dirname "$USERS_DB")"
    local UUID
    UUID=$(cat /proc/sys/kernel/random/uuid)
    local CREATED
    CREATED=$(date '+%Y-%m-%d')

    echo "${USERNAME}:${PASSWORD}:${EXPIRE_DATE}:${MAX_CONN}:${CREATED}:active:${UUID}:${PROTO_OPT}" \
        >> "$USERS_DB"

    # ── Agregar UUID a V2Ray/Xray si aplica ─────────────────
    if [[ "$PROTO_OPT" =~ [245] ]]; then
        _add_user_v2ray "$USERNAME" "$UUID"
    fi
    if [[ "$PROTO_OPT" =~ [345] ]]; then
        _add_user_xray "$USERNAME" "$UUID"
    fi

    # ── Mostrar información del usuario ─────────────────────
    echo ""
    echo -e "  ${GREEN}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "  ${GREEN}║         USUARIO CREADO EXITOSAMENTE              ║${NC}"
    echo -e "  ${GREEN}╚══════════════════════════════════════════════════╝${NC}"
    echo ""
    _show_user_info "$USERNAME"

    echo -ne "\n  ${WHITE}Presiona ENTER para continuar...${NC}"; read -r
}

# ── MOSTRAR INFO USUARIO ────────────────────────────────────
_show_user_info() {
    local USER="$1"
    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"
    local HOST="${DOMAIN:-$(curl -s ifconfig.me 2>/dev/null)}"

    local LINE
    LINE=$(grep "^${USER}:" "$USERS_DB" 2>/dev/null)
    [[ -z "$LINE" ]] && { echo -e "  ${RED}Usuario no encontrado.${NC}"; return; }

    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"

    echo -e "  ${WHITE}Usuario      :${NC} $u"
    echo -e "  ${WHITE}Contraseña   :${NC} $pass"
    echo -e "  ${WHITE}Vencimiento  :${NC} $exp"
    echo -e "  ${WHITE}Max Conexiones:${NC} $maxc"
    echo -e "  ${WHITE}Creado       :${NC} $created"
    echo -e "  ${WHITE}Estado       :${NC} $status"
    echo -e "  ${WHITE}UUID         :${NC} $uuid"
    echo ""
    echo -e "  ${CYAN}── DATOS DE CONEXIÓN ──────────────────────────────${NC}"
    echo -e "  ${WHITE}Host SSH (WS80) :${NC} $HOST:80"
    echo -e "  ${WHITE}Host SSH (WS443):${NC} $HOST:443"
    echo -e "  ${WHITE}Payload WS      :${NC} GET / HTTP/1.1[crlf]Host: $HOST[crlf]Upgrade: websocket[crlf][crlf]"
    echo ""
    if [[ "$proto" =~ [245] ]]; then
        echo -e "  ${WHITE}VMess Link:${NC}"
        local VMESS_JSON="{\"v\":\"2\",\"ps\":\"${u}\",\"add\":\"${HOST}\",\"port\":\"443\",\"id\":\"${uuid}\",\"aid\":\"0\",\"net\":\"ws\",\"path\":\"/v2ray\",\"tls\":\"tls\"}"
        echo -e "  ${CYAN}vmess://$(echo -n "$VMESS_JSON" | base64 -w 0)${NC}"
    fi
    if [[ "$proto" =~ [345] ]]; then
        echo -e "  ${WHITE}VLESS Link:${NC}"
        echo -e "  ${CYAN}vless://${uuid}@${HOST}:443?encryption=none&security=tls&type=ws&path=/vless#${u}${NC}"
    fi
}

# ── LISTAR USUARIOS ─────────────────────────────────────────
list_users() {
    show_banner
    echo -e "  ${YELLOW}══════════════════ USUARIOS ACTIVOS ════════════════${NC}"
    echo ""
    printf "  %-16s %-14s %-8s %-8s %-8s\n" "USUARIO" "VENCIMIENTO" "CONEX." "ESTADO" "TIPO"
    echo -e "  ${CYAN}──────────────────────────────────────────────────────${NC}"

    if [[ ! -f "$USERS_DB" ]]; then
        echo -e "  ${YELLOW}No hay usuarios registrados.${NC}"
    else
        while IFS=':' read -r u pass exp maxc created status uuid proto; do
            local today
            today=$(date '+%Y-%m-%d')
            local color="${GREEN}"
            [[ "$status" == "blocked" ]] && color="${RED}"
            [[ "$exp" < "$today" ]] && color="${YELLOW}"

            printf "  ${color}%-16s %-14s %-8s %-8s %-8s${NC}\n" \
                "$u" "$exp" "$maxc" "$status" "P${proto}"
        done < "$USERS_DB"
    fi

    echo ""
    echo -e "  ${WHITE}Total usuarios: $(wc -l < "$USERS_DB" 2>/dev/null || echo 0)${NC}"
    echo -ne "\n  ${WHITE}Presiona ENTER...${NC}"; read -r
}

# ── EDITAR USUARIO ──────────────────────────────────────────
edit_user() {
    show_banner
    echo -e "  ${YELLOW}══════════════════ EDITAR USUARIO ══════════════════${NC}"
    echo ""

    list_users_simple
    echo -ne "  ${WHITE}Usuario a editar: ${NC}"; read -r USERNAME
    [[ -z "$USERNAME" ]] && return

    local LINE
    LINE=$(grep "^${USERNAME}:" "$USERS_DB" 2>/dev/null)
    [[ -z "$LINE" ]] && { echo -e "  ${RED}Usuario no encontrado.${NC}"; sleep 2; return; }

    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"

    echo ""
    echo -e "  ${CYAN}Datos actuales de '$USERNAME':${NC}"
    echo -e "  Contraseña: $pass | Vencimiento: $exp | Max. conn: $maxc"
    echo ""
    echo -e "  ${GREEN}[1]${NC} Cambiar contraseña"
    echo -e "  ${GREEN}[2]${NC} Cambiar vencimiento"
    echo -e "  ${GREEN}[3]${NC} Cambiar máx. conexiones"
    echo -ne "  ${WHITE}Qué editar: ${NC}"; read -r EDIT_OPT

    case $EDIT_OPT in
        1)
            echo -ne "  Nueva contraseña: "; read -r NEW_PASS
            [[ -z "$NEW_PASS" ]] && NEW_PASS=$(openssl rand -base64 10 | tr -dc 'a-zA-Z0-9' | head -c 10)
            echo "$USERNAME:$NEW_PASS" | chpasswd
            sed -i "s/^${u}:${pass}:/${u}:${NEW_PASS}:/" "$USERS_DB"
            echo -e "  ${GREEN}✔ Contraseña actualizada.${NC}"
            ;;
        2)
            echo -ne "  Días a agregar desde hoy: "; read -r DAYS
            local NEW_EXP
            NEW_EXP=$(date -d "+${DAYS} days" '+%Y-%m-%d')
            chage -E "$NEW_EXP" "$USERNAME" 2>/dev/null
            sed -i "s/^${u}:${pass}:${exp}:/${u}:${pass}:${NEW_EXP}:/" "$USERS_DB"
            echo -e "  ${GREEN}✔ Vencimiento actualizado a: $NEW_EXP${NC}"
            ;;
        3)
            echo -ne "  Nuevo límite de conexiones: "; read -r NEW_CONN
            sed -i "s/^${u}:${pass}:${exp}:${maxc}:/${u}:${pass}:${exp}:${NEW_CONN}:/" "$USERS_DB"
            echo -e "  ${GREEN}✔ Límite actualizado a: $NEW_CONN${NC}"
            ;;
    esac

    sleep 2
}

# ── ELIMINAR USUARIO ────────────────────────────────────────
delete_user() {
    show_banner
    echo -e "  ${YELLOW}══════════════════ ELIMINAR USUARIO ════════════════${NC}"
    echo ""

    list_users_simple
    echo -ne "  ${WHITE}Usuario a eliminar: ${NC}"; read -r USERNAME
    [[ -z "$USERNAME" ]] && return

    if ! grep -q "^${USERNAME}:" "$USERS_DB" 2>/dev/null; then
        echo -e "  ${RED}Usuario no encontrado.${NC}"; sleep 2; return
    fi

    echo -ne "  ${RED}¿Confirmar eliminación de '$USERNAME'? [s/N]: ${NC}"; read -r CONF
    [[ "${CONF,,}" != "s" ]] && return

    # Eliminar del sistema
    pkill -u "$USERNAME" 2>/dev/null
    userdel -r "$USERNAME" 2>/dev/null

    # Eliminar de la DB
    sed -i "/^${USERNAME}:/d" "$USERS_DB"

    echo -e "  ${GREEN}✔ Usuario '$USERNAME' eliminado.${NC}"
    sleep 2
}

# ── RENOVAR USUARIO ─────────────────────────────────────────
renew_user() {
    list_users_simple
    echo -ne "  ${WHITE}Usuario a renovar: ${NC}"; read -r USERNAME
    echo -ne "  ${WHITE}Días a agregar: ${NC}"; read -r DAYS

    local LINE
    LINE=$(grep "^${USERNAME}:" "$USERS_DB" 2>/dev/null)
    [[ -z "$LINE" ]] && { echo -e "  ${RED}No encontrado.${NC}"; sleep 2; return; }

    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"
    local NEW_EXP
    NEW_EXP=$(date -d "$exp +${DAYS} days" '+%Y-%m-%d' 2>/dev/null || date -d "+${DAYS} days" '+%Y-%m-%d')

    sed -i "s/^${u}:${pass}:${exp}:/${u}:${pass}:${NEW_EXP}:/" "$USERS_DB"
    chage -E "$NEW_EXP" "$USERNAME" 2>/dev/null
    echo -e "  ${GREEN}✔ Renovado hasta: $NEW_EXP${NC}"
    sleep 2
}

# ── BLOQUEAR / DESBLOQUEAR ──────────────────────────────────
toggle_user() {
    list_users_simple
    echo -ne "  ${WHITE}Usuario: ${NC}"; read -r USERNAME

    local LINE
    LINE=$(grep "^${USERNAME}:" "$USERS_DB" 2>/dev/null)
    [[ -z "$LINE" ]] && { echo -e "  ${RED}No encontrado.${NC}"; sleep 2; return; }

    IFS=':' read -r u pass exp maxc created status uuid proto <<< "$LINE"

    if [[ "$status" == "active" ]]; then
        usermod -L "$USERNAME" 2>/dev/null
        pkill -u "$USERNAME" 2>/dev/null
        sed -i "s/:active:/:blocked:/" "$USERS_DB"
        echo -e "  ${RED}✔ Usuario bloqueado.${NC}"
    else
        usermod -U "$USERNAME" 2>/dev/null
        sed -i "s/:blocked:/:active:/" "$USERS_DB"
        echo -e "  ${GREEN}✔ Usuario desbloqueado.${NC}"
    fi
    sleep 2
}

# ── CONEXIONES ACTIVAS ──────────────────────────────────────
active_connections() {
    show_banner
    echo -e "  ${YELLOW}══════════════ CONEXIONES ACTIVAS ══════════════════${NC}"
    echo ""
    echo -e "  ${CYAN}── SSH ──────────────────────────────────────────────${NC}"
    who 2>/dev/null | awk '{print "  " $1, $3, $4}' | head -20
    echo ""
    echo -e "  ${CYAN}── Procesos SSH por usuario ─────────────────────────${NC}"
    ss -tnp 2>/dev/null | grep "sshd" | awk '{print "  " $4, $5}' | head -20
    echo ""
    echo -ne "  ${WHITE}Presiona ENTER...${NC}"; read -r
}

# ── USUARIOS EXPIRADOS ──────────────────────────────────────
expired_users() {
    show_banner
    echo -e "  ${YELLOW}════════════════ USUARIOS EXPIRADOS ════════════════${NC}"
    echo ""

    local today
    today=$(date '+%Y-%m-%d')
    local found=0

    while IFS=':' read -r u pass exp maxc created status uuid proto; do
        if [[ "$exp" < "$today" ]]; then
            printf "  ${RED}%-16s ${NC}Expiró: %s\n" "$u" "$exp"
            found=1
        fi
    done < "$USERS_DB" 2>/dev/null

    [[ $found -eq 0 ]] && echo -e "  ${GREEN}No hay usuarios expirados.${NC}"
    echo ""
    echo -ne "  ${WHITE}Presiona ENTER...${NC}"; read -r
}

# ── GENERAR QR ──────────────────────────────────────────────
generate_qr() {
    list_users_simple
    echo -ne "  ${WHITE}Usuario para QR: ${NC}"; read -r USERNAME

    local LINE
    LINE=$(grep "^${USERNAME}:" "$USERS_DB" 2>/dev/null)
    [[ -z "$LINE" ]] && { echo -e "  ${RED}No encontrado.${NC}"; sleep 2; return; }

    _show_user_info "$USERNAME"
    echo -ne "\n  ${WHITE}Presiona ENTER...${NC}"; read -r
}

# ── HELPER: Lista simple ────────────────────────────────────
list_users_simple() {
    echo ""
    echo -e "  ${CYAN}Usuarios disponibles:${NC}"
    cut -d':' -f1 "$USERS_DB" 2>/dev/null | while read -r u; do
        echo -e "  • $u"
    done
    echo ""
}

# ── AGREGAR UUID A V2RAY ────────────────────────────────────
_add_user_v2ray() {
    local USER="$1"
    local UUID="$2"
    local CONF="/etc/v2ray/config.json"
    [[ ! -f "$CONF" ]] && return

    # Insertar cliente en la lista de clients usando python3
    python3 - <<PYEOF 2>/dev/null
import json, sys

with open("$CONF", "r") as f:
    c = json.load(f)

new_client = {"id": "$UUID", "alterId": 0}
for inb in c.get("inbounds", []):
    if inb.get("protocol") == "vmess":
        inb["settings"]["clients"].append(new_client)

with open("$CONF", "w") as f:
    json.dump(c, f, indent=2)
PYEOF

    systemctl restart v2ray 2>/dev/null
}

# ── AGREGAR UUID A XRAY ─────────────────────────────────────
_add_user_xray() {
    local USER="$1"
    local UUID="$2"
    for CONF in /etc/xray/config-vless.json /etc/xray/config-trojan.json; do
        [[ ! -f "$CONF" ]] && continue
        python3 - <<PYEOF 2>/dev/null
import json

with open("$CONF", "r") as f:
    c = json.load(f)

for inb in c.get("inbounds", []):
    if inb.get("protocol") in ["vless", "trojan"]:
        inb["settings"]["clients"].append({"id": "$UUID", "level": 0})

with open("$CONF", "w") as f:
    json.dump(c, f, indent=2)
PYEOF
    done
    systemctl restart xray 2>/dev/null
}
