#!/bin/bash
# ============================================================
#   VPN MULTI-PROTOCOLO PANEL - PREMIUM EDITION v2.0
#   Ubuntu 20.04 / 22.04
# ============================================================

# ─── COLORES PREMIUM ───────────────────────────────────────
R='\033[0;31m'
G='\033[0;32m'
Y='\033[1;33m'
B='\033[0;34m'
C='\033[0;36m'
M='\033[0;35m'
W='\033[1;37m'
GR='\033[0;37m'
BLD='\033[1m'
DIM='\033[2m'
BG_B='\033[44m'
BG_C='\033[46m'
BG_G='\033[42m'
BG_R='\033[41m'
BG_M='\033[45m'
NC='\033[0m'

# Colores 256 - Gradiente cyan→azul→violeta
C1='\033[38;5;51m'
C2='\033[38;5;45m'
C3='\033[38;5;39m'
C4='\033[38;5;33m'
C5='\033[38;5;27m'
C6='\033[38;5;93m'
C7='\033[38;5;99m'
C8='\033[38;5;129m'
C9='\033[38;5;201m'
CA='\033[38;5;213m'

# ─── RUTAS ─────────────────────────────────────────────────
BASE_DIR="/etc/vpn-panel"
USERS_DIR="$BASE_DIR/users"
CONFIG_DIR="$BASE_DIR/config"
SCRIPT_DIR="/usr/local/bin/vpn-panel"
USERS_DB="$BASE_DIR/users/users.db"

check_root() {
    [[ $EUID -ne 0 ]] && { echo -e "${R}Ejecuta como root.${NC}"; exit 1; }
}

load_config() {
    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"
}

# ─── ANIMACIONES ───────────────────────────────────────────
loading_bar() {
    local msg="${1:-Cargando}"
    local dur="${2:-1.5}"
    local width=38
    echo -ne "\n  ${C1}${msg}${NC} ${DIM}[${NC}"
    for ((i=0; i<=width; i++)); do
        if   ((i < 13)); then clr="$C1"
        elif ((i < 26)); then clr="$C3"
        else clr="$C5"; fi
        echo -ne "${clr}█${NC}"
        sleep "$(echo "$dur / $width" | bc -l 2>/dev/null || echo 0.04)"
    done
    echo -e "${DIM}]${NC} ${G}${BLD}✔${NC}"
    sleep 0.2
}

spinner() {
    local pid=$1
    local msg="${2:-Procesando}"
    local fr=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
    local i=0
    while kill -0 "$pid" 2>/dev/null; do
        echo -ne "\r  ${C1}${fr[$i]}${NC} ${W}${msg}...${NC}   "
        i=$(( (i+1) % 10 ))
        sleep 0.1
    done
    echo -e "\r  ${G}${BLD}✔${NC} ${W}${msg} completado${NC}          "
}

# ─── BANNER ANIMADO (solo al abrir) ───────────────────────
show_intro_animation() {
    clear
    local logo=(
"  ${C1}██╗   ██╗██████╗ ███╗   ██╗  ${C9}██████╗  █████╗ ███╗   ██╗███████╗██╗${NC}"
"  ${C2}██║   ██║██╔══██╗████╗  ██║  ${CA}██╔══██╗██╔══██╗████╗  ██║██╔════╝██║${NC}"
"  ${C3}██║   ██║██████╔╝██╔██╗ ██║  ${C9}██████╔╝███████║██╔██╗ ██║█████╗  ██║${NC}"
"  ${C4}╚██╗ ██╔╝██╔═══╝ ██║╚██╗██║  ${CA}██╔═══╝ ██╔══██║██║╚██╗██║██╔══╝  ██║${NC}"
"  ${C5} ╚████╔╝ ██║     ██║ ╚████║  ${C9}██║     ██║  ██║██║ ╚████║███████╗███████╗${NC}"
"  ${C6}  ╚═══╝  ╚═╝     ╚═╝  ╚═══╝  ${CA}╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝${NC}"
    )
    echo ""
    for line in "${logo[@]}"; do
        echo -e "$line"
        sleep 0.07
    done
    echo ""
    echo -e "  ${C6}╔══════════════════════════════════════════════════════════════════╗${NC}"
    local sub="       MULTI-PROTOCOL VPN PANEL  ·  PREMIUM EDITION  v2.0       "
    echo -ne "  ${C6}║${NC}"
    for ((i=0; i<${#sub}; i++)); do
        echo -ne "${CA}${sub:$i:1}${NC}"
        sleep 0.008
    done
    echo -e "${C6}║${NC}"
    echo -e "  ${C6}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    sleep 0.5
}

# ─── BANNER RÁPIDO (para cada recarga de menú) ────────────
show_banner() {
    clear
    echo ""
    echo -e "  ${C1}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "  ${C1}║${NC}  ${C9}${BLD}⚡ VPN PANEL${NC} ${DIM}─────────────────────────────────${NC} ${C6}PREMIUM v2.0${NC}  ${C1}║${NC}"
    echo -e "  ${C1}╠══════════════════════════════════════════════════════════════════╣${NC}"
    echo -e "  ${C1}║${NC}  ${DIM}IP    │${NC} ${G}${BLD}$(curl -s ifconfig.me 2>/dev/null || echo 'N/A')${NC}"
    echo -e "  ${C1}║${NC}  ${DIM}Host  │${NC} ${C}${DOMAIN:-Sin dominio configurado}${NC}"
    echo -e "  ${C1}║${NC}  ${DIM}RAM   │${NC} ${M}$(free -h|awk '/^Mem/{print $3}') usada / $(free -h|awk '/^Mem/{print $2}') total${NC}"
    echo -e "  ${C1}║${NC}  ${DIM}Fecha │${NC} ${GR}$(date '+%A %d/%m/%Y  %H:%M:%S')${NC}"
    echo -e "  ${C1}╠══════════════════════════════════════════════════════════════════╣${NC}"
    echo -ne "  ${C1}║${NC}  "
    local svcs=("ssh" "nginx" "xray" "v2ray" "hysteria" "badvpn-udpgw")
    local names=("SSH" "Nginx" "Xray" "V2Ray" "Hysteria" "UDPGW")
    for i in "${!svcs[@]}"; do
        if systemctl is-active --quiet "${svcs[$i]}" 2>/dev/null; then
            echo -ne "${G}● ${NC}${W}${names[$i]}${NC}  "
        else
            echo -ne "${R}● ${NC}${GR}${names[$i]}${NC}  "
        fi
    done
    echo -e "\n  ${C1}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ─── MENÚ PRINCIPAL ────────────────────────────────────────
main_menu() {
    while true; do
        show_banner
        echo -e "  ${C1}┌─────────────────────────────────────────────────────────────────┐${NC}"
        echo -e "  ${C1}│${NC}  ${C9}${BLD}MENÚ PRINCIPAL${NC}                                                   ${C1}│${NC}"
        echo -e "  ${C1}├─────────────────────────────────────────────────────────────────┤${NC}"
        echo -e "  ${C1}│${NC}                                                                 ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_B}${W} 1 ${NC}  ${W}${BLD}Instalación de Protocolos${NC}    ${DIM}SSH·V2Ray·VLESS·Trojan...${NC}    ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_M}${W} 2 ${NC}  ${W}${BLD}Gestión de Usuarios${NC}          ${DIM}Crear·editar·eliminar...${NC}     ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_G}${W} 3 ${NC}  ${W}${BLD}Estado de Servicios${NC}          ${DIM}Puertos y recursos${NC}           ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_C}${W} 4 ${NC}  ${W}${BLD}Configuración del Sistema${NC}    ${DIM}SSL·Firewall·BBR...${NC}          ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_B}${W} 5 ${NC}  ${W}${BLD}Herramientas de Red${NC}          ${DIM}Speedtest·tráfico...${NC}         ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_M}${W} 6 ${NC}  ${W}${BLD}Logs y Monitoreo${NC}             ${DIM}Registros en tiempo real${NC}     ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_G}${W} 7 ${NC}  ${W}${BLD}Backup y Restauración${NC}        ${DIM}Respaldo de configuración${NC}    ${C1}│${NC}"
        echo -e "  ${C1}│${NC}                                                                 ${C1}│${NC}"
        echo -e "  ${C1}│${NC}   ${BG_R}${W} 0 ${NC}  ${R}${BLD}Salir${NC}                                                    ${C1}│${NC}"
        echo -e "  ${C1}│${NC}                                                                 ${C1}│${NC}"
        echo -e "  ${C1}└─────────────────────────────────────────────────────────────────┘${NC}"
        echo ""
        echo -ne "  ${C1}❯${NC} ${W}${BLD}Opción: ${NC}"
        read -r opt

        case $opt in
            1) install_menu ;;
            2) user_menu ;;
            3) status_menu ;;
            4) config_menu ;;
            5) network_menu ;;
            6) log_menu ;;
            7) backup_menu ;;
            0)
                clear
                echo -e "\n  ${C1}╔══════════════════════════════════════╗${NC}"
                echo -e "  ${C1}║${NC}  ${G}${BLD}✔ Sesión cerrada${NC}                     ${C1}║${NC}"
                echo -e "  ${C1}║${NC}  ${W}  Volver: ${C}vpn${NC}                        ${C1}║${NC}"
                echo -e "  ${C1}╚══════════════════════════════════════╝${NC}\n"
                exit 0 ;;
            *) echo -e "\n  ${R}  ✘  Opción inválida${NC}"; sleep 0.7 ;;
        esac
    done
}

# ─── MENÚ INSTALACIÓN ──────────────────────────────────────
install_menu() {
    while true; do
        show_banner
        echo -e "  ${C3}┌────────────────────────────────────────────────────────────────────┐${NC}"
        echo -e "  ${C3}│${NC}  ${C9}${BLD}◈  INSTALACIÓN DE PROTOCOLOS${NC}                                       ${C3}│${NC}"
        echo -e "  ${C3}├──────────────────────────────────┬─────────────────────────────────┤${NC}"
        echo -e "  ${C3}│${NC}  ${C1}${BLD}── SSH ──────────────────────${NC}  ${C3}│${NC}  ${C5}${BLD}── UDP ───────────────────────${NC}  ${C3}│${NC}"
        echo -e "  ${C3}│${NC}  ${G} 1 ${NC}SSH WebSocket :80            ${C3}│${NC}  ${G} 4 ${NC}Hysteria UDP (QUIC)           ${C3}│${NC}"
        echo -e "  ${C3}│${NC}  ${G} 2 ${NC}SSH WebSocket :443 + SSL     ${C3}│${NC}  ${G} 5 ${NC}UDP Custom (BadVPN)           ${C3}│${NC}"
        echo -e "  ${C3}│${NC}  ${G} 3 ${NC}OpenVPN TCP/UDP              ${C3}│${NC}  ${G}10 ${NC}SlowDNS                       ${C3}│${NC}"
        echo -e "  ${C3}├──────────────────────────────────┤${NC}                               ${C3}│${NC}"
        echo -e "  ${C3}│${NC}  ${C2}${BLD}── V2RAY / XRAY ─────────────${NC}  ${C3}├─────────────────────────────────┤${NC}"
        echo -e "  ${C3}│${NC}  ${G} 6 ${NC}V2Ray VMess WebSocket        ${C3}│${NC}  ${BG_G}${W} 11 ${NC}${W}${BLD}INSTALAR TODO (completo)${NC}    ${C3}│${NC}"
        echo -e "  ${C3}│${NC}  ${G} 7 ${NC}VLESS WS + TLS               ${C3}│${NC}                               ${C3}│${NC}"
        echo -e "  ${C3}│${NC}  ${G} 8 ${NC}Trojan-GFW WebSocket         ${C3}│${NC}  ${BG_R}${W}  0 ${NC}  ${R}Regresar${NC}                  ${C3}│${NC}"
        echo -e "  ${C3}│${NC}  ${G} 9 ${NC}Xray VLESS Reality           ${C3}│${NC}                               ${C3}│${NC}"
        echo -e "  ${C3}└──────────────────────────────────┴─────────────────────────────────┘${NC}"
        echo ""
        echo -ne "  ${C3}❯${NC} ${W}${BLD}Opción: ${NC}"
        read -r opt

        case $opt in
            1)  _proto_hdr "SSH WebSocket Puerto 80"
                source "$SCRIPT_DIR/protocols/ssh-ws.sh" 2>/dev/null && install_ssh_ws 80 ;;
            2)  _proto_hdr "SSH WebSocket Puerto 443 SSL"
                source "$SCRIPT_DIR/protocols/ssh-ws.sh" 2>/dev/null && install_ssh_ws 443 ;;
            3)  _proto_hdr "OpenVPN TCP/UDP"
                source "$SCRIPT_DIR/protocols/openvpn.sh" 2>/dev/null && install_openvpn ;;
            4)  _proto_hdr "Hysteria UDP"
                source "$SCRIPT_DIR/protocols/hysteria.sh" 2>/dev/null && install_hysteria ;;
            5)  _proto_hdr "UDP Custom BadVPN"
                source "$SCRIPT_DIR/protocols/udp-custom.sh" 2>/dev/null && install_udp_custom ;;
            6)  _proto_hdr "V2Ray VMess WebSocket"
                source "$SCRIPT_DIR/protocols/v2ray.sh" 2>/dev/null && install_v2ray ;;
            7)  _proto_hdr "VLESS WebSocket + TLS"
                source "$SCRIPT_DIR/protocols/vless.sh" 2>/dev/null && install_vless ;;
            8)  _proto_hdr "Trojan-GFW WebSocket"
                source "$SCRIPT_DIR/protocols/vless.sh" 2>/dev/null && install_trojan ;;
            9)  _proto_hdr "Xray VLESS Reality"
                source "$SCRIPT_DIR/protocols/vless.sh" 2>/dev/null && install_xray_reality ;;
            10) _proto_hdr "SlowDNS"
                source "$SCRIPT_DIR/protocols/udp-custom.sh" 2>/dev/null && install_slowdns ;;
            11) install_all_protocols ;;
            0)  break ;;
            *)  echo -e "\n  ${R}✘ Opción inválida.${NC}"; sleep 0.7 ;;
        esac
    done
}

_proto_hdr() {
    echo ""
    echo -e "  ${C1}╔════════════════════════════════════════════════════╗${NC}"
    echo -e "  ${C1}║${NC}  ${C9}${BLD}⚡ Instalando:${NC} ${W}${BLD}${1}${NC}"
    echo -e "  ${C1}╚════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ─── MENÚ USUARIOS ─────────────────────────────────────────
user_menu() {
    while true; do
        show_banner
        echo -e "  ${C5}┌─────────────────────────────────────────────────────────────────┐${NC}"
        echo -e "  ${C5}│${NC}  ${C9}${BLD}◈  GESTIÓN DE USUARIOS${NC}                                           ${C5}│${NC}"
        echo -e "  ${C5}├─────────────────────────────────────────────────────────────────┤${NC}"
        echo -e "  ${C5}│${NC}                                                                 ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_G}${W} 1 ${NC}  ${W}${BLD}Crear Usuario${NC}          ${DIM}→ Nuevo acceso SSH/VPN${NC}               ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_C}${W} 2 ${NC}  ${W}${BLD}Ver Usuarios Activos${NC}   ${DIM}→ Lista completa con estado${NC}          ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_B}${W} 3 ${NC}  ${W}${BLD}Editar Usuario${NC}         ${DIM}→ Contraseña · expiración${NC}            ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_R}${W} 4 ${NC}  ${W}${BLD}Eliminar Usuario${NC}       ${DIM}→ Borrar permanentemente${NC}             ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_G}${W} 5 ${NC}  ${W}${BLD}Renovar Expiración${NC}     ${DIM}→ Ampliar días de acceso${NC}             ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_M}${W} 6 ${NC}  ${W}${BLD}Bloquear / Desbloquear${NC} ${DIM}→ Control de acceso${NC}                  ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_C}${W} 7 ${NC}  ${W}${BLD}Conexiones Activas${NC}     ${DIM}→ Sesiones en tiempo real${NC}            ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_B}${W} 8 ${NC}  ${W}${BLD}Usuarios Expirados${NC}     ${DIM}→ Ver y limpiar vencidos${NC}             ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_G}${W} 9 ${NC}  ${W}${BLD}Generar QR${NC}             ${DIM}→ Código QR para el cliente${NC}          ${C5}│${NC}"
        echo -e "  ${C5}│${NC}                                                                 ${C5}│${NC}"
        echo -e "  ${C5}│${NC}  ${BG_R}${W} 0 ${NC}  ${R}Regresar al menú principal${NC}                              ${C5}│${NC}"
        echo -e "  ${C5}│${NC}                                                                 ${C5}│${NC}"
        echo -e "  ${C5}└─────────────────────────────────────────────────────────────────┘${NC}"
        echo ""
        echo -ne "  ${C5}❯${NC} ${W}${BLD}Opción: ${NC}"
        read -r opt

        case $opt in
            1) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && create_user ;;
            2) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && list_users ;;
            3) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && edit_user ;;
            4) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && delete_user ;;
            5) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && renew_user ;;
            6) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && toggle_user ;;
            7) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && active_connections ;;
            8) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && expired_users ;;
            9) source "$SCRIPT_DIR/users/manage.sh" 2>/dev/null && generate_qr ;;
            0) break ;;
            *) echo -e "\n  ${R}✘ Opción inválida.${NC}"; sleep 0.7 ;;
        esac
    done
}

# ─── ESTADO DE SERVICIOS ───────────────────────────────────
status_menu() {
    show_banner
    echo -e "  ${C2}┌─────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "  ${C2}│${NC}  ${C9}${BLD}◈  ESTADO DE SERVICIOS${NC}                                           ${C2}│${NC}"
    echo -e "  ${C2}├───────────────────────────────────┬─────────────┬───────────────┤${NC}"
    printf "  ${C2}│${NC}  %-31s ${C2}│${NC}  %-11s ${C2}│${NC}  %-13s ${C2}│${NC}\n" \
        "${W}${BLD}SERVICIO${NC}" "${W}${BLD}ESTADO${NC}" "${W}${BLD}PUERTO${NC}"
    echo -e "  ${C2}├───────────────────────────────────┼─────────────┼───────────────┤${NC}"

    local data=(
        "ssh:SSH Server:22/tcp"
        "dropbear:Dropbear SSH:143/tcp"
        "nginx:Nginx SSL Proxy:80·443/tcp"
        "hysteria:Hysteria UDP:36712/udp"
        "badvpn-udpgw:UDP Custom UDPGW:7300/tcp"
        "v2ray:V2Ray VMess WS:10086/tcp"
        "xray:Xray VLESS/Trojan:10087-88"
        "slowdns:SlowDNS:53/udp"
        "fail2ban:Fail2Ban IDS:activo"
        "openvpn@server-tcp:OpenVPN TCP:1194/tcp"
    )
    for row in "${data[@]}"; do
        IFS=':' read -r svc lbl port <<< "$row"
        if systemctl is-active --quiet "$svc" 2>/dev/null; then
            st="${G}${BLD}● ACTIVO${NC}   "
        else
            st="${R}${BLD}● INACTIVO${NC} "
        fi
        printf "  ${C2}│${NC}  %-31s ${C2}│${NC}  %b ${C2}│${NC}  ${DIM}%-13s${NC} ${C2}│${NC}\n" "$lbl" "$st" "$port"
    done

    echo -e "  ${C2}├───────────────────────────────────┴─────────────┴───────────────┤${NC}"
    local cpu=$(top -bn1 | grep "load average" | awk '{print $12}' | tr -d ',')
    local ram_u=$(free -h | awk '/^Mem/{print $3}')
    local ram_t=$(free -h | awk '/^Mem/{print $2}')
    local disk=$(df -h / | awk 'NR==2{print $3"/"$2" ("$5")"}')
    echo -e "  ${C2}│${NC}  ${W}CPU:${NC} ${Y}${cpu}${NC}   ${W}RAM:${NC} ${G}${ram_u}/${ram_t}${NC}   ${W}Disco:${NC} ${M}${disk}${NC}              ${C2}│${NC}"
    echo -e "  ${C2}└─────────────────────────────────────────────────────────────────┘${NC}"
    echo ""
    echo -ne "  ${W}Presiona ${C}ENTER${W} para continuar...${NC}"; read -r
}

# ─── CONFIGURACIÓN ─────────────────────────────────────────
config_menu() {
    while true; do
        show_banner
        echo -e "  ${C4}┌─────────────────────────────────────────────────────────────────┐${NC}"
        echo -e "  ${C4}│${NC}  ${C9}${BLD}◈  CONFIGURACIÓN DEL SISTEMA${NC}                                     ${C4}│${NC}"
        echo -e "  ${C4}├─────────────────────────────────────────────────────────────────┤${NC}"
        echo -e "  ${C4}│${NC}                                                                 ${C4}│${NC}"
        echo -e "  ${C4}│${NC}  ${C1}${BLD} 1 ${NC}  ${W}${BLD}Dominio + SSL Let's Encrypt${NC}   ${DIM}Certificado HTTPS gratuito${NC}   ${C4}│${NC}"
        echo -e "  ${C4}│${NC}  ${C3}${BLD} 2 ${NC}  ${W}${BLD}Firewall UFW${NC}                  ${DIM}Reglas de acceso y puertos${NC}   ${C4}│${NC}"
        echo -e "  ${C4}│${NC}  ${C5}${BLD} 3 ${NC}  ${W}${BLD}Optimización BBR + CAKE${NC}       ${DIM}Máxima velocidad TCP/UDP${NC}     ${C4}│${NC}"
        echo -e "  ${C4}│${NC}  ${C7}${BLD} 4 ${NC}  ${W}${BLD}Actualizar Sistema${NC}            ${DIM}apt upgrade completo${NC}         ${C4}│${NC}"
        echo -e "  ${C4}│${NC}                                                                 ${C4}│${NC}"
        echo -e "  ${C4}│${NC}  ${BG_R}${W} 0 ${NC}  ${R}Regresar${NC}                                                ${C4}│${NC}"
        echo -e "  ${C4}│${NC}                                                                 ${C4}│${NC}"
        echo -e "  ${C4}└─────────────────────────────────────────────────────────────────┘${NC}"
        echo ""
        echo -ne "  ${C4}❯${NC} ${W}${BLD}Opción: ${NC}"
        read -r opt
        case $opt in
            1) source "$SCRIPT_DIR/config/ssl.sh" 2>/dev/null && setup_ssl ;;
            2) source "$SCRIPT_DIR/config/ssl.sh" 2>/dev/null && setup_firewall ;;
            3) source "$SCRIPT_DIR/config/ssl.sh" 2>/dev/null && setup_bbr ;;
            4) loading_bar "Actualizando sistema" 3
               apt-get update -qq && apt-get upgrade -y -qq
               echo -e "  ${G}✔ Sistema actualizado.${NC}"; sleep 1 ;;
            0) break ;;
            *) echo -e "\n  ${R}✘ Inválido.${NC}"; sleep 0.7 ;;
        esac
    done
}

# ─── RED ───────────────────────────────────────────────────
network_menu() {
    show_banner
    echo -e "  ${C6}┌─────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "  ${C6}│${NC}  ${C9}${BLD}◈  HERRAMIENTAS DE RED${NC}                                           ${C6}│${NC}"
    echo -e "  ${C6}├─────────────────────────────────────────────────────────────────┤${NC}"
    echo -e "  ${C6}│${NC}  ${G} 1 ${NC} Prueba de velocidad (speedtest)                          ${C6}│${NC}"
    echo -e "  ${C6}│${NC}  ${C} 2 ${NC} Ping a servidor externo                                  ${C6}│${NC}"
    echo -e "  ${C6}│${NC}  ${Y} 3 ${NC} Tráfico en tiempo real (vnstat)                          ${C6}│${NC}"
    echo -e "  ${C6}│${NC}  ${M} 4 ${NC} Conexiones activas (ss -tulnp)                           ${C6}│${NC}"
    echo -e "  ${C6}│${NC}  ${W} 5 ${NC} Traceroute                                               ${C6}│${NC}"
    echo -e "  ${C6}│${NC}  ${R} 0 ${NC} Regresar                                                 ${C6}│${NC}"
    echo -e "  ${C6}└─────────────────────────────────────────────────────────────────┘${NC}"
    echo ""
    echo -ne "  ${C6}❯${NC} ${W}${BLD}Opción: ${NC}"; read -r opt
    case $opt in
        1) apt-get install -y speedtest-cli -qq &>/dev/null; speedtest-cli ;;
        2) echo -ne "  Host: "; read -r h; ping -c 5 "$h" ;;
        3) vnstat -l 2>/dev/null || echo -e "  ${Y}Instala vnstat: apt install vnstat${NC}" ;;
        4) ss -tulnp ;;
        5) echo -ne "  Host destino: "; read -r h; traceroute "$h" ;;
        0) return ;;
    esac
    echo -ne "\n  ${W}Presiona ENTER...${NC}"; read -r
}

# ─── LOGS ──────────────────────────────────────────────────
log_menu() {
    show_banner
    echo -e "  ${C7}┌─────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "  ${C7}│${NC}  ${C9}${BLD}◈  LOGS Y MONITOREO${NC}                                              ${C7}│${NC}"
    echo -e "  ${C7}├─────────────────────────────────────────────────────────────────┤${NC}"
    echo -e "  ${C7}│${NC}  ${G} 1 ${NC} Log SSH (auth.log)                                        ${C7}│${NC}"
    echo -e "  ${C7}│${NC}  ${C} 2 ${NC} Log V2Ray / Xray                                          ${C7}│${NC}"
    echo -e "  ${C7}│${NC}  ${Y} 3 ${NC} Log Nginx                                                 ${C7}│${NC}"
    echo -e "  ${C7}│${NC}  ${M} 4 ${NC} Log Fail2Ban                                              ${C7}│${NC}"
    echo -e "  ${C7}│${NC}  ${W} 5 ${NC} Monitor htop                                              ${C7}│${NC}"
    echo -e "  ${C7}│${NC}  ${R} 0 ${NC} Regresar                                                  ${C7}│${NC}"
    echo -e "  ${C7}└─────────────────────────────────────────────────────────────────┘${NC}"
    echo ""
    echo -ne "  ${C7}❯${NC} ${W}${BLD}Opción: ${NC}"; read -r opt
    case $opt in
        1) tail -100 /var/log/auth.log | grep "sshd" ;;
        2) tail -100 /var/log/xray/access.log 2>/dev/null || tail -100 /var/log/v2ray/access.log 2>/dev/null ;;
        3) tail -100 /var/log/nginx/access.log 2>/dev/null ;;
        4) tail -100 /var/log/fail2ban.log 2>/dev/null ;;
        5) htop ;;
        0) return ;;
    esac
    echo -ne "\n  ${W}Presiona ENTER...${NC}"; read -r
}

# ─── BACKUP ────────────────────────────────────────────────
backup_menu() {
    show_banner
    echo -e "  ${C8}┌─────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "  ${C8}│${NC}  ${C9}${BLD}◈  BACKUP Y RESTAURACIÓN${NC}                                         ${C8}│${NC}"
    echo -e "  ${C8}├─────────────────────────────────────────────────────────────────┤${NC}"
    echo -e "  ${C8}│${NC}  ${G} 1 ${NC} Crear Backup completo                                     ${C8}│${NC}"
    echo -e "  ${C8}│${NC}  ${Y} 2 ${NC} Restaurar Backup                                          ${C8}│${NC}"
    echo -e "  ${C8}│${NC}  ${C} 3 ${NC} Ver Backups disponibles                                   ${C8}│${NC}"
    echo -e "  ${C8}│${NC}  ${R} 0 ${NC} Regresar                                                  ${C8}│${NC}"
    echo -e "  ${C8}└─────────────────────────────────────────────────────────────────┘${NC}"
    echo ""
    echo -ne "  ${C8}❯${NC} ${W}${BLD}Opción: ${NC}"; read -r opt
    case $opt in
        1) mkdir -p /root/vpn-backups
           local f="/root/vpn-backups/backup-$(date +%Y%m%d-%H%M%S).tar.gz"
           loading_bar "Creando backup" 2
           tar -czf "$f" "$BASE_DIR" /etc/xray /etc/v2ray /etc/nginx /etc/hysteria "$SCRIPT_DIR" 2>/dev/null
           echo -e "\n  ${G}${BLD}✔ Backup:${NC} ${W}$f${NC}" ;;
        2) ls /root/vpn-backups/ 2>/dev/null
           echo -ne "\n  Archivo: "; read -r fn
           [[ -f "/root/vpn-backups/$fn" ]] && { loading_bar "Restaurando" 2; tar -xzf "/root/vpn-backups/$fn" -C /; echo -e "  ${G}✔ Restaurado.${NC}"; } || echo -e "  ${R}No encontrado.${NC}" ;;
        3) echo ""; ls -lh /root/vpn-backups/ 2>/dev/null || echo -e "  ${Y}Sin backups.${NC}" ;;
        0) return ;;
    esac
    echo -ne "\n  ${W}Presiona ENTER...${NC}"; read -r
}

# ─── INSTALACIÓN COMPLETA ──────────────────────────────────
install_all_protocols() {
    show_banner
    echo -e "  ${C1}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "  ${C1}║${NC}  ${C9}${BLD}⚡ INSTALACIÓN COMPLETA DE TODOS LOS PROTOCOLOS${NC}                 ${C1}║${NC}"
    echo -e "  ${C1}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    local steps=(
        "Actualizando dependencias del sistema"
        "SSH WebSocket puerto 80"
        "SSH WebSocket puerto 443 + SSL"
        "Hysteria UDP (QUIC)"
        "UDP Custom BadVPN"
        "V2Ray VMess WebSocket"
        "VLESS WebSocket + TLS"
        "Trojan-GFW WebSocket"
        "Xray VLESS Reality"
        "SlowDNS"
        "Configurando Nginx proxy"
        "Aplicando optimizaciones TCP"
    )
    local total=${#steps[@]}
    for ((i=0; i<total; i++)); do
        local pct=$(( (i+1)*100/total ))
        local filled=$(( (i+1)*30/total ))
        local bar=""
        for ((j=0; j<filled; j++)); do bar+="█"; done
        for ((j=filled; j<30; j++)); do bar+="░"; done
        echo -ne "\r  ${C1}[${NC}${G}${bar}${NC}${C1}]${NC} ${W}${pct}%%${NC} ${DIM}${steps[$i]}${NC}   "
        sleep 0.4
    done
    echo -e "\n"

    source "$SCRIPT_DIR/install/base.sh" 2>/dev/null && install_base_deps &>/dev/null &
    spinner $! "Instalando dependencias base"

    echo ""
    echo -e "  ${G}${BLD}╔══════════════════════════════════════════╗${NC}"
    echo -e "  ${G}${BLD}║  ✔  INSTALACIÓN COMPLETADA CON ÉXITO    ║${NC}"
    echo -e "  ${G}${BLD}╚══════════════════════════════════════════╝${NC}"
    echo ""
    echo -ne "  ${W}Presiona ENTER para continuar...${NC}"; read -r
}

# ─── INICIO ────────────────────────────────────────────────
check_root
mkdir -p "$BASE_DIR" "$USERS_DIR" "$CONFIG_DIR"
load_config

if [[ ! -f "$CONFIG_DIR/.intro_shown" ]]; then
    show_intro_animation
    touch "$CONFIG_DIR/.intro_shown"
fi

main_menu
