#!/bin/bash
# ============================================================
#   INSTALADOR PRINCIPAL - VPN MULTI-PROTOCOLO PANEL
#   Ejecutar como root: bash install.sh
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

BASE_DIR="/etc/vpn-panel"
CONFIG_DIR="$BASE_DIR/config"
SCRIPT_DIR="/usr/local/bin/vpn-panel"

check_root() {
    [[ $EUID -ne 0 ]] && { echo -e "${RED}Debe ejecutarse como root.${NC}"; exit 1; }
}

show_intro() {
    clear
    echo -e "${CYAN}"
    echo "  ╔══════════════════════════════════════════════════════╗"
    echo "  ║      INSTALADOR - VPN MULTI-PROTOCOLO PANEL          ║"
    echo "  ║          Ubuntu 20.04 / 22.04  •  v1.0               ║"
    echo "  ╚══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo -e "  Protocolos incluidos:"
    echo -e "  ${GREEN}•${NC} SSH WebSocket (80/443)"
    echo -e "  ${GREEN}•${NC} UDP Hysteria"
    echo -e "  ${GREEN}•${NC} UDP Custom (BadVPN)"
    echo -e "  ${GREEN}•${NC} V2Ray VMess WebSocket"
    echo -e "  ${GREEN}•${NC} VLESS WebSocket + TLS"
    echo -e "  ${GREEN}•${NC} Trojan-GFW"
    echo -e "  ${GREEN}•${NC} Xray VLESS Reality"
    echo -e "  ${GREEN}•${NC} OpenVPN TCP/UDP"
    echo -e "  ${GREEN}•${NC} SlowDNS"
    echo ""
}

install_panel() {
    check_root
    show_intro

    echo -ne "  ${WHITE}¿Continuar instalación? [s/N]: ${NC}"
    read -r CONF
    [[ "${CONF,,}" != "s" ]] && exit 0

    echo -e "\n  ${CYAN}[1/5]${NC} Creando estructura de directorios..."
    mkdir -p "$BASE_DIR"/{users,config,certs,logs}
    mkdir -p "$SCRIPT_DIR"/{protocols,users,config,install}

    echo -e "  ${CYAN}[2/5]${NC} Copiando módulos del panel..."
    SCRIPT_SOURCE="$(dirname "$(realpath "$0")")"

    cp -r "$SCRIPT_SOURCE/"* "$SCRIPT_DIR/" 2>/dev/null || {
        echo -e "  ${YELLOW}Descargando módulos del repositorio...${NC}"
        # Si se ejecuta directamente, los archivos ya están en su lugar
    }

    echo -e "  ${CYAN}[3/5]${NC} Instalando dependencias del sistema..."
    apt-get update -y -qq
    apt-get install -y \
        curl wget unzip tar git jq uuid-runtime \
        openssl ca-certificates \
        nginx certbot python3-certbot-nginx \
        dropbear stunnel4 squid \
        fail2ban ufw vnstat \
        qrencode bc socat cron \
        python3 python3-pip \
        build-essential cmake \
        --no-install-recommends -qq

    echo -e "  ${CYAN}[4/5]${NC} Configurando sistema..."

    # IP forwarding
    echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/10-vpn.conf
    sysctl -p /etc/sysctl.d/10-vpn.conf >/dev/null 2>&1

    # Deshabilitar IPv6 (opcional, mejora compatibilidad)
    echo -ne "\n  ${WHITE}¿Deshabilitar IPv6? [s/N]: ${NC}"; read -r DISABLE_IPV6
    if [[ "${DISABLE_IPV6,,}" == "s" ]]; then
        cat >> /etc/sysctl.d/10-vpn.conf <<'EOF'
net.ipv6.conf.all.disable_ipv6     = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6      = 1
EOF
        sysctl -p /etc/sysctl.d/10-vpn.conf >/dev/null 2>&1
    fi

    # BBR
    if modprobe tcp_bbr 2>/dev/null; then
        echo "net.core.default_qdisc=fq"                >> /etc/sysctl.d/10-vpn.conf
        echo "net.ipv4.tcp_congestion_control=bbr"      >> /etc/sysctl.d/10-vpn.conf
        sysctl -p /etc/sysctl.d/10-vpn.conf >/dev/null 2>&1
        echo -e "  ${GREEN}✔ BBR activado${NC}"
    fi

    echo -e "  ${CYAN}[5/5]${NC} Instalando comando global 'vpn'..."

    # Crear enlace simbólico global
    cat > /usr/local/bin/vpn <<'VPNEOF'
#!/bin/bash
source /usr/local/bin/vpn-panel/vpn-menu.sh
VPNEOF
    chmod +x /usr/local/bin/vpn

    # Copiar script principal
    cp "$SCRIPT_SOURCE/vpn-menu.sh" "$SCRIPT_DIR/vpn-menu.sh"
    chmod +x "$SCRIPT_DIR/vpn-menu.sh"

    echo ""
    echo -e "  ${GREEN}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "  ${GREEN}║     ✔ PANEL INSTALADO CORRECTAMENTE              ║${NC}"
    echo -e "  ${GREEN}╚══════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  ${WHITE}Para abrir el panel, ejecuta:${NC}"
    echo -e "  ${CYAN}  vpn${NC}"
    echo ""
    echo -e "  ${YELLOW}Pasos siguientes recomendados:${NC}"
    echo -e "  1. Ejecuta ${CYAN}vpn${NC} → Configuración → Configurar Dominio y SSL"
    echo -e "  2. Luego instala los protocolos que necesites"
    echo -e "  3. Crea tus primeros usuarios"
    echo ""
}

install_panel
