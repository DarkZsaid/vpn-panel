#!/bin/bash
# ============================================================
#   MÓDULO: UDP Custom (BadVPN UDPGW)
# ============================================================

UDPGW_PORT="${UDPGW_PORT:-7300}"

install_udp_custom() {
    echo -e "\n  ${CYAN}[UDP-CUSTOM]${NC} Instalando BadVPN UDPGW..."

    apt-get install -y cmake make build-essential 2>/dev/null

    # ── Descargar y compilar badvpn ─────────────────────────
    cd /tmp || return
    rm -rf badvpn
    git clone --depth=1 https://github.com/ambrop72/badvpn.git 2>/dev/null

    if [[ -d /tmp/badvpn ]]; then
        cd /tmp/badvpn
        mkdir build && cd build
        cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 2>/dev/null
        make 2>/dev/null
        install -m 755 udpgw/badvpn-udpgw /usr/local/bin/
        cd /tmp && rm -rf badvpn
    else
        # Fallback: descargar binario precompilado
        wget -q -O /usr/local/bin/badvpn-udpgw \
            "https://github.com/daybreakersx/premscript/raw/master/badvpn-udpgw64"
        chmod +x /usr/local/bin/badvpn-udpgw
    fi

    # ── Servicio systemd ────────────────────────────────────
    cat > /etc/systemd/system/badvpn-udpgw.service <<EOF
[Unit]
Description=BadVPN UDP Gateway
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/badvpn-udpgw \\
    --listen-addr 127.0.0.1:$UDPGW_PORT \\
    --max-clients 1000 \\
    --max-connections-for-client 100
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable --now badvpn-udpgw

    echo -e "  ${GREEN}✔ UDP Custom (BadVPN) instalado${NC}"
    echo -e "  ${WHITE}  Puerto local UDPGW : 127.0.0.1:$UDPGW_PORT${NC}"
    echo -e "  ${WHITE}  Configurar en cliente como UDP Custom${NC}"
}

# ============================================================
#   MÓDULO: SlowDNS
# ============================================================

install_slowdns() {
    echo -e "\n  ${CYAN}[SLOWDNS]${NC} Instalando SlowDNS..."

    local ARCH=$(uname -m)
    local BIN_URL
    case "$ARCH" in
        x86_64)  BIN_URL="https://github.com/helmiau/helmwrt/releases/latest/download/slowdns-linux-amd64" ;;
        aarch64) BIN_URL="https://github.com/helmiau/helmwrt/releases/latest/download/slowdns-linux-arm64" ;;
        *) echo -e "  ${RED}Arquitectura no soportada${NC}"; return 1 ;;
    esac

    wget -q -O /usr/local/bin/slowdns "$BIN_URL" || {
        echo -e "  ${YELLOW}[SLOWDNS]${NC} Descarga alternativa..."
        wget -q -O /usr/local/bin/slowdns \
            "https://github.com/mixool/SlowTunnel/releases/latest/download/slowtunnel-linux-amd64"
    }
    chmod +x /usr/local/bin/slowdns

    # ── Generar claves ──────────────────────────────────────
    mkdir -p /etc/slowdns

    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"

    # Necesita nameserver apuntando al servidor
    local NS_DOMAIN="${SLOWDNS_NS:-ns.${DOMAIN:-example.com}}"

    # Generar par de claves
    local KEYS
    KEYS=$(/usr/local/bin/slowdns -gen-key 2>/dev/null || openssl genrsa 2048 2>/dev/null)
    echo "$KEYS" > /etc/slowdns/keys.txt

    cat > /etc/systemd/system/slowdns.service <<EOF
[Unit]
Description=SlowDNS Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/slowdns server \\
    -udp 0.0.0.0:53 \\
    -privkey /etc/slowdns/keys.txt \\
    -ns $NS_DOMAIN
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable --now slowdns

    echo -e "  ${GREEN}✔ SlowDNS instalado${NC}"
    echo -e "  ${WHITE}  Nameserver  : $NS_DOMAIN${NC}"
    echo -e "  ${YELLOW}  ⚠ Asegúrate de que el registro NS apunte a tu servidor${NC}"
}

# ============================================================
#   MÓDULO: Trojan-GFW (standalone, sin Xray)
# ============================================================

install_trojan_standalone() {
    echo -e "\n  ${CYAN}[TROJAN]${NC} Instalando Trojan-GFW standalone..."

    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"

    # Descargar Trojan
    local ARCH=$(uname -m)
    local URL="https://github.com/trojan-gfw/trojan/releases/latest/download/trojan-linux-amd64.tar.xz"
    [[ "$ARCH" == "aarch64" ]] && URL="https://github.com/trojan-gfw/trojan/releases/latest/download/trojan-linux-arm64.tar.xz"

    wget -q -O /tmp/trojan.tar.xz "$URL"
    tar -xJf /tmp/trojan.tar.xz -C /tmp/
    install -m 755 /tmp/trojan/trojan /usr/local/bin/
    rm -rf /tmp/trojan /tmp/trojan.tar.xz

    local PASS
    PASS=$(openssl rand -hex 12)
    mkdir -p /etc/trojan

    local CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
    local KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"

    cat > /etc/trojan/config.json <<EOF
{
    "run_type": "server",
    "local_addr": "0.0.0.0",
    "local_port": 10088,
    "remote_addr": "127.0.0.1",
    "remote_port": 80,
    "password": ["$PASS"],
    "log_level": 1,
    "ssl": {
        "cert":       "$CERT",
        "key":        "$KEY",
        "alpn":       ["h2","http/1.1"],
        "reuse_session": true
    },
    "tcp": {
        "prefer_ipv4":    true,
        "no_delay":       true,
        "keep_alive":     true,
        "reuse_port":     false,
        "fast_open":      false,
        "fast_open_qlen": 20
    }
}
EOF

    cat > /etc/systemd/system/trojan.service <<EOF
[Unit]
Description=Trojan GFW Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/trojan /etc/trojan/config.json
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable --now trojan

    echo -e "  ${GREEN}✔ Trojan standalone instalado${NC}"
    echo -e "  ${WHITE}  Password: $PASS${NC}"
    echo -e "  ${WHITE}  Puerto  : 10088${NC}"
}
