#!/bin/bash
# ============================================================
#   MÓDULO: VLESS WebSocket + TLS (via Xray)
# ============================================================

XRAY_DIR="/etc/xray"
VLESS_PORT="${VLESS_PORT:-10087}"
VLESS_WS_PATH="${VLESS_WS_PATH:-/vless}"

install_vless() {
    echo -e "\n  ${CYAN}[VLESS]${NC} Instalando VLESS WebSocket + TLS..."

    _ensure_xray_installed

    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"

    local UUID
    UUID=$(cat /proc/sys/kernel/random/uuid)

    # Agregar inbound VLESS al config de Xray
    _xray_add_inbound "vless" "$UUID" "$VLESS_PORT" "$VLESS_WS_PATH" "ws"

    _nginx_add_location "vless" "$VLESS_WS_PATH" "$VLESS_PORT" 2>/dev/null || true
    systemctl restart xray

    echo -e "  ${GREEN}✔ VLESS instalado${NC}"
    echo -e "  ${WHITE}  UUID    : $UUID${NC}"
    echo -e "  ${WHITE}  WS Path : $VLESS_WS_PATH${NC}"

    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    local LINK="vless://${UUID}@${HOST}:443?encryption=none&security=tls&type=ws&path=${VLESS_WS_PATH}#VLESS-WS"
    echo -e "  ${CYAN}$LINK${NC}"
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null
}

# ============================================================
#   MÓDULO: Trojan-GFW
# ============================================================

TROJAN_PORT="${TROJAN_PORT:-10088}"
TROJAN_WS_PATH="${TROJAN_WS_PATH:-/trojan}"

install_trojan() {
    echo -e "\n  ${CYAN}[TROJAN]${NC} Instalando Trojan-GFW..."

    _ensure_xray_installed

    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"

    local PASS
    PASS=$(openssl rand -hex 12)

    _xray_add_inbound "trojan" "$PASS" "$TROJAN_PORT" "$TROJAN_WS_PATH" "ws"

    _nginx_add_location "trojan" "$TROJAN_WS_PATH" "$TROJAN_PORT" 2>/dev/null || true
    systemctl restart xray

    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    echo -e "  ${GREEN}✔ Trojan instalado${NC}"
    echo -e "  ${WHITE}  Password: $PASS${NC}"
    echo -e "  ${WHITE}  WS Path : $TROJAN_WS_PATH${NC}"
    local LINK="trojan://${PASS}@${HOST}:443?security=tls&type=ws&path=${TROJAN_WS_PATH}#Trojan-WS"
    echo -e "  ${CYAN}$LINK${NC}"
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null
}

# ============================================================
#   MÓDULO: Xray VLESS Reality (sin necesidad de dominio)
# ============================================================

install_xray_reality() {
    echo -e "\n  ${CYAN}[XRAY-REALITY]${NC} Instalando Xray VLESS Reality..."

    _ensure_xray_installed

    local UUID PRIVATE_KEY PUBLIC_KEY SHORT_ID
    UUID=$(cat /proc/sys/kernel/random/uuid)
    SHORT_ID=$(openssl rand -hex 4)

    # Generar par de claves Reality
    local KEYS
    KEYS=$(/usr/local/bin/xray x25519 2>/dev/null)
    PRIVATE_KEY=$(echo "$KEYS" | grep "Private key:" | awk '{print $3}')
    PUBLIC_KEY=$(echo  "$KEYS" | grep "Public key:"  | awk '{print $3}')

    mkdir -p "$XRAY_DIR"

    cat > "$XRAY_DIR/config-reality.json" <<EOF
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": 443,
      "protocol": "vless",
      "settings": {
        "clients": [{ "id": "$UUID", "flow": "xtls-rprx-vision" }],
        "decryption": "none",
        "fallbacks": []
      },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show":        false,
          "dest":        "www.microsoft.com:443",
          "xver":        0,
          "serverNames": ["www.microsoft.com"],
          "privateKey":  "$PRIVATE_KEY",
          "shortIds":    ["$SHORT_ID"]
        }
      },
      "sniffing": { "enabled": true, "destOverride": ["http","tls"] }
    }
  ],
  "outbounds": [{ "protocol": "freedom" }]
}
EOF

    systemctl restart xray

    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"
    local LINK="vless://${UUID}@${HOST}:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.microsoft.com&fp=chrome&pbk=${PUBLIC_KEY}&sid=${SHORT_ID}&type=tcp#VLESS-Reality"

    echo -e "  ${GREEN}✔ VLESS Reality instalado${NC}"
    echo -e "  ${WHITE}  UUID       : $UUID${NC}"
    echo -e "  ${WHITE}  Public Key : $PUBLIC_KEY${NC}"
    echo -e "  ${WHITE}  Short ID   : $SHORT_ID${NC}"
    echo -e "  ${CYAN}$LINK${NC}"
    echo "$LINK" | qrencode -t ANSIUTF8 2>/dev/null
}

# ── HELPERS COMPARTIDOS ─────────────────────────────────────
_ensure_xray_installed() {
    if [[ ! -f /usr/local/bin/xray ]]; then
        echo -e "  ${CYAN}[XRAY]${NC} Instalando Xray-core..."
        bash <(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh) 2>/dev/null
    fi
}

_xray_add_inbound() {
    local proto="$1"   # vless | trojan
    local secret="$2"  # uuid o password
    local port="$3"
    local path="$4"
    local network="$5"

    local CONF="$XRAY_DIR/config-${proto}.json"

    if [[ "$proto" == "vless" ]]; then
        local clients_block="[{\"id\":\"$secret\",\"level\":0}]"
        local settings_key="\"id\":\"$secret\""
    else
        local clients_block="[{\"password\":\"$secret\",\"level\":0}]"
        local settings_key="\"password\":\"$secret\""
    fi

    cat > "$CONF" <<EOF
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": $port,
      "listen": "127.0.0.1",
      "protocol": "$proto",
      "settings": {
        "clients": $clients_block,
        "decryption": "none"
      },
      "streamSettings": {
        "network": "$network",
        "wsSettings": { "path": "$path" }
      }
    }
  ],
  "outbounds": [{ "protocol": "freedom" }]
}
EOF
}
