#!/bin/bash
# ============================================================
#   MÓDULO: OpenVPN TCP + UDP
# ============================================================

OVPN_DIR="/etc/openvpn"

install_openvpn() {
    echo -e "\n  ${CYAN}[OPENVPN]${NC} Instalando OpenVPN..."

    apt-get install -y openvpn easy-rsa 2>/dev/null

    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"
    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"

    # ── Configurar Easy-RSA ─────────────────────────────────
    make-cadir /etc/openvpn/easy-rsa
    cd /etc/openvpn/easy-rsa || return

    cat > vars <<EOF
set_var EASYRSA_REQ_COUNTRY    "US"
set_var EASYRSA_REQ_PROVINCE   "California"
set_var EASYRSA_REQ_CITY       "Los Angeles"
set_var EASYRSA_REQ_ORG        "VPN-Panel"
set_var EASYRSA_REQ_EMAIL      "${EMAIL:-admin@vpn.local}"
set_var EASYRSA_REQ_OU         "VPN"
set_var EASYRSA_KEY_SIZE       2048
set_var EASYRSA_ALGO           rsa
set_var EASYRSA_CA_EXPIRE      3650
set_var EASYRSA_CERT_EXPIRE    825
set_var EASYRSA_DIGEST         "sha256"
EOF

    ./easyrsa init-pki 2>/dev/null
    echo "VPN-Panel" | ./easyrsa build-ca nopass 2>/dev/null
    ./easyrsa gen-req server nopass 2>/dev/null
    echo "yes" | ./easyrsa sign-req server server 2>/dev/null
    ./easyrsa gen-dh 2>/dev/null
    openvpn --genkey --secret pki/ta.key 2>/dev/null

    cp pki/ca.crt pki/issued/server.crt pki/private/server.key pki/dh.pem pki/ta.key /etc/openvpn/

    # ── Configuración servidor TCP ──────────────────────────
    cat > /etc/openvpn/server-tcp.conf <<EOF
port 1194
proto tcp
dev tun
ca   /etc/openvpn/ca.crt
cert /etc/openvpn/server.crt
key  /etc/openvpn/server.key
dh   /etc/openvpn/dh.pem
tls-auth /etc/openvpn/ta.key 0
server 10.8.0.0 255.255.255.0
push "redirect-gateway def1 bypass-dhcp"
push "dhcp-option DNS 8.8.8.8"
push "dhcp-option DNS 8.8.4.4"
keepalive 10 120
cipher AES-256-CBC
auth SHA256
comp-lzo
user nobody
group nogroup
persist-key
persist-tun
status /var/log/openvpn-tcp.log
verb 3
EOF

    # ── Configuración servidor UDP ──────────────────────────
    cat > /etc/openvpn/server-udp.conf <<EOF
port 1195
proto udp
dev tun1
ca   /etc/openvpn/ca.crt
cert /etc/openvpn/server.crt
key  /etc/openvpn/server.key
dh   /etc/openvpn/dh.pem
tls-auth /etc/openvpn/ta.key 0
server 10.9.0.0 255.255.255.0
push "redirect-gateway def1 bypass-dhcp"
push "dhcp-option DNS 8.8.8.8"
keepalive 10 120
cipher AES-256-CBC
auth SHA256
comp-lzo
user nobody
group nogroup
persist-key
persist-tun
status /var/log/openvpn-udp.log
verb 3
EOF

    # ── Habilitar IP forwarding ─────────────────────────────
    echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/vpn.conf
    sysctl -p /etc/sysctl.d/vpn.conf 2>/dev/null

    # NAT
    local IFACE
    IFACE=$(ip route get 8.8.8.8 | awk '{print $5}' | head -1)
    iptables -t nat -A POSTROUTING -s 10.8.0.0/24 -o "$IFACE" -j MASQUERADE
    iptables -t nat -A POSTROUTING -s 10.9.0.0/24 -o "$IFACE" -j MASQUERADE

    systemctl enable --now openvpn@server-tcp
    systemctl enable --now openvpn@server-udp

    echo -e "  ${GREEN}✔ OpenVPN TCP (1194) y UDP (1195) instalados.${NC}"

    # ── Crear perfil .ovpn base ─────────────────────────────
    cat > /etc/openvpn/client-template.ovpn <<EOF
client
dev tun
proto tcp
remote $HOST 1194
resolv-retry infinite
nobind
persist-key
persist-tun
remote-cert-tls server
cipher AES-256-CBC
auth SHA256
comp-lzo
verb 3
key-direction 1
<ca>
$(cat /etc/openvpn/ca.crt)
</ca>
<tls-auth>
$(cat /etc/openvpn/ta.key)
</tls-auth>
EOF

    echo -e "  ${WHITE}  Template OVPN: /etc/openvpn/client-template.ovpn${NC}"
    sleep 2
}
