#!/bin/bash
# ============================================================
#   MÓDULO: Hysteria UDP
#   Puerto por defecto: 36712 UDP
# ============================================================

HYSTERIA_PORT="${HYSTERIA_PORT:-36712}"
HYSTERIA_DIR="/etc/hysteria"

install_hysteria() {
    echo -e "\n  ${CYAN}[HYSTERIA]${NC} Instalando Hysteria UDP..."

    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"

    # ── Descargar binario ───────────────────────────────────
    local ARCH=$(uname -m)
    local BIN_URL
    case "$ARCH" in
        x86_64)  BIN_URL="https://github.com/apernet/hysteria/releases/latest/download/hysteria-linux-amd64" ;;
        aarch64) BIN_URL="https://github.com/apernet/hysteria/releases/latest/download/hysteria-linux-arm64" ;;
        *)        echo -e "  ${RED}Arquitectura no soportada: $ARCH${NC}"; return 1 ;;
    esac

    wget -q -O /usr/local/bin/hysteria "$BIN_URL"
    chmod +x /usr/local/bin/hysteria

    mkdir -p "$HYSTERIA_DIR"

    # ── Generar certificado autofirmado si no hay dominio ──
    local CERT KEY
    if [[ -n "$DOMAIN" && -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]]; then
        CERT="/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
        KEY="/etc/letsencrypt/live/$DOMAIN/privkey.pem"
    else
        CERT="$HYSTERIA_DIR/hysteria.crt"
        KEY="$HYSTERIA_DIR/hysteria.key"
        openssl req -x509 -nodes -newkey ec:<(openssl ecparam -name prime256v1) \
            -keyout "$KEY" -out "$CERT" -subj "/CN=hysteria" -days 3650 2>/dev/null
    fi

    # ── Generar contraseña aleatoria ───────────────────────
    local PASS
    PASS=$(openssl rand -base64 16)
    echo "$PASS" > "$HYSTERIA_DIR/password.txt"

    # ── Configuración servidor ──────────────────────────────
    cat > "$HYSTERIA_DIR/config.json" <<EOF
{
  "listen": ":$HYSTERIA_PORT",
  "tls": {
    "cert": "$CERT",
    "key":  "$KEY"
  },
  "quic": {
    "initStreamReceiveWindow": 8388608,
    "maxStreamReceiveWindow":  8388608,
    "initConnReceiveWindow":   20971520,
    "maxConnReceiveWindow":    20971520
  },
  "bandwidth": {
    "up":   "100 mbps",
    "down": "100 mbps"
  },
  "ignoreClientBandwidth": false,
  "auth": {
    "type":     "password",
    "password": "$PASS"
  },
  "masquerade": {
    "type": "proxy",
    "proxy": {
      "url":         "https://www.bing.com",
      "rewriteHost": true
    }
  }
}
EOF

    # ── Servicio systemd ────────────────────────────────────
    cat > /etc/systemd/system/hysteria.service <<EOF
[Unit]
Description=Hysteria UDP VPN Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/hysteria server --config $HYSTERIA_DIR/config.json
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable --now hysteria

    echo -e "  ${GREEN}✔ Hysteria instalado${NC}"
    echo -e "  ${WHITE}  Puerto  : $HYSTERIA_PORT (UDP)${NC}"
    echo -e "  ${WHITE}  Password: $PASS${NC}"
    echo -e "  ${WHITE}  Config  : $HYSTERIA_DIR/config.json${NC}"
}
