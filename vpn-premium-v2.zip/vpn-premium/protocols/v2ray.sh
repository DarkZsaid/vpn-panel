#!/bin/bash
# ============================================================
#   MÓDULO: V2Ray VMess WebSocket + TLS
# ============================================================

V2RAY_DIR="/etc/v2ray"
V2RAY_PORT="${V2RAY_PORT:-10086}"
V2RAY_WS_PATH="${V2RAY_WS_PATH:-/v2ray}"

install_v2ray() {
    echo -e "\n  ${CYAN}[V2RAY]${NC} Instalando V2Ray VMess WebSocket..."

    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"

    # ── Instalar V2Ray ──────────────────────────────────────
    bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh) 2>/dev/null \
        || { echo -e "  ${RED}Error descargando V2Ray.${NC}"; return 1; }

    mkdir -p "$V2RAY_DIR"

    local UUID
    UUID=$(cat /proc/sys/kernel/random/uuid)
    echo "$UUID" > "$V2RAY_DIR/uuid.txt"

    # ── Configuración V2Ray ─────────────────────────────────
    cat > "$V2RAY_DIR/config.json" <<EOF
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/v2ray/access.log",
    "error":  "/var/log/v2ray/error.log"
  },
  "inbounds": [
    {
      "port": $V2RAY_PORT,
      "listen": "127.0.0.1",
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id": "$UUID",
            "alterId": 0
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "wsSettings": {
          "path": "$V2RAY_WS_PATH"
        }
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
EOF

    # ── Configurar Nginx como proxy reverso ─────────────────
    _nginx_add_location "vmess" "$V2RAY_WS_PATH" "$V2RAY_PORT"

    systemctl enable --now v2ray
    systemctl restart nginx 2>/dev/null

    echo -e "  ${GREEN}✔ V2Ray VMess instalado${NC}"
    echo -e "  ${WHITE}  UUID     : $UUID${NC}"
    echo -e "  ${WHITE}  WS Path  : $V2RAY_WS_PATH${NC}"
    echo -e "  ${WHITE}  Puerto   : $V2RAY_PORT (local)${NC}"
    _show_vmess_link "$UUID"
}

_show_vmess_link() {
    local UUID="$1"
    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"
    local HOST="${DOMAIN:-$(curl -s ifconfig.me)}"

    local VMESS_JSON="{\"v\":\"2\",\"ps\":\"VMess-WS\",\"add\":\"$HOST\",\"port\":\"443\",\"id\":\"$UUID\",\"aid\":\"0\",\"net\":\"ws\",\"path\":\"$V2RAY_WS_PATH\",\"tls\":\"tls\"}"
    local VMESS_LINK="vmess://$(echo -n "$VMESS_JSON" | base64 -w 0)"
    echo ""
    echo -e "  ${YELLOW}── LINK DE CONEXIÓN ────────────────────────────────${NC}"
    echo -e "  ${CYAN}$VMESS_LINK${NC}"
    echo ""
    # QR en terminal
    echo "$VMESS_LINK" | qrencode -t ANSIUTF8 2>/dev/null
}

_nginx_add_location() {
    local name="$1"
    local path="$2"
    local port="$3"

    local CONF="/etc/nginx/conf.d/vpn-${name}.conf"
    cat >> /etc/nginx/conf.d/vpn-main.conf <<EOF

    location $path {
        proxy_pass          http://127.0.0.1:$port;
        proxy_http_version  1.1;
        proxy_set_header    Upgrade    \$http_upgrade;
        proxy_set_header    Connection "upgrade";
        proxy_set_header    Host       \$host;
        proxy_read_timeout  86400;
    }
EOF
}
