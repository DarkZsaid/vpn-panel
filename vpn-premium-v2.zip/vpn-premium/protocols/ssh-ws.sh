#!/bin/bash
# ============================================================
#   MÓDULO: SSH WebSocket (Dropbear + WebSocket Proxy)
#   Puerto 80 y Puerto 443 con SSL
# ============================================================

install_ssh_ws() {
    local PORT="${1:-80}"
    echo -e "\n  ${CYAN}[SSH-WS]${NC} Instalando SSH WebSocket en puerto $PORT..."

    # ── Instalar Dropbear ───────────────────────────────────
    apt-get install -y dropbear

    # Configurar Dropbear
    cat > /etc/default/dropbear <<EOF
NO_START=0
DROPBEAR_PORT=22
DROPBEAR_EXTRA_ARGS="-p 143"
DROPBEAR_BANNER="/etc/issue.net"
DROPBEAR_RECEIVE_WINDOW=65536
EOF

    # ── Banner de bienvenida ────────────────────────────────
    cat > /etc/issue.net <<'EOF'
 ╔══════════════════════════════════════╗
 ║     VPN MULTI-PROTOCOLO SERVER       ║
 ║     Acceso Autorizado Únicamente     ║
 ╚══════════════════════════════════════╝
EOF

    # ── Instalar WebSocket proxy en Python ─────────────────
    cat > /usr/local/bin/ws-ssh-proxy.py <<'PYEOF'
#!/usr/bin/env python3
"""WebSocket to SSH proxy - puerto configurable"""
import socket, threading, select, sys, os

LISTEN_PORT = int(os.environ.get("WS_PORT", "80"))
SSH_HOST    = "127.0.0.1"
SSH_PORT    = 22
BUFFER_SIZE = 4096

HTTP_RESP = (
    b"HTTP/1.1 101 Switching Protocols\r\n"
    b"Upgrade: websocket\r\n"
    b"Connection: Upgrade\r\n"
    b"\r\n"
)

def handle_client(client_sock):
    try:
        data = client_sock.recv(BUFFER_SIZE)
        if not data:
            client_sock.close()
            return

        # Responder handshake HTTP/WS
        client_sock.sendall(HTTP_RESP)

        # Conectar al SSH local
        ssh_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ssh_sock.connect((SSH_HOST, SSH_PORT))

        def forward(src, dst):
            try:
                while True:
                    r, _, _ = select.select([src], [], [], 60)
                    if not r:
                        break
                    d = src.recv(BUFFER_SIZE)
                    if not d:
                        break
                    dst.sendall(d)
            except Exception:
                pass
            finally:
                src.close()
                dst.close()

        threading.Thread(target=forward, args=(client_sock, ssh_sock), daemon=True).start()
        threading.Thread(target=forward, args=(ssh_sock, client_sock), daemon=True).start()
    except Exception as e:
        client_sock.close()

def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", LISTEN_PORT))
    srv.listen(512)
    print(f"[WS-SSH] Escuchando en puerto {LISTEN_PORT}")
    while True:
        try:
            client, _ = srv.accept()
            threading.Thread(target=handle_client, args=(client,), daemon=True).start()
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    main()
PYEOF
    chmod +x /usr/local/bin/ws-ssh-proxy.py

    # ── Servicio systemd ────────────────────────────────────
    local svc_name="ws-ssh-${PORT}"
    cat > "/etc/systemd/system/${svc_name}.service" <<EOF
[Unit]
Description=SSH WebSocket Proxy Port $PORT
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /usr/local/bin/ws-ssh-proxy.py
Environment="WS_PORT=$PORT"
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable --now "$svc_name"
    systemctl restart dropbear

    # ── Si es puerto 443, configurar stunnel ───────────────
    if [[ "$PORT" == "443" ]]; then
        _setup_stunnel_ssl
    fi

    echo -e "  ${GREEN}✔ SSH WebSocket instalado en puerto $PORT${NC}"
    echo -e "  ${WHITE}  Payload HTTP: GET / HTTP/1.1[crlf]Host: TU_DOMINIO[crlf]Upgrade: websocket[crlf][crlf]${NC}"
}

_setup_stunnel_ssl() {
    [[ -f "$CONFIG_DIR/panel.conf" ]] && source "$CONFIG_DIR/panel.conf"
    local CERT="/etc/letsencrypt/live/${DOMAIN:-localhost}/fullchain.pem"
    local KEY="/etc/letsencrypt/live/${DOMAIN:-localhost}/privkey.pem"

    cat > /etc/stunnel/stunnel.conf <<EOF
[dropbear-ssl]
accept  = 443
connect = 127.0.0.1:80
cert    = $CERT
key     = $KEY
EOF
    systemctl enable --now stunnel4
}
